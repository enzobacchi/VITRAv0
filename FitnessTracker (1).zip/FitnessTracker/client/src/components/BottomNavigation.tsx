import { Link, useLocation } from "wouter";
import { Home, Dumbbell, Apple, MessageCircle } from "lucide-react";

export function BottomNavigation() {
  const [location] = useLocation();

  const navItems = [
    { href: "/", icon: Home, label: "Home" },
    { href: "/workouts", icon: Dumbbell, label: "Workouts" },
    { href: "/nutrition", icon: Apple, label: "Nutrition" },
    { href: "/coach", icon: MessageCircle, label: "Coach" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-black/95 backdrop-blur-sm border-t border-gray-800 px-6 py-2 safe-area-pb">
      <div className="flex items-center justify-around max-w-md mx-auto">
        {navItems.map((item) => {
          const IconComponent = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center justify-center py-3 px-4 transition-colors ${
                location === item.href
                  ? "text-white"
                  : "text-gray-500 hover:text-gray-300"
              }`}
            >
              <IconComponent className="w-6 h-6" />
            </Link>
          );
        })}
      </div>
    </nav>
  );
}