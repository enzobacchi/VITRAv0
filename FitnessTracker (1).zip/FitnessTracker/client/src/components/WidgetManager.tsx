import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Plus, X } from "lucide-react";
import { AIAssistantPreview } from "@/components/widgets/AIAssistantWidget";

interface Widget {
  id: string;
  name: string;
  component: React.ComponentType<any>;
  enabled: boolean;
  order: number;
  size?: 'full' | 'half';
  description?: string;
  preview?: React.ReactNode;
}

interface WidgetManagerProps {
  widgets: Widget[];
  onUpdateWidgets: (widgets: Widget[]) => void;
}

// Widget previews for the gallery
const WIDGET_PREVIEWS = {
  calories: (
    <div className="bg-gray-800 border border-gray-700 rounded-xl p-4 w-full">
      <h3 className="text-sm font-medium text-white mb-2">CALORIES</h3>
      <div className="flex items-end space-x-1">
        <span className="text-2xl font-light text-white">1,680</span>
        <span className="text-xs text-gray-400">of 2,800</span>
      </div>
    </div>
  ),
  macros: (
    <div className="bg-gray-800 border border-gray-700 rounded-xl p-4 w-full">
      <h3 className="text-sm font-medium text-white mb-3">MACROS</h3>
      <div className="grid grid-cols-3 gap-2">
        <div className="text-center">
          <div className="w-8 h-8 bg-green-500 rounded-full mx-auto mb-1"></div>
          <p className="text-xs text-gray-400">Protein</p>
        </div>
        <div className="text-center">
          <div className="w-8 h-8 bg-blue-500 rounded-full mx-auto mb-1"></div>
          <p className="text-xs text-gray-400">Carbs</p>
        </div>
        <div className="text-center">
          <div className="w-8 h-8 bg-yellow-500 rounded-full mx-auto mb-1"></div>
          <p className="text-xs text-gray-400">Fats</p>
        </div>
      </div>
    </div>
  ),
  workout: (
    <div className="bg-gray-800 border border-gray-700 rounded-xl p-4 w-full">
      <h3 className="text-sm font-medium text-white mb-2">TODAY'S WORKOUT</h3>
      <div className="space-y-1">
        <p className="text-sm text-white">Upper Body Push</p>
        <p className="text-xs text-gray-400">45min • 6 exercises</p>
      </div>
    </div>
  ),
  water: (
    <div className="bg-gray-800 border border-gray-700 rounded-xl p-4 w-full">
      <h3 className="text-sm font-medium text-white mb-2">WATER</h3>
      <div className="flex items-center space-x-2">
        <div className="flex-1 bg-gray-700 rounded-full h-2">
          <div className="bg-blue-400 h-2 rounded-full w-3/4"></div>
        </div>
        <span className="text-xs text-gray-400">6/8L</span>
      </div>
    </div>
  ),
  streak: (
    <div className="bg-gray-800 border border-gray-700 rounded-xl p-4 w-full">
      <h3 className="text-sm font-medium text-white mb-2">STREAK</h3>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-lg font-semibold text-white">7</p>
          <p className="text-xs text-gray-400">days</p>
        </div>
        <div className="text-right">
          <p className="text-sm text-teal-400">4/6</p>
          <p className="text-xs text-gray-400">this week</p>
        </div>
      </div>
    </div>
  ),
  recovery: (
    <div className="bg-gray-800 border border-gray-700 rounded-xl p-4 w-full">
      <h3 className="text-sm font-medium text-white mb-2">RECOVERY</h3>
      <div className="flex items-center space-x-3">
        <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
          <span className="text-xs font-bold text-white">85</span>
        </div>
        <div>
          <p className="text-xs text-green-400">Good</p>
          <p className="text-xs text-gray-400">Ready to train</p>
        </div>
      </div>
    </div>
  ),
  aiAssistant: <AIAssistantPreview />,
};

export function WidgetManager({ widgets, onUpdateWidgets }: WidgetManagerProps) {
  const [isOpen, setIsOpen] = useState(false);

  const addWidget = (widgetId: string, size: 'full' | 'half' = 'full') => {
    const updatedWidgets = widgets.map(widget =>
      widget.id === widgetId ? { ...widget, enabled: true, size } : widget
    );
    onUpdateWidgets(updatedWidgets);
  };

  const toggleWidgetSize = (widgetId: string) => {
    const updatedWidgets = widgets.map(widget =>
      widget.id === widgetId ? { ...widget, size: widget.size === 'full' ? 'half' : 'full' } : widget
    );
    onUpdateWidgets(updatedWidgets);
  };

  const removeWidget = (widgetId: string) => {
    const updatedWidgets = widgets.map(widget =>
      widget.id === widgetId ? { ...widget, enabled: false } : widget
    );
    onUpdateWidgets(updatedWidgets);
  };

  const availableWidgets = widgets.filter(w => !w.enabled);

  return (
    <>
      <Button
        onClick={() => setIsOpen(true)}
        variant="ghost"
        size="sm"
        className="w-10 h-10 p-0 text-gray-400 hover:text-white hover:bg-gray-700 rounded-full"
      >
        <Plus className="w-5 h-5" />
      </Button>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-lg bg-gray-900 border-gray-700 text-white max-h-[80vh] overflow-y-auto" aria-describedby="widget-manager-description">
          <DialogHeader>
            <DialogTitle className="text-lg font-semibold text-white">Add Widgets</DialogTitle>
            <div id="widget-manager-description" className="sr-only">
              Manage and customize your dashboard widgets. Add new widgets or remove existing ones.
            </div>
          </DialogHeader>
          
          {availableWidgets.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-400 mb-2">All widgets are already added</p>
              <p className="text-sm text-gray-500">
                Tap and hold widgets on your home screen to rearrange them
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {availableWidgets.map((widget) => (
                <div
                  key={widget.id}
                  className="relative group"
                >
                  {/* Widget Preview */}
                  <div className="mb-3 space-y-2">
                    <div className="text-xs text-gray-400 font-medium">Full Size</div>
                    <div className="w-full">
                      {WIDGET_PREVIEWS[widget.id as keyof typeof WIDGET_PREVIEWS]}
                    </div>
                    
                    {['calories', 'macros'].includes(widget.id) && (
                      <>
                        <div className="text-xs text-gray-400 font-medium mt-3">Half Size</div>
                        <div className="w-1/2">
                          {widget.id === 'calories' && (
                            <div className="bg-gray-800 border border-gray-700 rounded-xl p-3 w-full">
                              <h3 className="text-xs font-medium text-white mb-2">CALORIES</h3>
                              <div className="flex items-end space-x-1 mb-1">
                                <span className="text-xl font-light text-white">400</span>
                                <span className="text-xs text-gray-400">/2800</span>
                              </div>
                              <div className="w-full bg-gray-700 rounded-full h-1">
                                <div className="bg-teal-500 h-1 rounded-full w-1/6"></div>
                              </div>
                            </div>
                          )}
                          {widget.id === 'macros' && (
                            <div className="bg-gray-800 border border-gray-700 rounded-xl p-3 w-full">
                              <h3 className="text-xs font-medium text-white mb-2">MACROS</h3>
                              <div className="space-y-1">
                                <div className="flex justify-between">
                                  <span className="text-xs text-gray-400">Protein</span>
                                  <span className="text-xs text-white">0g</span>
                                </div>
                                <div className="w-full bg-gray-700 rounded-full h-0.5">
                                  <div className="bg-red-500 h-0.5 rounded-full w-0"></div>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      </>
                    )}
                  </div>
                  
                  {/* Widget Info */}
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-sm font-medium text-white">{widget.name}</h3>
                      <p className="text-xs text-gray-400">
                        {widget.id === 'calories' && 'Track daily calorie intake'}
                        {widget.id === 'macros' && 'Monitor protein, carbs, and fats'}
                        {widget.id === 'workout' && 'View today\'s scheduled workout'}
                        {widget.id === 'water' && 'Log water intake throughout the day'}
                        {widget.id === 'streak' && 'Track workout consistency'}
                        {widget.id === 'recovery' && 'Monitor recovery metrics'}
                        {widget.id === 'aiAssistant' && 'Quick access to AI coaching and personalized suggestions'}
                      </p>
                    </div>
                    
                    <div className="flex gap-2">
                      {['calories', 'macros'].includes(widget.id) && (
                        <>
                          <Button
                            onClick={() => addWidget(widget.id, 'half')}
                            size="sm"
                            variant="outline"
                            className="border-gray-600 text-gray-300 hover:text-white px-3"
                          >
                            Half
                          </Button>
                          <Button
                            onClick={() => addWidget(widget.id, 'full')}
                            size="sm"
                            className="bg-teal-500 hover:bg-teal-400 text-white px-3"
                          >
                            Full
                          </Button>
                        </>
                      )}
                      {!['calories', 'macros'].includes(widget.id) && (
                        <Button
                          onClick={() => addWidget(widget.id)}
                          size="sm"
                          className="bg-teal-500 hover:bg-teal-400 text-white px-4"
                        >
                          Add
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
          
          {/* Current Widgets Section */}
          {widgets.some(w => w.enabled) && (
            <>
              <div className="border-t border-gray-700 pt-6 mt-6">
                <h3 className="text-lg font-medium text-white mb-4">Current Widgets</h3>
                <div className="space-y-3">
                  {widgets
                    .filter(w => w.enabled)
                    .sort((a, b) => a.order - b.order)
                    .map((widget) => (
                      <div
                        key={widget.id}
                        className="flex items-center justify-between p-3 bg-gray-800 rounded-lg border border-gray-700"
                      >
                        <div className="flex items-center space-x-3">
                          <div className="w-2 h-8 bg-gray-600 rounded-full flex items-center justify-center">
                            <div className="w-1 h-4 bg-gray-400 rounded-full"></div>
                          </div>
                          <div className="flex-1">
                            <span className="text-sm font-medium">{widget.name}</span>
                            <div className="text-xs text-gray-500">
                              {widget.size === 'half' ? 'Half width' : 'Full width'}
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          {['calories', 'macros'].includes(widget.id) && (
                            <Button
                              onClick={() => toggleWidgetSize(widget.id)}
                              variant="ghost"
                              size="sm"
                              className="text-xs text-gray-400 hover:text-white px-2"
                            >
                              {widget.size === 'half' ? 'Make Full' : 'Make Half'}
                            </Button>
                          )}
                          <Button
                            onClick={() => removeWidget(widget.id)}
                            variant="ghost"
                            size="sm"
                            className="w-8 h-8 p-0 text-gray-400 hover:text-red-400"
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                </div>
                <p className="text-xs text-gray-500 mt-3">
                  Tip: Tap and hold widgets on your home screen to rearrange them
                </p>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}