import { ChevronRight } from "lucide-react";
import { useLocation } from "wouter";

interface CaloriesCompactWidgetProps {
  dailyNutrition: any;
}

export function CaloriesCompactWidget({ dailyNutrition }: CaloriesCompactWidgetProps) {
  const [, setLocation] = useLocation();

  return (
    <div 
      data-widget-click
      onClick={() => setLocation('/calories')}
      onContextMenu={(e) => e.preventDefault()}
      className="bg-gray-900 border border-gray-800 rounded-2xl p-4 cursor-pointer hover:bg-gray-800 transition-all duration-200 select-none h-full"
      style={{ WebkitTouchCallout: 'none', WebkitUserSelect: 'none' }}
    >
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-medium text-white uppercase tracking-wide">Calories</h3>
        <ChevronRight className="w-4 h-4 text-gray-600" />
      </div>
      
      <div className="space-y-1">
        <div className="flex items-end space-x-1">
          <span className="text-3xl font-light text-white">{Math.round(dailyNutrition.calories)}</span>
          <span className="text-xs text-gray-400 pb-1">/{dailyNutrition.targetCalories}</span>
        </div>
        <div className="w-full bg-gray-800 rounded-full h-1.5">
          <div 
            className="bg-gradient-to-r from-teal-500 to-blue-500 h-1.5 rounded-full transition-all duration-300"
            style={{ width: `${Math.min((dailyNutrition.calories / dailyNutrition.targetCalories) * 100, 100)}%` }}
          />
        </div>
      </div>
    </div>
  );
}