import { ChevronRight } from "lucide-react";
import { useLocation } from "wouter";

interface MacrosCompactWidgetProps {
  dailyNutrition: any;
  proteinPercentage: number;
  carbsPercentage: number;
  fatsPercentage: number;
}

export function MacrosCompactWidget({ 
  dailyNutrition, 
  proteinPercentage, 
  carbsPercentage, 
  fatsPercentage 
}: MacrosCompactWidgetProps) {
  const [, setLocation] = useLocation();

  return (
    <div 
      data-widget-click
      onClick={() => setLocation('/nutrition')}
      onContextMenu={(e) => e.preventDefault()}
      className="bg-gray-900 border border-gray-800 rounded-2xl p-4 cursor-pointer hover:bg-gray-800 transition-all duration-200 select-none h-full"
      style={{ WebkitTouchCallout: 'none', WebkitUserSelect: 'none' }}
    >
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-medium text-white uppercase tracking-wide">Macros</h3>
        <ChevronRight className="w-4 h-4 text-gray-600" />
      </div>
      
      <div className="space-y-2">
        {/* Protein */}
        <div className="flex items-center justify-between">
          <span className="text-xs text-gray-400">Protein</span>
          <span className="text-xs text-white">{Math.round(dailyNutrition.protein)}g</span>
        </div>
        <div className="w-full bg-gray-800 rounded-full h-1">
          <div 
            className="bg-red-500 h-1 rounded-full transition-all duration-300"
            style={{ width: `${Math.min(proteinPercentage, 100)}%` }}
          />
        </div>
        
        {/* Carbs */}
        <div className="flex items-center justify-between">
          <span className="text-xs text-gray-400">Carbs</span>
          <span className="text-xs text-white">{Math.round(dailyNutrition.carbs)}g</span>
        </div>
        <div className="w-full bg-gray-800 rounded-full h-1">
          <div 
            className="bg-blue-500 h-1 rounded-full transition-all duration-300"
            style={{ width: `${Math.min(carbsPercentage, 100)}%` }}
          />
        </div>
        
        {/* Fats */}
        <div className="flex items-center justify-between">
          <span className="text-xs text-gray-400">Fats</span>
          <span className="text-xs text-white">{Math.round(dailyNutrition.fats)}g</span>
        </div>
        <div className="w-full bg-gray-800 rounded-full h-1">
          <div 
            className="bg-yellow-500 h-1 rounded-full transition-all duration-300"
            style={{ width: `${Math.min(fatsPercentage, 100)}%` }}
          />
        </div>
      </div>
    </div>
  );
}