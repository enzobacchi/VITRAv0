import { Calendar, ChevronRight } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";

export function WorkoutStreakWidget() {
  const [, setLocation] = useLocation();

  // Fetch workout streak data
  const { data: streakData = { current: 0, thisWeek: 0, total: 0 } } = useQuery({
    queryKey: ["/api/workouts/streak"],
    staleTime: 30000,
  });

  return (
    <div 
      onClick={() => setLocation('/workouts')}
      onContextMenu={(e) => e.preventDefault()}
      className="bg-gray-900 border border-gray-800 rounded-2xl p-6 cursor-pointer hover:bg-gray-800 transition-all duration-200 select-none"
      style={{ WebkitTouchCallout: 'none', WebkitUserSelect: 'none' }}
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-base font-medium text-white uppercase tracking-wide">STREAK</h3>
        <div className="flex items-center space-x-2">
          <Calendar className="w-5 h-5 text-teal-400" />
          <ChevronRight className="w-5 h-5 text-gray-600" />
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4 text-center">
        <div>
          <div className="text-2xl font-light text-white mb-1">
            {streakData.current}
          </div>
          <div className="text-xs text-gray-400 uppercase tracking-wide">
            Current
          </div>
        </div>
        
        <div>
          <div className="text-2xl font-light text-teal-400 mb-1">
            {streakData.thisWeek}
          </div>
          <div className="text-xs text-gray-400 uppercase tracking-wide">
            This Week
          </div>
        </div>
        
        <div>
          <div className="text-2xl font-light text-white mb-1">
            {streakData.total}
          </div>
          <div className="text-xs text-gray-400 uppercase tracking-wide">
            Total
          </div>
        </div>
      </div>
    </div>
  );
}