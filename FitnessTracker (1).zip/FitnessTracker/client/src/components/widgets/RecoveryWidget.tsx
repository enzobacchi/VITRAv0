import { useState } from "react";
import { Heart, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Slider } from "@/components/ui/slider";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export function RecoveryWidget() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [recoveryScore, setRecoveryScore] = useState([75]);
  const [sleepQuality, setSleepQuality] = useState([8]);
  const [stressLevel, setStressLevel] = useState([3]);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch today's recovery data
  const { data: recoveryData = { score: 75, sleep: 8, stress: 3, status: 'Good' } } = useQuery({
    queryKey: ["/api/recovery/today"],
    staleTime: 30000,
  });

  // Update recovery mutation
  const updateRecoveryMutation = useMutation({
    mutationFn: async (data: { score: number; sleep: number; stress: number }) => {
      const response = await apiRequest("POST", "/api/recovery/log", {
        ...data,
        loggedAt: new Date().toISOString(),
        loggedDate: new Date().toISOString().split('T')[0],
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recovery/today"] });
      toast({ title: "Success", description: "Recovery data updated" });
      setIsModalOpen(false);
    },
  });

  const handleSave = () => {
    updateRecoveryMutation.mutate({
      score: recoveryScore[0],
      sleep: sleepQuality[0],
      stress: stressLevel[0],
    });
  };

  const getStatusColor = (score: number) => {
    if (score >= 80) return 'text-green-400';
    if (score >= 60) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getStatusText = (score: number) => {
    if (score >= 80) return 'Excellent';
    if (score >= 60) return 'Good';
    return 'Poor';
  };

  return (
    <>
      <div 
        onClick={() => setIsModalOpen(true)}
        onContextMenu={(e) => e.preventDefault()}
        className="bg-gray-900 border border-gray-800 rounded-2xl p-6 cursor-pointer hover:bg-gray-800 transition-all duration-200 select-none"
        style={{ WebkitTouchCallout: 'none', WebkitUserSelect: 'none' }}
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-medium text-white uppercase tracking-wide">RECOVERY</h3>
          <div className="flex items-center space-x-2">
            <Heart className="w-5 h-5 text-red-400" />
            <ChevronRight className="w-5 h-5 text-gray-600" />
          </div>
        </div>

        <div className="text-center">
          <div className={`text-6xl font-light mb-2 ${getStatusColor(recoveryData.score)}`}>
            {recoveryData.score}%
          </div>
          <div className={`text-lg font-medium mb-2 ${getStatusColor(recoveryData.score)}`}>
            {getStatusText(recoveryData.score)}
          </div>
          <div className="text-sm text-gray-400">
            Sleep: {recoveryData.sleep}h • Stress: {recoveryData.stress}/10
          </div>
        </div>
      </div>

      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="bg-gray-900 border-gray-800 text-white">
          <DialogHeader>
            <DialogTitle className="text-white">Update Recovery</DialogTitle>
            <DialogDescription className="text-gray-400">
              Log your recovery metrics for today.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            <div>
              <label className="text-sm font-medium text-white mb-2 block">
                Recovery Score: {recoveryScore[0]}%
              </label>
              <Slider
                value={recoveryScore}
                onValueChange={setRecoveryScore}
                max={100}
                min={0}
                step={5}
                className="w-full"
              />
            </div>

            <div>
              <label className="text-sm font-medium text-white mb-2 block">
                Sleep Quality: {sleepQuality[0]} hours
              </label>
              <Slider
                value={sleepQuality}
                onValueChange={setSleepQuality}
                max={12}
                min={3}
                step={0.5}
                className="w-full"
              />
            </div>

            <div>
              <label className="text-sm font-medium text-white mb-2 block">
                Stress Level: {stressLevel[0]}/10
              </label>
              <Slider
                value={stressLevel}
                onValueChange={setStressLevel}
                max={10}
                min={1}
                step={1}
                className="w-full"
              />
            </div>
          </div>

          <div className="flex justify-end space-x-2 pt-4">
            <Button
              variant="ghost"
              onClick={() => setIsModalOpen(false)}
              className="text-gray-400 hover:text-white"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              disabled={updateRecoveryMutation.isPending}
              className="bg-teal-500 hover:bg-teal-600 text-white"
            >
              Save
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}