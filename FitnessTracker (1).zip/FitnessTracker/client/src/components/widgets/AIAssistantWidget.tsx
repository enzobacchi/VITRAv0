import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { MessageCircle, Send, Bot, Sparkles } from "lucide-react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";

export function AIAssistantWidget() {
  const [message, setMessage] = useState("");
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch recent chat history (last 3 messages)
  const { data: chatHistory = [] } = useQuery({
    queryKey: ["/api/ai/chat-history"],
    select: (data) => data.slice(-3), // Only show last 3 messages
  });

  // Quick AI suggestion mutation
  const suggestionMutation = useMutation({
    mutationFn: async (type: string) => {
      const suggestions = {
        workout: "Generate a quick 20-minute workout for today",
        nutrition: "What should I eat to reach my protein goals?",
        recovery: "Give me recovery tips based on my current status"
      };
      
      const response = await apiRequest("POST", "/api/ai/chat", {
        message: suggestions[type as keyof typeof suggestions],
        context: {}
      });
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/ai/chat-history"] });
      if (data.workoutPlan) {
        toast({ 
          title: "Workout Generated", 
          description: "New workout plan created! Check your workouts tab."
        });
      }
    },
  });

  const quickSuggestions = [
    { label: "Quick Workout", type: "workout", icon: "💪" },
    { label: "Nutrition Tip", type: "nutrition", icon: "🥗" },
    { label: "Recovery Advice", type: "recovery", icon: "😴" }
  ];

  const handleQuickSuggestion = (type: string) => {
    suggestionMutation.mutate(type);
  };

  const handleOpenChat = () => {
    setLocation("/coach");
  };

  return (
    <div 
      className="bg-gray-900 border border-gray-800 rounded-2xl p-6 cursor-pointer hover:border-gray-700 transition-all duration-200"
      data-widget-click
      onClick={handleOpenChat}
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-r from-teal-500 to-blue-500 rounded-full flex items-center justify-center">
            <Bot className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-white font-semibold">AI Assistant</h3>
            <p className="text-gray-400 text-sm">Your fitness coach</p>
          </div>
        </div>
        <Sparkles className="w-5 h-5 text-teal-400" />
      </div>

      {/* Recent Chat Preview */}
      {chatHistory.length > 0 && (
        <div className="mb-4">
          <div className="bg-gray-800/50 rounded-lg p-3 border border-gray-700/50">
            <p className="text-gray-300 text-sm line-clamp-2">
              {chatHistory[chatHistory.length - 1]?.response || 
               chatHistory[chatHistory.length - 1]?.message || 
               "Ready to help with your fitness goals!"}
            </p>
          </div>
        </div>
      )}

      {/* Quick Suggestions */}
      <div className="space-y-2">
        <p className="text-gray-400 text-xs uppercase tracking-wide font-medium mb-3">
          Quick Actions
        </p>
        <div className="grid grid-cols-3 gap-2">
          {quickSuggestions.map((suggestion) => (
            <button
              key={suggestion.type}
              onClick={(e) => {
                e.stopPropagation();
                handleQuickSuggestion(suggestion.type);
              }}
              disabled={suggestionMutation.isPending}
              className="bg-gray-800/50 hover:bg-gray-700/50 border border-gray-700/50 rounded-lg p-2 text-center transition-all duration-200 disabled:opacity-50"
            >
              <div className="text-lg mb-1">{suggestion.icon}</div>
              <p className="text-gray-300 text-xs font-medium">
                {suggestion.label}
              </p>
            </button>
          ))}
        </div>
      </div>

      {/* Chat Access Hint */}
      <div className="mt-4 pt-4 border-t border-gray-800/50">
        <div className="flex items-center justify-between">
          <p className="text-gray-500 text-xs">Tap to open full chat</p>
          <MessageCircle className="w-4 h-4 text-gray-500" />
        </div>
      </div>
    </div>
  );
}

// Widget preview component for the widget manager
export function AIAssistantPreview() {
  return (
    <div className="bg-gray-900 border border-gray-800 rounded-lg p-4">
      <div className="flex items-center gap-3 mb-3">
        <div className="w-8 h-8 bg-gradient-to-r from-teal-500 to-blue-500 rounded-full flex items-center justify-center">
          <Bot className="w-4 h-4 text-white" />
        </div>
        <div>
          <h4 className="text-white font-medium text-sm">AI Assistant</h4>
          <p className="text-gray-400 text-xs">Quick AI coaching</p>
        </div>
      </div>
      <div className="grid grid-cols-3 gap-1">
        {["💪", "🥗", "😴"].map((emoji, i) => (
          <div key={i} className="bg-gray-800/50 rounded p-1 text-center">
            <span className="text-xs">{emoji}</span>
          </div>
        ))}
      </div>
    </div>
  );
}