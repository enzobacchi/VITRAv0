import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Droplets, Plus, Minus } from "lucide-react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export function WaterTracker() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch water intake for today
  const { data: waterData = { intake: 0, goal: 8 } } = useQuery({
    queryKey: ["/api/water/daily"],
    staleTime: 5000,
  });

  // Add water mutation
  const addWaterMutation = useMutation({
    mutationFn: async (cups: number) => {
      const response = await apiRequest("POST", "/api/water/log", {
        cups,
        loggedAt: new Date().toISOString(),
        loggedDate: new Date().toISOString().split('T')[0],
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/water/daily"] });
      toast({ title: "Success", description: "Water intake updated" });
    },
  });

  const percentage = Math.min(100, (waterData.intake / waterData.goal) * 100);

  const addWater = (amount: number) => {
    addWaterMutation.mutate(amount);
  };

  return (
    <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-base font-medium text-white uppercase tracking-wide">WATER</h3>
        <Droplets className="w-5 h-5 text-blue-400" />
      </div>

      <div className="text-center mb-4">
        <div className="text-4xl font-light text-white mb-2">
          {Math.round(waterData.intake * 10) / 10}
        </div>
        <div className="text-sm text-gray-400 mb-4">
          of {waterData.goal} cups goal
        </div>
        
        {/* Progress bar */}
        <div className="w-full bg-gray-800 rounded-full h-3 mb-2">
          <div 
            className="bg-blue-400 h-3 rounded-full transition-all duration-500" 
            style={{ width: `${Math.min(100, percentage)}%` }}
          ></div>
        </div>
        <div className="text-xs text-gray-500">
          {Math.round(percentage)}% of daily goal
        </div>
      </div>

      {/* Quick add buttons */}
      <div className="grid grid-cols-3 gap-2">
        <Button
          onClick={() => addWater(0.5)}
          disabled={addWaterMutation.isPending}
          variant="outline"
          size="sm"
          className="bg-gray-800 border-gray-700 text-white hover:bg-gray-700"
        >
          +0.5
        </Button>
        <Button
          onClick={() => addWater(1)}
          disabled={addWaterMutation.isPending}
          variant="outline"
          size="sm"
          className="bg-gray-800 border-gray-700 text-white hover:bg-gray-700"
        >
          +1
        </Button>
        <Button
          onClick={() => addWater(2)}
          disabled={addWaterMutation.isPending}
          variant="outline"
          size="sm"
          className="bg-gray-800 border-gray-700 text-white hover:bg-gray-700"
        >
          +2
        </Button>
      </div>
    </div>
  );
}