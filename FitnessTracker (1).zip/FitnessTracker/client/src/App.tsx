import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/ThemeProvider";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";

// Pages
import Landing from "@/pages/Landing";
import Home from "@/pages/Home";
import Onboarding from "@/pages/Onboarding";
import Workouts from "@/pages/Workouts";
import Nutrition from "@/pages/Nutrition";
import Calories from "@/pages/Calories";
import Progress from "@/pages/Progress";
import Profile from "@/pages/Profile";
import Coach from "@/pages/Coach";
import NotFound from "@/pages/not-found";

function Router() {
  const { isAuthenticated, isLoading } = useAuth();

  // Check if user has completed onboarding
  const { data: profile } = useQuery({
    queryKey: ["/api/profile"],
    enabled: isAuthenticated,
    retry: false,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <Switch>
      {!isAuthenticated ? (
        <Route path="/" component={Landing} />
      ) : (
        <>
          {/* If user is authenticated but hasn't completed onboarding */}
          {!profile ? (
            <Route path="/" component={Onboarding} />
          ) : (
            <>
              {/* Main app routes */}
              <Route path="/">
                <ProtectedRoute>
                  <Home />
                </ProtectedRoute>
              </Route>
              <Route path="/workouts">
                <ProtectedRoute>
                  <Workouts />
                </ProtectedRoute>
              </Route>
              <Route path="/nutrition">
                <ProtectedRoute>
                  <Nutrition />
                </ProtectedRoute>
              </Route>
              <Route path="/calories">
                <ProtectedRoute>
                  <Calories />
                </ProtectedRoute>
              </Route>
              <Route path="/progress">
                <ProtectedRoute>
                  <Progress />
                </ProtectedRoute>
              </Route>
              <Route path="/profile">
                <ProtectedRoute>
                  <Profile />
                </ProtectedRoute>
              </Route>
              <Route path="/coach">
                <ProtectedRoute>
                  <Coach />
                </ProtectedRoute>
              </Route>
              <Route path="/onboarding" component={Onboarding} />
            </>
          )}
        </>
      )}
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
