import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { BottomNavigation } from "@/components/BottomNavigation";

export default function Workouts() {
  const [location] = useLocation();
  const [expandedDay, setExpandedDay] = useState<string | null>(null);
  const [editingDay, setEditingDay] = useState<string | null>(null);
  const [editModeDay, setEditModeDay] = useState<string | null>(null);
  const [longPressTimer, setLongPressTimer] = useState<NodeJS.Timeout | null>(null);
  const [editedWorkouts, setEditedWorkouts] = useState<Record<string, any>>({});
  const [showAllExercises, setShowAllExercises] = useState<Record<string, boolean>>({});
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Handle workout completion toggle
  const handleToggleWorkoutCompletion = (dayName: string) => {
    const today = new Date();
    const currentDay = today.getDay();
    const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const targetDay = dayNames.indexOf(dayName);
    const daysFromToday = targetDay - currentDay;
    const targetDate = new Date(today);
    targetDate.setDate(today.getDate() + daysFromToday);
    const scheduledDate = targetDate.toISOString().split('T')[0];
    
    if (Array.isArray(scheduledWorkouts)) {
      const scheduledWorkout = scheduledWorkouts.find((sw: any) => sw.scheduledDate === scheduledDate);
      if (scheduledWorkout) {
        if (scheduledWorkout.completed) {
          // Uncomplete the workout
          uncompleteWorkoutMutation.mutate({ 
            scheduledWorkoutId: scheduledWorkout.id
          });
        } else {
          // Complete the workout
          const workout = scheduledWorkout.workoutPlan;
          const estimatedDuration = workout?.duration || 45;
          completeWorkoutMutation.mutate({ 
            scheduledWorkoutId: scheduledWorkout.id, 
            duration: estimatedDuration 
          });
        }
      }
    }
  };

  // Handle URL parameters to auto-expand specific day
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const dayParam = urlParams.get('day');
    if (dayParam) {
      setExpandedDay(dayParam);
      // Scroll to the day section after a short delay
      setTimeout(() => {
        const dayElement = document.querySelector(`[data-day="${dayParam}"]`);
        if (dayElement) {
          dayElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }, 100);
    }
  }, [location]);

  // Fetch workout plans
  const { data: workoutPlans, isLoading: plansLoading } = useQuery({
    queryKey: ["/api/workouts"],
  });

  // Fetch scheduled workouts
  const { data: scheduledWorkouts } = useQuery({
    queryKey: ["/api/workouts/scheduled"],
  });

  // Complete workout mutation
  const completeWorkoutMutation = useMutation({
    mutationFn: async ({ scheduledWorkoutId, duration }: { scheduledWorkoutId: number, duration?: number }) => {
      const response = await fetch(`/api/workouts/scheduled/${scheduledWorkoutId}/complete`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ duration }),
      });
      if (!response.ok) throw new Error('Failed to complete workout');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workouts/scheduled"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Workout Completed!",
        description: "Great job finishing your workout",
      });
    },
  });

  // Uncomplete workout mutation
  const uncompleteWorkoutMutation = useMutation({
    mutationFn: async ({ scheduledWorkoutId }: { scheduledWorkoutId: number }) => {
      const response = await fetch(`/api/workouts/scheduled/${scheduledWorkoutId}/uncomplete`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      });
      if (!response.ok) throw new Error('Failed to uncomplete workout');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workouts/scheduled"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Workout Marked Incomplete",
        description: "Workout status has been updated",
      });
    },
  });

  // Get current week's days
  const getWeekDays = () => {
    const today = new Date();
    const startOfWeek = new Date(today);
    startOfWeek.setDate(today.getDate() - today.getDay()); // Start from Sunday
    
    const days = [];
    for (let i = 0; i < 7; i++) {
      const day = new Date(startOfWeek);
      day.setDate(startOfWeek.getDate() + i);
      days.push({
        name: day.toLocaleDateString('en-US', { weekday: 'long' }),
        date: day.toISOString().split('T')[0],
        shortName: day.toLocaleDateString('en-US', { weekday: 'short' })
      });
    }
    return days;
  };

  const weekDays = getWeekDays();

  // Update workout mutation
  const updateWorkoutMutation = useMutation({
    mutationFn: async ({ workoutId, updates }: { workoutId: string; updates: any }) => {
      const response = await apiRequest("PUT", `/api/workouts/${workoutId}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workouts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Success",
        description: "Workout updated successfully"
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: isUnauthorizedError(error) ? "Please log in again" : "Failed to update workout"
      });
    }
  });

  // Generate AI workout mutation
  const generateWorkoutMutation = useMutation({
    mutationFn: async (preferences: any) => {
      const response = await apiRequest("POST", "/api/ai/generate-workout", { preferences });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Workout Generated",
        description: "Your AI-powered workout has been created!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/workouts"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to generate workout",
        variant: "destructive",
      });
    },
  });

  const handleGenerateWorkout = () => {
    const preferences = {
      duration: 45,
      focusArea: "full_body",
      equipment: "gym",
      difficulty: "intermediate"
    };
    generateWorkoutMutation.mutate(preferences);
  };

  const toggleDayExpansion = (dayName: string) => {
    setExpandedDay(expandedDay === dayName ? null : dayName);
  };

  const toggleShowAllExercises = (dayName: string) => {
    setShowAllExercises(prev => ({
      ...prev,
      [dayName]: !prev[dayName]
    }));
  };

  const removeExercise = (dayName: string, exerciseIndex: number) => {
    setEditedWorkouts(prev => {
      const currentWorkout = prev[dayName] || getWorkoutForDay(dayName);
      if (!currentWorkout) return prev;
      
      const updatedExercises = currentWorkout.exercises.filter((_: any, index: number) => index !== exerciseIndex);
      
      return {
        ...prev,
        [dayName]: {
          ...currentWorkout,
          exercises: updatedExercises
        }
      };
    });
  };

  const handleLongPressStart = (dayName: string) => {
    const timer = setTimeout(() => {
      setEditingDay(dayName);
    }, 800); // 800ms long press
    setLongPressTimer(timer);
  };

  const handleLongPressEnd = () => {
    if (longPressTimer) {
      clearTimeout(longPressTimer);
      setLongPressTimer(null);
    }
  };

  const handleEditWorkout = (dayName: string) => {
    setEditingDay(null);
    setEditModeDay(dayName);
    setExpandedDay(null); // Close any expanded view
  };

  const handleCancelEdit = () => {
    setEditingDay(null);
    setEditModeDay(null);
  };

  const handleSaveWorkout = (dayName: string) => {
    const workout = getWorkoutForDay(dayName);
    if (!workout) return;

    // Collect form data from the edit form
    const editForm = document.querySelector(`[data-edit-day="${dayName}"]`) as HTMLElement;
    
    if (editForm) {
      const nameInput = editForm.querySelector('input[data-field="name"]') as HTMLInputElement;
      const durationInput = editForm.querySelector('input[data-field="duration"]') as HTMLInputElement;
      
      const updates = {
        name: nameInput?.value || workout.name,
        duration: parseInt(durationInput?.value) || workout.duration,
        exercises: workout.exercises
      };

      updateWorkoutMutation.mutate({
        workoutId: workout.id,
        updates
      });
    }
    
    setEditModeDay(null);
  };

  // Get workout for any day based on scheduled workouts
  const getWorkoutForDay = (dayName: string) => {
    if (!Array.isArray(workoutPlans) || workoutPlans.length === 0) return null;
    
    // Calculate date for this day in the current week
    const today = new Date();
    const currentDay = today.getDay();
    const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const targetDay = dayNames.indexOf(dayName);
    const daysFromToday = targetDay - currentDay;
    const targetDate = new Date(today);
    targetDate.setDate(today.getDate() + daysFromToday);
    const scheduledDate = targetDate.toISOString().split('T')[0];
    
    // Find workout assigned to this specific date
    if (Array.isArray(scheduledWorkouts)) {
      const scheduledWorkout = scheduledWorkouts.find((sw: any) => sw.scheduledDate === scheduledDate);
      return scheduledWorkout?.workoutPlan || null;
    }
    
    return null;
  };

  // Get scheduled workout data for completion status
  const getScheduledWorkoutForDay = (dayName: string) => {
    const today = new Date();
    const currentDay = today.getDay();
    const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const targetDay = dayNames.indexOf(dayName);
    const daysFromToday = targetDay - currentDay;
    const targetDate = new Date(today);
    targetDate.setDate(today.getDate() + daysFromToday);
    const scheduledDate = targetDate.toISOString().split('T')[0];
    
    if (Array.isArray(scheduledWorkouts)) {
      return scheduledWorkouts.find((sw: any) => sw.scheduledDate === scheduledDate);
    }
    return null;
  };

  if (plansLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-gray-900 via-gray-800 to-gray-900">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-teal-400"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black text-white">
      {/* Sticky Header */}
      <div className="sticky top-0 z-50 bg-gray-900/80 backdrop-blur-md border-b border-gray-800/50">
        <div className="px-6 py-4 pt-[6px] pb-[6px]">
          <div className="flex items-center justify-between">
            {/* Empty space for balance */}
            <div className="w-10"></div>
            
            {/* App Name - Centered */}
            <h1 className="text-2xl font-light text-white tracking-wider uppercase">
              VITRA
            </h1>
            
            {/* Empty space for balance */}
            <div className="w-10"></div>
          </div>
        </div>
      </div>
      
      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 py-6 pb-32 space-y-6">
        <h2 className="text-xl font-semibold text-white mb-6">This Week's Schedule</h2>
        
        {/* Weekly Workout Dropdown */}
        <div className="space-y-3">
          {weekDays.map((day) => {
            const workout = getWorkoutForDay(day.name);
            const scheduledWorkout = getScheduledWorkoutForDay(day.name);
            const isExpanded = expandedDay === day.name;
            const hasWorkout = workout !== null;
            const isCompleted = scheduledWorkout?.completed || false;
            
            return (
              <div key={day.name} data-day={day.name} className="bg-gray-900 border border-gray-800 rounded-2xl overflow-hidden relative">
                <button
                  onClick={() => hasWorkout && !editModeDay && toggleDayExpansion(day.name)}
                  onMouseDown={() => handleLongPressStart(day.name)}
                  onMouseUp={handleLongPressEnd}
                  onMouseLeave={handleLongPressEnd}
                  onTouchStart={() => handleLongPressStart(day.name)}
                  onTouchEnd={handleLongPressEnd}
                  className={`w-full p-4 text-left flex items-center justify-between transition-colors hover:bg-gray-700/30 ${editingDay === day.name ? 'ring-2 ring-teal-400' : ''} ${editModeDay === day.name ? 'ring-2 ring-blue-400' : ''}`}
                >
                  <div className="flex items-center space-x-4">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center relative ${
                      isCompleted ? 'bg-teal-500/20' : hasWorkout ? 'bg-teal-500/20' : 'bg-gray-700/50'
                    }`}>
                      {isCompleted ? (
                        <i className="fas fa-check text-teal-400 text-lg"></i>
                      ) : (
                        <span className={`text-sm font-medium ${
                          hasWorkout ? 'text-teal-400' : 'text-gray-400'
                        }`}>
                          {day.shortName}
                        </span>
                      )}
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white">{day.name}</h3>
                      <p className="text-sm text-gray-400">
                        {hasWorkout ? workout.name : 'Rest Day'}
                      </p>
                    </div>
                  </div>
                  
                  {hasWorkout && (
                    <div className="flex items-center space-x-2">
                      <Badge className="bg-teal-500/20 text-teal-400 border-teal-500/30">
                        {workout.duration || 45} min
                      </Badge>
                      <i className={`fas fa-chevron-${isExpanded ? 'up' : 'down'} text-gray-400`}></i>
                    </div>
                  )}
                </button>

                {/* Unified Edit Options Overlay */}
                {editingDay === day.name && (
                  <div className="absolute inset-0 bg-gray-900/90 backdrop-blur-sm flex items-center justify-center z-10">
                    <div className="flex items-center space-x-3">
                      <button
                        onClick={() => handleEditWorkout(day.name)}
                        className="bg-teal-500 text-gray-900 px-4 py-2 rounded-full text-sm font-medium hover:bg-teal-400 transition-colors"
                      >
                        <i className="fas fa-edit mr-2"></i>
                        Edit
                      </button>
                      <button
                        onClick={handleCancelEdit}
                        className="bg-gray-600 text-white px-4 py-2 rounded-full text-sm font-medium hover:bg-gray-500 transition-colors"
                      >
                        <i className="fas fa-times mr-2"></i>
                        Cancel
                      </button>
                    </div>
                  </div>
                )}
                
                {/* Manual Edit Mode */}
                {editModeDay === day.name && (
                  <div className="p-4 border-t border-gray-700/50 bg-gray-800/30" data-edit-day={day.name}>
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="text-white font-medium">Edit {day.name} Workout</h4>
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => handleSaveWorkout(day.name)}
                          className="bg-teal-500 text-gray-900 px-3 py-1 rounded-full text-xs font-medium hover:bg-teal-400 transition-colors"
                        >
                          Save
                        </button>
                        <button
                          onClick={handleCancelEdit}
                          className="bg-gray-600 text-white px-3 py-1 rounded-full text-xs font-medium hover:bg-gray-500 transition-colors"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                    
                    {hasWorkout && (
                      <div className="space-y-3">
                        {/* Workout Name Editor */}
                        <div className="flex items-center space-x-3">
                          <label className="text-gray-300 text-sm w-16">Name:</label>
                          <input
                            type="text"
                            defaultValue={workout.name}
                            data-field="name"
                            className="bg-gray-700 text-white px-3 py-1 rounded-lg text-sm flex-1"
                            placeholder="Workout name"
                          />
                        </div>
                        
                        {/* Duration Editor */}
                        <div className="flex items-center space-x-3">
                          <label className="text-gray-300 text-sm w-16">Duration:</label>
                          <input
                            type="number"
                            defaultValue={workout.duration}
                            data-field="duration"
                            className="bg-gray-700 text-white px-3 py-1 rounded-lg text-sm w-20"
                            min="1"
                            max="180"
                          />
                          <span className="text-gray-400 text-sm">minutes</span>
                        </div>
                        
                        {/* Exercises Editor */}
                        <div>
                          <label className="text-gray-300 text-sm block mb-2">Exercises:</label>
                          <div className="space-y-2">
                            {workout.exercises.map((exercise: any, index: number) => (
                              <div key={index} className="bg-gray-700/50 p-3 rounded-lg">
                                <div className="flex items-center justify-between mb-2">
                                  <input
                                    type="text"
                                    defaultValue={exercise.name}
                                    className="bg-gray-700 text-white px-2 py-1 rounded text-sm flex-1 mr-2"
                                  />
                                  <button 
                                    onClick={() => removeExercise(day.name, index)}
                                    className="text-red-400 hover:text-red-300 text-xs"
                                  >
                                    <i className="fas fa-trash"></i>
                                  </button>
                                </div>
                                <div className="grid grid-cols-3 gap-2 text-xs">
                                  <div>
                                    <label className="text-gray-400 block">Sets</label>
                                    <input
                                      type="number"
                                      defaultValue={exercise.sets}
                                      className="bg-gray-700 text-white px-2 py-1 rounded w-full"
                                      min="1"
                                    />
                                  </div>
                                  <div>
                                    <label className="text-gray-400 block">Reps</label>
                                    <input
                                      type="text"
                                      defaultValue={exercise.reps}
                                      className="bg-gray-700 text-white px-2 py-1 rounded w-full"
                                    />
                                  </div>
                                  <div>
                                    <label className="text-gray-400 block">Rest (s)</label>
                                    <input
                                      type="number"
                                      defaultValue={exercise.restTime}
                                      className="bg-gray-700 text-white px-2 py-1 rounded w-full"
                                      min="30"
                                    />
                                  </div>
                                </div>
                              </div>
                            ))}
                            <button className="w-full border-2 border-dashed border-gray-600 hover:border-gray-500 text-gray-400 hover:text-gray-300 py-3 rounded-lg text-sm transition-colors">
                              <i className="fas fa-plus mr-2"></i>
                              Add Exercise
                            </button>
                          </div>
                        </div>
                      </div>
                    )}
                    
                    {/* Rest Day Editor */}
                    {!hasWorkout && (
                      <div className="text-center py-8">
                        <div className="text-gray-400 mb-4">
                          <i className="fas fa-plus-circle text-3xl"></i>
                        </div>
                        <p className="text-gray-400 mb-4">This is a rest day</p>
                        <button className="bg-teal-500 text-gray-900 px-4 py-2 rounded-full text-sm font-medium hover:bg-teal-400 transition-colors">
                          Add Workout
                        </button>
                      </div>
                    )}
                  </div>
                )}
                
                {/* Expanded Workout Details */}
                {isExpanded && hasWorkout && !editModeDay && (
                  <div className="border-t border-gray-700/50 p-4 bg-gray-700/20">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <h4 className="font-semibold text-white">Workout Details</h4>
                        {isCompleted ? (
                          <button 
                            onClick={() => handleToggleWorkoutCompletion(day.name)}
                            disabled={uncompleteWorkoutMutation.isPending}
                            className="flex items-center space-x-2 bg-gray-700/50 hover:bg-gray-600/50 px-3 py-1 rounded-full transition-colors disabled:opacity-50"
                          >
                            <i className="fas fa-check text-teal-400"></i>
                            <span className="text-teal-400 text-sm font-medium">
                              {uncompleteWorkoutMutation.isPending ? 'Updating...' : 'Completed'}
                            </span>
                          </button>
                        ) : (
                          <button 
                            onClick={() => handleToggleWorkoutCompletion(day.name)}
                            disabled={completeWorkoutMutation.isPending || uncompleteWorkoutMutation.isPending}
                            className="bg-teal-500 text-gray-900 px-4 py-2 rounded-full text-sm font-medium hover:bg-teal-400 transition-colors disabled:opacity-50"
                          >
                            {(completeWorkoutMutation.isPending || uncompleteWorkoutMutation.isPending) ? (
                              <>
                                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-900 mr-2 inline-block"></div>
                                {completeWorkoutMutation.isPending ? 'Completing...' : 'Updating...'}
                              </>
                            ) : (
                              <>
                                <i className="fas fa-check mr-2"></i>
                                Mark Complete
                              </>
                            )}
                          </button>
                        )}
                      </div>
                      
                      <div className="text-sm">
                        <span className="text-gray-400">Duration:</span>
                        <p className="text-white font-medium">{workout.duration || 45} minutes</p>
                      </div>
                      
                      {workout.exercises && (
                        <div>
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-gray-400 text-sm">Exercises ({workout.exercises.length}):</span>
                            {workout.exercises.length > 3 && (
                              <button
                                onClick={() => toggleShowAllExercises(day.name)}
                                className="text-teal-400 text-xs hover:text-teal-300 transition-colors"
                              >
                                {showAllExercises[day.name] ? 'Show Less' : `Show All (${workout.exercises.length})`}
                              </button>
                            )}
                          </div>
                          <div className="mt-2 space-y-2">
                            {(showAllExercises[day.name] ? workout.exercises : workout.exercises.slice(0, 3)).map((exercise: any, index: number) => (
                              <div key={index} className="flex items-center justify-between bg-gray-800/50 p-3 rounded-lg">
                                <span className="text-white font-medium">{exercise.name}</span>
                                <span className="text-gray-400 text-sm">
                                  {exercise.sets}x{exercise.reps}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* No Workouts Message */}
        {(!Array.isArray(workoutPlans) || workoutPlans.length === 0) && (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-700/50 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-dumbbell text-gray-400 text-xl"></i>
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">No Workouts Yet</h3>
            <p className="text-gray-400 mb-6">Generate your first AI-powered workout to get started</p>
            <button
              onClick={handleGenerateWorkout}
              disabled={generateWorkoutMutation.isPending}
              className="bg-teal-500 text-gray-900 px-6 py-3 rounded-full font-medium hover:bg-teal-400 transition-colors disabled:opacity-50"
            >
              {generateWorkoutMutation.isPending ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-gray-900 mr-2 inline-block"></div>
                  Generating...
                </>
              ) : (
                <>
                  <i className="fas fa-robot mr-2"></i>
                  Generate First Workout
                </>
              )}
            </button>
          </div>
        )}
      </div>
      <BottomNavigation />
    </div>
  );
}