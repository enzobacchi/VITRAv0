import React, { useState, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { BottomNavigation } from "@/components/BottomNavigation";
import { User, Settings, Target, ChevronRight, Camera, Upload } from "lucide-react";

// Account schema for basic account info
const accountSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  email: z.string().email("Invalid email address"),
});

// AI-focused profile schema - only metrics that inform AI recommendations
const aiProfileSchema = z.object({
  age: z.number().min(13, "Must be at least 13 years old").max(120),
  gender: z.string().min(1, "Gender is required"),
  activityLevel: z.string().min(1, "Activity level is required"),
  fitnessGoals: z.array(z.string()).min(1, "At least one fitness goal is required"),
  dietaryPreferences: z.array(z.string()).optional(),
  targetCalories: z.number().min(1000, "Minimum 1000 calories").max(5000, "Maximum 5000 calories"),
  targetProtein: z.number().min(50, "Minimum 50g protein").max(300, "Maximum 300g protein"),
  targetCarbs: z.number().min(50, "Minimum 50g carbs").max(500, "Maximum 500g carbs"),
  targetFats: z.number().min(20, "Minimum 20g fats").max(200, "Maximum 200g fats"),
});

type AccountForm = z.infer<typeof accountSchema>;
type AIProfileForm = z.infer<typeof aiProfileSchema>;

export default function Profile() {
  const [activeTab, setActiveTab] = useState("account");
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Profile photo upload state
  const [profilePhoto, setProfilePhoto] = useState<string>("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Fetch user profile
  const { data: profile, isLoading: profileLoading } = useQuery({
    queryKey: ["/api/profile"],
    enabled: !!user,
  });

  // Update profile photo when user data changes
  React.useEffect(() => {
    if (user && (user as any).profileImageUrl) {
      setProfilePhoto((user as any).profileImageUrl);
    }
  }, [user]);

  // Account form - using safe data access
  const accountForm = useForm<AccountForm>({
    resolver: zodResolver(accountSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
    },
  });

  // Update account form when user data loads
  React.useEffect(() => {
    if (user) {
      const userData = user as any;
      accountForm.reset({
        firstName: userData.firstName || "",
        lastName: userData.lastName || "",
        email: userData.email || "",
      });
    }
  }, [user, accountForm]);

  // AI Profile form - consolidated form for AI-relevant metrics
  const aiProfileForm = useForm<AIProfileForm>({
    resolver: zodResolver(aiProfileSchema),
    defaultValues: {
      age: 25,
      gender: "",
      activityLevel: "",
      fitnessGoals: [],
      dietaryPreferences: [],
      targetCalories: 2100,
      targetProtein: 150,
      targetCarbs: 250,
      targetFats: 70,
    },
  });

  // Update AI profile form when profile data loads
  React.useEffect(() => {
    if (profile) {
      const profileData = profile as any;
      aiProfileForm.reset({
        age: profileData.age || 25,
        gender: profileData.gender || "",
        activityLevel: profileData.activityLevel || "",
        fitnessGoals: profileData.fitnessGoals || [],
        dietaryPreferences: profileData.dietaryPreferences || [],
        targetCalories: profileData.targetCalories || 2100,
        targetProtein: profileData.targetProtein || 150,
        targetCarbs: profileData.targetCarbs || 250,
        targetFats: profileData.targetFats || 70,
      });
    }
  }, [profile, aiProfileForm]);

  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data: AIProfileForm) => {
      const response = await fetch("/api/profile", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
      
      if (!response.ok) {
        throw new Error("Failed to update profile");
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Profile Updated",
        description: "Your AI profile has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update profile",
        variant: "destructive",
      });
    },
  });

  // Photo upload mutation
  const uploadPhotoMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("photo", file);
      
      const response = await fetch("/api/profile/photo", {
        method: "POST",
        body: formData,
      });
      
      if (!response.ok) {
        throw new Error("Failed to upload photo");
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      setProfilePhoto(data.profileImageUrl);
      toast({
        title: "Photo Uploaded",
        description: "Your profile photo has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
    },
    onError: (error: any) => {
      toast({
        title: "Upload Failed",
        description: error.message || "Failed to upload photo",
        variant: "destructive",
      });
    },
  });

  const onSubmitProfile = (data: AIProfileForm) => {
    updateProfileMutation.mutate(data);
  };

  const handlePhotoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        toast({
          title: "File Too Large",
          description: "Please select a photo smaller than 5MB",
          variant: "destructive",
        });
        return;
      }
      uploadPhotoMutation.mutate(file);
    }
  };

  const triggerPhotoUpload = () => {
    fileInputRef.current?.click();
  };

  const fitnessGoalOptions = [
    "Weight Loss",
    "Muscle Gain",
    "Strength Training",
    "Endurance",
    "General Fitness",
    "Athletic Performance",
    "Flexibility",
    "Recovery"
  ];

  const dietaryPreferenceOptions = [
    "Vegetarian",
    "Vegan",
    "Keto",
    "Paleo",
    "Mediterranean",
    "Low Carb",
    "High Protein",
    "Gluten Free",
    "Dairy Free"
  ];

  if (profileLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black flex items-center justify-center">
        <div className="text-white">Loading profile...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black">
      {/* Sticky Header */}
      <div className="sticky top-0 z-50 bg-gray-900/80 backdrop-blur-md border-b border-gray-800/50">
        <div className="px-6 py-4 pt-[6px] pb-[6px]">
          <div className="flex items-center justify-between">
            {/* Empty space for balance */}
            <div className="w-10"></div>
            
            {/* App Name - Centered */}
            <h1 className="font-light text-white tracking-wider text-[22px]">
              VITRA
            </h1>
            
            {/* Empty space for balance */}
            <div className="w-10"></div>
          </div>
        </div>
      </div>
      <div className="px-6 py-6 pb-24">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 bg-gray-800/50 border border-gray-700">
            <TabsTrigger value="account" className="data-[state=active]:bg-gray-700">
              Account
            </TabsTrigger>
            <TabsTrigger value="ai-profile" className="data-[state=active]:bg-gray-700">
              AI Profile
            </TabsTrigger>
          </TabsList>

          {/* Account Tab */}
          <TabsContent value="account" className="space-y-6">
            <Card className="bg-gray-800/50 border-gray-700/50">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <User className="w-5 h-5 text-teal-400" />
                  <CardTitle className="text-white">Account Information</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Profile Photo */}
                <div className="flex flex-col items-center space-y-4">
                  <div className="relative">
                    <div className="w-24 h-24 rounded-full bg-gray-700 border-2 border-gray-600 overflow-hidden">
                      {profilePhoto ? (
                        <img
                          src={profilePhoto}
                          alt="Profile"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <User className="w-8 h-8 text-gray-400" />
                        </div>
                      )}
                    </div>
                    <button
                      onClick={triggerPhotoUpload}
                      disabled={uploadPhotoMutation.isPending}
                      className="absolute -bottom-2 -right-2 w-8 h-8 bg-teal-500 hover:bg-teal-400 rounded-full flex items-center justify-center text-gray-900 transition-colors"
                    >
                      {uploadPhotoMutation.isPending ? (
                        <div className="w-4 h-4 border-2 border-gray-900 border-t-transparent rounded-full animate-spin" />
                      ) : (
                        <Camera className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoUpload}
                    className="hidden"
                  />
                </div>

                {/* Account Details */}
                <div className="text-center space-y-2">
                  <h3 className="text-lg font-semibold text-white">
                    {(user as any)?.firstName} {(user as any)?.lastName}
                  </h3>
                  <p className="text-gray-400">{(user as any)?.email}</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* AI Profile Tab */}
          <TabsContent value="ai-profile" className="space-y-6">
            <Card className="bg-gray-800/50 border-gray-700/50">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <Target className="w-5 h-5 text-teal-400" />
                  <CardTitle className="text-white">AI Training Profile</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <Form {...aiProfileForm}>
                  <form onSubmit={aiProfileForm.handleSubmit(onSubmitProfile)} className="space-y-6">
                    {/* Basic Info */}
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={aiProfileForm.control}
                        name="age"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-300">Age</FormLabel>
                            <FormControl>
                              <Input
                                type="number"
                                {...field}
                                onChange={(e) => field.onChange(parseInt(e.target.value))}
                                className="bg-gray-700 border-gray-600 text-white"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={aiProfileForm.control}
                        name="gender"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-300">Gender</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                                  <SelectValue placeholder="Select gender" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="male">Male</SelectItem>
                                <SelectItem value="female">Female</SelectItem>
                                <SelectItem value="other">Other</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    {/* Activity Level */}
                    <FormField
                      control={aiProfileForm.control}
                      name="activityLevel"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-300">Activity Level</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                                <SelectValue placeholder="Select activity level" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="sedentary">Sedentary (Little/no exercise)</SelectItem>
                              <SelectItem value="lightly_active">Lightly Active (Light exercise 1-3 days/week)</SelectItem>
                              <SelectItem value="moderately_active">Moderately Active (Moderate exercise 3-5 days/week)</SelectItem>
                              <SelectItem value="very_active">Very Active (Hard exercise 6-7 days/week)</SelectItem>
                              <SelectItem value="extremely_active">Extremely Active (Very hard exercise/physical job)</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Fitness Goals */}
                    <FormField
                      control={aiProfileForm.control}
                      name="fitnessGoals"
                      render={() => (
                        <FormItem>
                          <FormLabel className="text-gray-300">Fitness Goals (AI Training Focus)</FormLabel>
                          <div className="grid grid-cols-2 gap-3">
                            {fitnessGoalOptions.map((goal) => (
                              <FormField
                                key={goal}
                                control={aiProfileForm.control}
                                name="fitnessGoals"
                                render={({ field }) => {
                                  return (
                                    <FormItem
                                      key={goal}
                                      className="flex flex-row items-start space-x-3 space-y-0"
                                    >
                                      <FormControl>
                                        <Checkbox
                                          checked={field.value?.includes(goal)}
                                          onCheckedChange={(checked) => {
                                            return checked
                                              ? field.onChange([...field.value, goal])
                                              : field.onChange(
                                                  field.value?.filter((value) => value !== goal)
                                                );
                                          }}
                                        />
                                      </FormControl>
                                      <FormLabel className="text-sm text-gray-300 font-normal">
                                        {goal}
                                      </FormLabel>
                                    </FormItem>
                                  );
                                }}
                              />
                            ))}
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Dietary Preferences */}
                    <FormField
                      control={aiProfileForm.control}
                      name="dietaryPreferences"
                      render={() => (
                        <FormItem>
                          <FormLabel className="text-gray-300">Dietary Preferences (AI Nutrition Focus)</FormLabel>
                          <div className="grid grid-cols-2 gap-3">
                            {dietaryPreferenceOptions.map((preference) => (
                              <FormField
                                key={preference}
                                control={aiProfileForm.control}
                                name="dietaryPreferences"
                                render={({ field }) => {
                                  return (
                                    <FormItem
                                      key={preference}
                                      className="flex flex-row items-start space-x-3 space-y-0"
                                    >
                                      <FormControl>
                                        <Checkbox
                                          checked={field.value?.includes(preference)}
                                          onCheckedChange={(checked) => {
                                            return checked
                                              ? field.onChange([...(field.value || []), preference])
                                              : field.onChange(
                                                  field.value?.filter((value) => value !== preference)
                                                );
                                          }}
                                        />
                                      </FormControl>
                                      <FormLabel className="text-sm text-gray-300 font-normal">
                                        {preference}
                                      </FormLabel>
                                    </FormItem>
                                  );
                                }}
                              />
                            ))}
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Nutrition Targets */}
                    <div className="space-y-4">
                      <h4 className="text-lg font-semibold text-white">AI Nutrition Targets</h4>
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={aiProfileForm.control}
                          name="targetCalories"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-gray-300">Daily Calories</FormLabel>
                              <FormControl>
                                <Input
                                  type="number"
                                  {...field}
                                  onChange={(e) => field.onChange(parseInt(e.target.value))}
                                  className="bg-gray-700 border-gray-600 text-white"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={aiProfileForm.control}
                          name="targetProtein"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-gray-300">Protein (g)</FormLabel>
                              <FormControl>
                                <Input
                                  type="number"
                                  {...field}
                                  onChange={(e) => field.onChange(parseInt(e.target.value))}
                                  className="bg-gray-700 border-gray-600 text-white"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={aiProfileForm.control}
                          name="targetCarbs"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-gray-300">Carbs (g)</FormLabel>
                              <FormControl>
                                <Input
                                  type="number"
                                  {...field}
                                  onChange={(e) => field.onChange(parseInt(e.target.value))}
                                  className="bg-gray-700 border-gray-600 text-white"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={aiProfileForm.control}
                          name="targetFats"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-gray-300">Fats (g)</FormLabel>
                              <FormControl>
                                <Input
                                  type="number"
                                  {...field}
                                  onChange={(e) => field.onChange(parseInt(e.target.value))}
                                  className="bg-gray-700 border-gray-600 text-white"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>

                    <Button
                      type="submit"
                      disabled={updateProfileMutation.isPending}
                      className="w-full bg-gray-700 hover:bg-gray-600 text-white border border-gray-600 hover:border-gray-500 transition-colors"
                    >
                      {updateProfileMutation.isPending ? "Updating AI Profile..." : "Update AI Profile"}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
      <BottomNavigation />
    </div>
  );
}