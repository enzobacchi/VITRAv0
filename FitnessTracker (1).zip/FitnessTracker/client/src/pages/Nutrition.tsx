import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { BottomNavigation } from "@/components/BottomNavigation";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { MacroRing } from "@/components/MacroRing";
import { Apple, Pill, Droplets, ChevronRight, Plus } from "lucide-react";

export default function Nutrition() {
  const [activeTab, setActiveTab] = useState(0);
  const [isAddFoodOpen, setIsAddFoodOpen] = useState(false);
  const [macrosModalOpen, setMacrosModalOpen] = useState(false);
  const [waterIntake, setWaterIntake] = useState(0);
  const [proteinTarget, setProteinTarget] = useState(150);
  const [carbsTarget, setCarbsTarget] = useState(250);
  const [fatsTarget, setFatsTarget] = useState(70);
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch daily nutrition stats
  const { data: dailyNutrition = {}, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/nutrition/daily-stats"],
    refetchInterval: 10000, // Reduced frequency for better performance
    staleTime: 5000, // Allow 5 second cache
  });

  // Fetch food logs
  const { data: foodLogs = [], isLoading: logsLoading } = useQuery({
    queryKey: ["/api/nutrition/logs"],
    refetchInterval: 10000, // Reduced frequency
    staleTime: 5000, // Allow 5 second cache
  });

  // Calculate macro percentages
  const proteinPercentage = dailyNutrition.targetProtein ? (dailyNutrition.protein / dailyNutrition.targetProtein) * 100 : 0;
  const carbsPercentage = dailyNutrition.targetCarbs ? (dailyNutrition.carbs / dailyNutrition.targetCarbs) * 100 : 0;
  const fatsPercentage = dailyNutrition.targetFats ? (dailyNutrition.fats / dailyNutrition.targetFats) * 100 : 0;

  // Update macros target mutation
  const updateMacrosMutation = useMutation({
    mutationFn: async (macros: { targetProtein: number; targetCarbs: number; targetFats: number }) => {
      const response = await apiRequest("POST", "/api/profile", macros);
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Success", description: "Macro targets updated successfully" });
      queryClient.invalidateQueries({ queryKey: ["/api/nutrition/daily-stats"] });
      setMacrosModalOpen(false);
    },
  });

  const tabs = [
    { name: 'Food', icon: Apple },
    { name: 'Supplements', icon: Pill },
    { name: 'Water', icon: Droplets }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black">
      {/* Sticky Header */}
      <div className="sticky top-0 z-50 bg-gray-900/80 backdrop-blur-md border-b border-gray-800/50">
        <div className="px-6 py-4 pt-[6px] pb-[6px]">
          <div className="flex items-center justify-between">
            {/* Empty space for balance */}
            <div className="w-10"></div>
            
            {/* App Name - Centered */}
            <h1 className="text-2xl font-light text-white tracking-wider uppercase">
              VITRA
            </h1>
            
            {/* Empty space for balance */}
            <div className="w-10"></div>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="max-w-sm mx-auto px-6 pt-4">
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-1">
          <div className="grid grid-cols-3 gap-1">
            {tabs.map((tab, index) => {
              const Icon = tab.icon;
              return (
                <button
                  key={index}
                  onClick={() => setActiveTab(index)}
                  className={`flex flex-col items-center py-3 px-2 rounded-xl transition-all duration-200 ${
                    activeTab === index
                      ? 'bg-teal-500 text-white shadow-lg'
                      : 'text-gray-400 hover:text-white hover:bg-gray-700/50'
                  }`}
                >
                  <Icon className="w-5 h-5 mb-1" />
                  <span className="text-xs font-medium">{tab.name}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Tab Content */}
      <div className="px-6 py-6 pb-32 space-y-4">
        {/* Food Tab */}
        {activeTab === 0 && (
          <>
            {/* Diary Label */}
            <div className="mb-2">
              <h2 className="text-sm font-medium text-gray-400 uppercase tracking-wider">DIARY</h2>
            </div>

            {/* Calories Widget */}
            <div 
              onClick={() => setLocation('/calories')}
              className="bg-gray-900 border border-gray-800 rounded-2xl p-6 cursor-pointer hover:bg-gray-800 transition-all duration-200"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-base font-medium text-white uppercase tracking-wide">CALORIES</h3>
                <ChevronRight className="w-5 h-5 text-gray-600" />
              </div>
              <div className="flex items-end space-x-2">
                <span className="text-6xl font-light text-white">{Math.round(dailyNutrition.calories || 0)}</span>
                <span className="text-lg text-gray-400 pb-2">of {dailyNutrition.targetCalories || 2400}</span>
              </div>
            </div>

            {/* Macros Widget */}
            <div 
              onClick={() => setMacrosModalOpen(true)}
              className="bg-gray-900 border border-gray-800 rounded-2xl p-6 cursor-pointer hover:bg-gray-800 transition-all duration-200"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-base font-medium text-white uppercase tracking-wide">MACROS</h3>
                <ChevronRight className="w-5 h-5 text-gray-600" />
              </div>
              <div className="grid grid-cols-3 gap-6">
                <div className="text-center">
                  <MacroRing percentage={proteinPercentage || 0} color="#6B7280" size={80} strokeWidth={6} />
                  <p className="text-xs text-gray-400 mt-3">Protein</p>
                  <p className="text-lg font-medium text-white">{Math.round(dailyNutrition.protein || 0)}g</p>
                </div>
                
                <div className="text-center">
                  <MacroRing percentage={carbsPercentage || 0} color="#6B7280" size={80} strokeWidth={6} />
                  <p className="text-xs text-gray-400 mt-3">Carbs</p>
                  <p className="text-lg font-medium text-white">{Math.round(dailyNutrition.carbs || 0)}g</p>
                </div>
                
                <div className="text-center">
                  <MacroRing percentage={fatsPercentage || 0} color="#6B7280" size={80} strokeWidth={6} />
                  <p className="text-xs text-gray-400 mt-3">Fats</p>
                  <p className="text-lg font-medium text-white">{Math.round(dailyNutrition.fats || 0)}g</p>
                </div>
              </div>
            </div>

            {/* Meals Widget */}
            <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6">
              <h3 className="text-base font-medium text-white uppercase tracking-wide mb-6">MEALS</h3>
              
              <div className="space-y-4">
                {/* Breakfast */}
                <div className="flex items-center justify-between py-2">
                  <span className="text-white font-medium">Breakfast</span>
                  <Button 
                    onClick={() => setIsAddFoodOpen(true)}
                    variant="ghost" 
                    className="text-blue-400 hover:text-blue-300 p-0 h-auto font-normal"
                  >
                    Add
                  </Button>
                </div>
                
                {/* Lunch */}
                <div className="flex items-center justify-between py-2">
                  <span className="text-white font-medium">Lunch</span>
                  <Button 
                    onClick={() => setIsAddFoodOpen(true)}
                    variant="ghost" 
                    className="text-blue-400 hover:text-blue-300 p-0 h-auto font-normal"
                  >
                    Add
                  </Button>
                </div>
                
                {/* Dinner */}
                <div className="flex items-center justify-between py-2">
                  <span className="text-white font-medium">Dinner</span>
                  <Button 
                    onClick={() => setIsAddFoodOpen(true)}
                    variant="ghost" 
                    className="text-blue-400 hover:text-blue-300 p-0 h-auto font-normal"
                  >
                    Add
                  </Button>
                </div>
              </div>
            </div>

            {/* Daily Food Diary */}
            {foodLogs && foodLogs.length > 0 && (
              <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6">
                <h3 className="text-base font-medium text-white uppercase tracking-wide mb-4">TODAY'S DIARY</h3>
                <div className="space-y-3">
                  {foodLogs.map((log: any) => (
                    <div key={log.id} className="bg-gray-800 border border-gray-700 rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium text-white">{log.foodName}</h4>
                          <p className="text-sm text-gray-400">
                            {log.servingSize}g • {Math.round(log.calories)} cal
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-gray-300">
                            P: {Math.round(log.protein)}g • C: {Math.round(log.carbs)}g • F: {Math.round(log.fats)}g
                          </p>
                          <p className="text-xs text-gray-500">
                            {new Date(log.loggedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}

        {/* Supplements Tab */}
        {activeTab === 1 && (
          <div className="space-y-6">
            <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6">
              <h2 className="text-xl font-semibold text-white mb-4">Supplements</h2>
              <div className="text-center py-8">
                <div className="w-16 h-16 bg-gray-700/50 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Pill className="w-8 h-8 text-gray-400" />
                </div>
                <p className="text-gray-400 mb-2">No supplements tracked</p>
                <p className="text-sm text-gray-500">Add supplements to track your intake</p>
              </div>
            </div>
          </div>
        )}

        {/* Water Tab */}
        {activeTab === 2 && (
          <div className="space-y-6">
            <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6">
              <h2 className="text-xl font-semibold text-white mb-6">Water Intake</h2>
              
              <div className="text-center mb-6">
                <div className="text-4xl font-bold text-white mb-2">{waterIntake}ml</div>
                <div className="text-gray-400">of 2000ml daily goal</div>
                <div className="w-full bg-gray-700 rounded-full h-3 mt-4">
                  <div 
                    className="bg-teal-500 h-3 rounded-full transition-all duration-300" 
                    style={{ width: `${Math.min(100, (waterIntake / 2000) * 100)}%` }}
                  ></div>
                </div>
                <div className="text-xs text-gray-500 mt-2">
                  {Math.round((waterIntake / 2000) * 100)}% complete
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-6">
                <Button 
                  onClick={() => setWaterIntake(prev => prev + 250)}
                  className="bg-teal-500 hover:bg-teal-400 text-gray-900 h-16 flex flex-col"
                >
                  <Droplets className="w-6 h-6 mb-1" />
                  <span className="text-sm">+250ml</span>
                </Button>
                <Button 
                  onClick={() => setWaterIntake(prev => prev + 500)}
                  className="bg-teal-500 hover:bg-teal-400 text-gray-900 h-16 flex flex-col"
                >
                  <Droplets className="w-6 h-6 mb-1" />
                  <span className="text-sm">+500ml</span>
                </Button>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-6">
                <Button 
                  onClick={() => setWaterIntake(prev => Math.max(0, prev - 250))}
                  variant="outline"
                  className="border-gray-600 text-gray-300 hover:bg-gray-800 h-12"
                >
                  -250ml
                </Button>
                <Button 
                  onClick={() => setWaterIntake(0)}
                  variant="outline"
                  className="border-gray-600 text-gray-300 hover:bg-gray-800 h-12"
                >
                  Reset
                </Button>
              </div>

              {waterIntake >= 2000 && (
                <div className="text-center p-4 bg-teal-500/20 border border-teal-500/30 rounded-lg">
                  <p className="text-teal-400 font-medium">Great job! You've reached your daily water goal!</p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Add Food Dialog */}
      <Dialog open={isAddFoodOpen} onOpenChange={setIsAddFoodOpen}>
        <DialogContent className="sm:max-w-md bg-gray-800 border-gray-700">
          <DialogHeader>
            <DialogTitle className="text-white">Add Food</DialogTitle>
            <DialogDescription className="text-gray-400">
              Search for food to add to your log
            </DialogDescription>
          </DialogHeader>
          <div className="text-center py-4">
            <p className="text-gray-400">Food search feature coming soon</p>
          </div>
        </DialogContent>
      </Dialog>



      {/* Macros Edit Modal */}
      <Dialog open={macrosModalOpen} onOpenChange={setMacrosModalOpen}>
        <DialogContent className="sm:max-w-sm bg-gray-900 border-gray-800 p-0 gap-0">
          <div className="p-6">
            <div className="text-center mb-6">
              <h3 className="text-base font-medium text-white uppercase tracking-wide mb-2">MACRO TARGETS</h3>
              <p className="text-xs text-gray-400">Set your daily goals</p>
            </div>
            
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-gray-800 border border-gray-700 rounded-xl p-3 text-center">
                  <Label className="text-gray-400 text-xs uppercase tracking-wide block mb-2">Protein</Label>
                  <Input
                    type="number"
                    value={proteinTarget}
                    onChange={(e) => setProteinTarget(Number(e.target.value))}
                    className="bg-transparent border-0 text-lg font-medium text-white p-0 text-center focus-visible:ring-0 focus-visible:ring-offset-0"
                    placeholder="150"
                  />
                  <span className="text-xs text-gray-500 mt-1 block">g</span>
                </div>
                
                <div className="bg-gray-800 border border-gray-700 rounded-xl p-3 text-center">
                  <Label className="text-gray-400 text-xs uppercase tracking-wide block mb-2">Carbs</Label>
                  <Input
                    type="number"
                    value={carbsTarget}
                    onChange={(e) => setCarbsTarget(Number(e.target.value))}
                    className="bg-transparent border-0 text-lg font-medium text-white p-0 text-center focus-visible:ring-0 focus-visible:ring-offset-0"
                    placeholder="250"
                  />
                  <span className="text-xs text-gray-500 mt-1 block">g</span>
                </div>
                
                <div className="bg-gray-800 border border-gray-700 rounded-xl p-3 text-center">
                  <Label className="text-gray-400 text-xs uppercase tracking-wide block mb-2">Fats</Label>
                  <Input
                    type="number"
                    value={fatsTarget}
                    onChange={(e) => setFatsTarget(Number(e.target.value))}
                    className="bg-transparent border-0 text-lg font-medium text-white p-0 text-center focus-visible:ring-0 focus-visible:ring-offset-0"
                    placeholder="70"
                  />
                  <span className="text-xs text-gray-500 mt-1 block">g</span>
                </div>
              </div>
              
              <div className="flex gap-3 mt-6">
                <Button 
                  onClick={() => setMacrosModalOpen(false)}
                  variant="outline" 
                  className="flex-1 bg-gray-800 border-gray-700 text-gray-300 hover:bg-gray-700 rounded-xl"
                >
                  Cancel
                </Button>
                <Button 
                  onClick={() => updateMacrosMutation.mutate({ 
                    targetProtein: proteinTarget, 
                    targetCarbs: carbsTarget, 
                    targetFats: fatsTarget 
                  })}
                  disabled={updateMacrosMutation.isPending}
                  className="flex-1 bg-teal-500 hover:bg-teal-600 text-gray-900 font-medium rounded-xl"
                >
                  {updateMacrosMutation.isPending ? "Saving..." : "Save"}
                </Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <BottomNavigation />
    </div>
  );
}