import { useState, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, getQueryFn } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { BottomNavigation } from "@/components/BottomNavigation";

interface Message {
  id: string;
  content: string;
  isUser: boolean;
  timestamp: Date;
  workoutPlan?: WorkoutPlan;
  weeklyWorkouts?: WeeklyWorkouts;
}

interface WorkoutPlan {
  name: string;
  description: string;
  duration: number;
  difficulty: string;
  exercises: Exercise[];
}

interface WeeklyWorkouts {
  [day: string]: WorkoutPlan;
}

interface Exercise {
  name: string;
  sets: number;
  reps: string;
  weight?: string;
  duration?: number;
  restTime: number;
  notes?: string;
}

export default function Coach() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      content: "Hi! I'm your AI fitness coach. I can help you create personalized workouts, answer questions about exercises, and provide fitness guidance. What would you like to work on today?",
      isUser: false,
      timestamp: new Date(),
    }
  ]);

  // Load chat history on component mount
  const { data: chatHistory } = useQuery({
    queryKey: ["/api/ai/chat-history"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/ai/chat-history");
      return response.json();
    },
  });

  // Initialize messages with chat history
  useEffect(() => {
    if (chatHistory && Array.isArray(chatHistory) && chatHistory.length > 0) {
      const sortedHistory = [...chatHistory].reverse();
      const formattedMessages = sortedHistory.map((chat: any) => [
        {
          id: `user-${chat.id}`,
          content: chat.message,
          isUser: true,
          timestamp: new Date(chat.createdAt),
        },
        {
          id: `ai-${chat.id}`,
          content: chat.response,
          isUser: false,
          timestamp: new Date(chat.createdAt),
          workoutPlan: chat.workoutPlan ? JSON.parse(chat.workoutPlan) : undefined,
          weeklyWorkouts: chat.weeklyWorkouts ? JSON.parse(chat.weeklyWorkouts) : undefined,
        }
      ]).flat();
      setMessages(prev => [...prev, ...formattedMessages]);
    }
  }, [chatHistory]);
  const [inputMessage, setInputMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Quick action buttons
  const quickActions = [
    { text: "Create a workout", icon: "fas fa-dumbbell", prompt: "Create a personalized workout for me" },
    { text: "Weekly plan", icon: "fas fa-calendar-week", prompt: "Create a complete 7-day weekly workout plan with different workouts for each day" },
    { text: "Upper body focus", icon: "fas fa-hand-paper", prompt: "Generate an upper body workout" },
    { text: "Cardio session", icon: "fas fa-heart", prompt: "Create a cardio workout plan" },
  ];

  // Chat with AI mutation
  const chatMutation = useMutation({
    mutationFn: async (message: string) => {
      const response = await apiRequest("POST", "/api/ai/chat", { message });
      return response.json();
    },
    onSuccess: (data) => {
      const aiMessage: Message = {
        id: Date.now().toString(),
        content: data.response,
        isUser: false,
        timestamp: new Date(),
        workoutPlan: data.workoutPlan || undefined,
        weeklyWorkouts: data.weeklyWorkouts || undefined,
      };
      setMessages(prev => [...prev, aiMessage]);
      setIsTyping(false);
    },
    onError: (error) => {
      console.error("Chat error:", error);
      setIsTyping(false);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to send message",
        variant: "destructive",
      });
    },
  });

  // Replace workout in schedule mutation
  const addWorkoutMutation = useMutation({
    mutationFn: async (workoutPlan: WorkoutPlan) => {
      // Get current date to replace
      const today = new Date();
      const scheduledDate = today.toISOString().split('T')[0]; // YYYY-MM-DD format
      
      const response = await apiRequest("POST", "/api/workouts/replace", {
        workoutPlan: {
          name: workoutPlan.name,
          description: workoutPlan.description,
          duration: workoutPlan.duration,
          difficulty: workoutPlan.difficulty,
          exercises: workoutPlan.exercises,
        },
        scheduledDate
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workouts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/workouts/scheduled"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Workout Replaced!",
        description: "Today's workout has been replaced with the new AI-generated plan.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to replace workout in your schedule",
        variant: "destructive",
      });
    },
  });

  // Weekly workout scheduling mutation
  const scheduleWeeklyMutation = useMutation({
    mutationFn: async (weeklyWorkouts: WeeklyWorkouts) => {
      const response = await apiRequest("POST", "/api/workouts/schedule-weekly", {
        weeklyWorkouts
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workouts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/workouts/scheduled"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Weekly Plan Scheduled!",
        description: "Your complete weekly workout plan has been added to your schedule.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to schedule weekly workout plan",
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = (message: string) => {
    if (!message.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      content: message,
      isUser: true,
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, userMessage]);
    setInputMessage("");
    setIsTyping(true);

    // Send to AI
    chatMutation.mutate(message);
  };

  const handleQuickAction = (action: typeof quickActions[0]) => {
    handleSendMessage(action.prompt);
  };

  const handleAcceptWorkout = (workoutPlan: WorkoutPlan) => {
    addWorkoutMutation.mutate(workoutPlan);
  };

  const handleAcceptWeeklyPlan = (weeklyWorkouts: WeeklyWorkouts) => {
    scheduleWeeklyMutation.mutate(weeklyWorkouts);
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black text-white">
      {/* Sticky Header */}
      <div className="sticky top-0 z-50 bg-gray-900/80 backdrop-blur-md border-b border-gray-800/50">
        <div className="px-6 py-4 pt-[6px] pb-[6px]">
          <div className="flex items-center justify-between">
            {/* Empty space for balance */}
            <div className="w-10"></div>
            
            {/* App Name - Centered */}
            <h1 className="text-2xl font-light text-white tracking-wider uppercase">
              VITRA
            </h1>
            
            {/* Empty space for balance */}
            <div className="w-10"></div>
          </div>
        </div>
      </div>
      
      {/* Main Content */}
      <div className="px-6 pt-8 pb-32 space-y-6">
        {/* Quick Actions */}
        <div className="bg-gray-800/50 rounded-2xl p-6 border border-gray-700/50 space-y-4">
          <h2 className="text-lg font-semibold text-white">Quick Actions</h2>
          <div className="grid grid-cols-2 gap-3">
            {quickActions.map((action, index) => (
              <button
                key={index}
                onClick={() => handleQuickAction(action)}
                className="bg-gray-700/50 border border-gray-600/50 rounded-xl p-4 text-left hover:bg-gray-600/50 transition-all duration-200"
              >
                <div className="flex items-center space-x-3">
                  <div className="text-teal-400">
                    <i className={`${action.icon} text-lg`}></i>
                  </div>
                  <span className="text-white text-sm font-medium">{action.text}</span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Messages */}
        <div className="bg-gray-800/50 rounded-2xl border border-gray-700/50 p-6 space-y-4">
          <h2 className="text-lg font-semibold text-white">AI Chat</h2>
          <div className="space-y-4 max-h-96 overflow-y-auto">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-lg rounded-2xl px-4 py-3 ${
                    message.isUser
                      ? 'bg-gradient-to-r from-teal-600 to-blue-600 text-white'
                      : 'bg-gray-700/50 border border-gray-600/50 text-white'
                  }`}
                >
                <div className="text-sm leading-relaxed whitespace-pre-wrap">
                  {message.content}
                </div>
                
                {/* Workout Plan Card */}
                {message.workoutPlan && (
                  <div className="mt-4 bg-gray-700/50 rounded-xl p-4 border border-gray-600/50">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-white font-semibold">{message.workoutPlan.name}</h4>
                      <div className="flex items-center space-x-2">
                        <Badge variant="secondary" className="text-xs">
                          {message.workoutPlan.duration} min
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          {message.workoutPlan.difficulty}
                        </Badge>
                      </div>
                    </div>
                    
                    <p className="text-gray-300 text-sm mb-4">{message.workoutPlan.description}</p>
                    
                    <div className="space-y-2 mb-4">
                      <h5 className="text-white font-medium text-sm">Exercises:</h5>
                      {message.workoutPlan.exercises.slice(0, 3).map((exercise, idx) => (
                        <div key={idx} className="flex items-center justify-between text-sm">
                          <span className="text-gray-300">{exercise.name}</span>
                          <span className="text-gray-400">{exercise.sets} × {exercise.reps}</span>
                        </div>
                      ))}
                      {message.workoutPlan.exercises.length > 3 && (
                        <div className="text-gray-400 text-xs">
                          +{message.workoutPlan.exercises.length - 3} more exercises
                        </div>
                      )}
                    </div>
                    
                    <Button
                      onClick={() => handleAcceptWorkout(message.workoutPlan!)}
                      disabled={addWorkoutMutation.isPending}
                      className="w-full bg-teal-500 hover:bg-teal-400 text-gray-900 font-medium"
                    >
                      {addWorkoutMutation.isPending ? "Adding..." : "Add to My Workouts"}
                    </Button>
                  </div>
                )}

                {message.weeklyWorkouts && (
                  <div className="mt-3 bg-gray-700/50 rounded-lg p-3 border border-gray-600/50">
                    <div className="text-white font-medium mb-3">📅 Weekly Workout Plan</div>
                    
                    <div className="space-y-3 mb-4">
                      {Object.entries(message.weeklyWorkouts).map(([day, workout]) => (
                        <div key={day} className="bg-gray-800/50 rounded-md p-2">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-teal-400 font-medium capitalize">{day}</span>
                            <span className="text-xs text-gray-400">{workout.duration} min</span>
                          </div>
                          <div className="text-gray-300 text-sm">{workout.name}</div>
                          <div className="text-gray-400 text-xs">{workout.exercises.length} exercises</div>
                        </div>
                      ))}
                    </div>
                    
                    <Button
                      onClick={() => handleAcceptWeeklyPlan(message.weeklyWorkouts!)}
                      disabled={scheduleWeeklyMutation.isPending}
                      className="w-full bg-gradient-to-r from-teal-600 to-blue-600 hover:from-teal-700 hover:to-blue-700 text-white font-medium"
                    >
                      {scheduleWeeklyMutation.isPending ? "Scheduling..." : "Schedule Weekly Plan"}
                    </Button>
                  </div>
                )}
                
                <div className={`text-xs mt-2 ${message.isUser ? 'text-gray-700' : 'text-gray-400'}`}>
                  {formatTime(message.timestamp)}
                </div>
              </div>
            </div>
          ))}
          
          {/* Typing Indicator */}
          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-2xl px-4 py-3">
                <div className="flex items-center space-x-2">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                  <span className="text-gray-400 text-sm">AI is thinking...</span>
                </div>
              </div>
            </div>
          )}
          </div>
        </div>

        {/* Input Area */}
        <div className="bg-gray-800/50 rounded-2xl border border-gray-700/50 p-4">
          <div className="flex items-center space-x-3">
            <Input
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder="Ask me anything about fitness..."
              className="flex-1 bg-gray-700 border-gray-600 text-white placeholder-gray-400"
              onKeyPress={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage(inputMessage);
                }
              }}
              disabled={chatMutation.isPending}
            />
            <Button
              onClick={() => handleSendMessage(inputMessage)}
              disabled={!inputMessage.trim() || chatMutation.isPending}
              className="bg-gradient-to-r from-teal-600 to-blue-600 hover:from-teal-700 hover:to-blue-700 text-white"
            >
              Send
            </Button>
          </div>
        </div>
      </div>
      <BottomNavigation />
    </div>
  );
}