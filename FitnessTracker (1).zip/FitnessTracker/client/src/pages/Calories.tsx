import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { ArrowLeft, Target, Plus } from "lucide-react";
import { useLocation } from "wouter";

export default function Calories() {
  const [, setLocation] = useLocation();
  const [calorieTarget, setCalorieTarget] = useState('');
  const [manualCalories, setManualCalories] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch current nutrition data
  const { data: dailyNutrition = {}, refetch: refetchNutrition } = useQuery({
    queryKey: ["/api/nutrition/daily-stats"],
    refetchInterval: 5000, // Reduced frequency for better performance
    staleTime: 1000, // Allow 1 second cache
  });

  const { data: profile } = useQuery({
    queryKey: ["/api/profile"],
    refetchInterval: 10000, // Refetch every 10 seconds
    staleTime: 0,
  });

  useEffect(() => {
    if (profile?.targetCalories) {
      setCalorieTarget(profile.targetCalories);
    }
  }, [profile]);

  const handleCalorieTargetChange = (value: string) => {
    if (value === '') {
      setCalorieTarget('');
    } else {
      const numValue = Number(value);
      if (!isNaN(numValue)) {
        setCalorieTarget(numValue);
      }
    }
  };

  // Update calorie target mutation
  const updateCaloriesMutation = useMutation({
    mutationFn: async (newTarget: number) => {
      const response = await apiRequest("POST", "/api/profile", { targetCalories: newTarget });
      return response.json();
    },
    onSuccess: async () => {
      toast({ title: "Success", description: "Calorie target updated successfully" });
      // Force refetch all related queries immediately
      await queryClient.refetchQueries({ queryKey: ["/api/nutrition/daily-stats"] });
      await queryClient.refetchQueries({ queryKey: ["/api/profile"] });
      await queryClient.refetchQueries({ queryKey: ["/api/dashboard/stats"] });
    },
  });

  // Add manual calories mutation
  const addCaloriesMutation = useMutation({
    mutationFn: async (calories: number) => {
      const response = await apiRequest("POST", "/api/nutrition/log", {
        customFoodName: "Manual Entry",
        calories: calories,
        protein: 0,
        carbs: 0,
        fats: 0,
        fiber: 0,
        servings: 1,
        mealType: "snack",
        loggedAt: new Date().toISOString(),
        loggedDate: new Date().toISOString().split('T')[0],
      });
      return response.json();
    },
    onSuccess: async (data) => {
      toast({ title: "Success", description: "Calories added successfully" });
      // Immediately refetch to show updated data
      await refetchNutrition();
      // Invalidate other related queries
      queryClient.invalidateQueries({ queryKey: ["/api/nutrition/logs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setManualCalories("");
    },
  });

  const caloriesPercentage = dailyNutrition.targetCalories 
    ? (dailyNutrition.calories / dailyNutrition.targetCalories) * 100 
    : 0;

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black text-white">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-gradient-to-b from-gray-900/95 to-black/95 backdrop-blur-sm border-b border-gray-800/50">
        <div className="flex items-center justify-between p-6">
          <button 
            onClick={() => setLocation('/nutrition')}
            className="p-2 hover:bg-gray-800 rounded-full transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-white" />
          </button>
          <h1 className="text-xl font-bold text-white uppercase tracking-wider">CALORIES</h1>
          <div className="w-10" /> {/* Spacer */}
        </div>
      </div>

      <div className="px-6 py-6 space-y-6">
        {/* Current Status Widget */}
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6">
          <div className="text-center mb-6">
            <h2 className="text-sm font-medium text-gray-400 uppercase tracking-wider mb-4">TODAY'S INTAKE</h2>
            <div className="text-6xl font-light text-white mb-2">
              {Math.round(dailyNutrition.calories || 0)}
            </div>
            <div className="text-lg text-gray-400 mb-4">
              of {dailyNutrition.targetCalories || 2400} goal
            </div>
            <div className="w-full bg-gray-800 rounded-full h-3">
              <div 
                className="bg-green-400 h-3 rounded-full transition-all duration-500" 
                style={{ width: `${Math.min(100, caloriesPercentage)}%` }}
              ></div>
            </div>
            <div className="text-xs text-gray-500 mt-2">
              {Math.round(caloriesPercentage)}% of daily goal
            </div>
          </div>
        </div>

        {/* Quick Add Calories */}
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6">
          <h3 className="text-base font-medium text-white uppercase tracking-wide mb-4">
            <Plus className="w-5 h-5 inline mr-2" />
            ADD CALORIES
          </h3>
          
          <div className="space-y-4">
            <div className="bg-gray-800 border border-gray-700 rounded-xl p-4">
              <Label htmlFor="manual-calories" className="text-gray-400 text-xs uppercase tracking-wide block mb-3">
                Manual Entry
              </Label>
              <Input
                id="manual-calories"
                type="number"
                value={manualCalories}
                onChange={(e) => setManualCalories(e.target.value)}
                className="bg-transparent border-0 text-2xl font-light text-white p-0 focus-visible:ring-0 focus-visible:ring-offset-0"
                placeholder="Enter calories..."
              />
            </div>
            
            <Button 
              onClick={() => manualCalories && addCaloriesMutation.mutate(Number(manualCalories))}
              disabled={!manualCalories || addCaloriesMutation.isPending}
              className="w-full bg-teal-500 hover:bg-teal-600 text-gray-900 font-medium rounded-xl h-12"
            >
              {addCaloriesMutation.isPending ? "Adding..." : "Add Calories"}
            </Button>
          </div>

          {/* Quick Add Buttons */}
          <div className="grid grid-cols-2 gap-3 mt-6">
            <Button 
              onClick={() => addCaloriesMutation.mutate(100)}
              disabled={addCaloriesMutation.isPending}
              variant="outline"
              className="bg-gray-800 border-gray-700 text-gray-300 hover:bg-gray-700 rounded-xl h-12"
            >
              +100 cal
            </Button>
            <Button 
              onClick={() => addCaloriesMutation.mutate(200)}
              disabled={addCaloriesMutation.isPending}
              variant="outline"
              className="bg-gray-800 border-gray-700 text-gray-300 hover:bg-gray-700 rounded-xl h-12"
            >
              +200 cal
            </Button>
            <Button 
              onClick={() => addCaloriesMutation.mutate(300)}
              disabled={addCaloriesMutation.isPending}
              variant="outline"
              className="bg-gray-800 border-gray-700 text-gray-300 hover:bg-gray-700 rounded-xl h-12"
            >
              +300 cal
            </Button>
            <Button 
              onClick={() => addCaloriesMutation.mutate(500)}
              disabled={addCaloriesMutation.isPending}
              variant="outline"
              className="bg-gray-800 border-gray-700 text-gray-300 hover:bg-gray-700 rounded-xl h-12"
            >
              +500 cal
            </Button>
          </div>
        </div>

        {/* Calorie Goal Settings */}
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6">
          <h3 className="text-base font-medium text-white uppercase tracking-wide mb-4">
            <Target className="w-5 h-5 inline mr-2" />
            DAILY GOAL
          </h3>
          
          <div className="space-y-4">
            <div className="bg-gray-800 border border-gray-700 rounded-xl p-4">
              <Label htmlFor="calorie-goal" className="text-gray-400 text-xs uppercase tracking-wide block mb-3">
                Target Calories
              </Label>
              <Input
                id="calorie-goal"
                type="number"
                value={calorieTarget}
                onChange={(e) => handleCalorieTargetChange(e.target.value)}
                className="bg-transparent border-0 text-2xl font-light text-white p-0 focus-visible:ring-0 focus-visible:ring-offset-0"
                placeholder="2400"
              />
            </div>
            
            <Button 
              onClick={() => updateCaloriesMutation.mutate(Number(calorieTarget))}
              disabled={updateCaloriesMutation.isPending || !calorieTarget}
              className="w-full bg-teal-500 hover:bg-teal-600 text-gray-900 font-medium rounded-xl h-12"
            >
              {updateCaloriesMutation.isPending ? "Updating..." : "Update Goal"}
            </Button>
          </div>

          {/* Quick Goal Presets */}
          <div className="grid grid-cols-2 gap-3 mt-6">
            <Button 
              onClick={() => setCalorieTarget(1800)}
              variant="outline"
              className="bg-gray-800 border-gray-700 text-gray-300 hover:bg-gray-700 rounded-xl h-10 text-sm"
            >
              1800 cal
            </Button>
            <Button 
              onClick={() => setCalorieTarget(2000)}
              variant="outline"
              className="bg-gray-800 border-gray-700 text-gray-300 hover:bg-gray-700 rounded-xl h-10 text-sm"
            >
              2000 cal
            </Button>
            <Button 
              onClick={() => setCalorieTarget(2400)}
              variant="outline"
              className="bg-gray-800 border-gray-700 text-gray-300 hover:bg-gray-700 rounded-xl h-10 text-sm"
            >
              2400 cal
            </Button>
            <Button 
              onClick={() => setCalorieTarget(2800)}
              variant="outline"
              className="bg-gray-800 border-gray-700 text-gray-300 hover:bg-gray-700 rounded-xl h-10 text-sm"
            >
              2800 cal
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}