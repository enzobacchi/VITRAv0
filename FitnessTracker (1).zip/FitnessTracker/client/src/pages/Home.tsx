import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { MacroRing } from "@/components/MacroRing";
import { useTheme } from "@/components/ThemeProvider";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { BottomNavigation } from "@/components/BottomNavigation";
import { MessageCircle, ChevronRight, User } from "lucide-react";
import { WidgetManager } from "@/components/WidgetManager";
import { WaterTracker } from "@/components/widgets/WaterTracker";
import { WorkoutStreakWidget } from "@/components/widgets/WorkoutStreakWidget";
import { RecoveryWidget } from "@/components/widgets/RecoveryWidget";
import { AIAssistantWidget } from "@/components/widgets/AIAssistantWidget";
import { CaloriesCompactWidget } from "@/components/widgets/CaloriesCompactWidget";
import { MacrosCompactWidget } from "@/components/widgets/MacrosCompactWidget";

// Widget components mapping
const WIDGET_COMPONENTS = {
  calories: ({ dailyNutrition, setLocation, size }: any) => 
    size === 'half' ? (
      <CaloriesCompactWidget dailyNutrition={dailyNutrition} />
    ) : (
    <section 
      data-widget-click
      onClick={() => setLocation('/calories')}
      onContextMenu={(e) => e.preventDefault()}
      className="bg-gray-900 border border-gray-800 rounded-2xl p-6 cursor-pointer hover:bg-gray-800 transition-all duration-200 select-none"
      style={{ WebkitTouchCallout: 'none', WebkitUserSelect: 'none' }}
    >
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-medium text-white uppercase tracking-wide">Calories</h3>
        <ChevronRight className="w-5 h-5 text-gray-600" />
      </div>
      
      <div className="flex items-end space-x-2">
        <span className="text-6xl font-light text-white">{Math.round(dailyNutrition.calories)}</span>
        <span className="text-lg text-gray-400 pb-2">of {dailyNutrition.targetCalories}</span>
      </div>
    </section>
  ),
  macros: ({ dailyNutrition, proteinPercentage, carbsPercentage, fatsPercentage, setLocation }: any) => (
    <section 
      data-widget-click
      onClick={() => setLocation('/nutrition')}
      onContextMenu={(e) => e.preventDefault()}
      className="bg-gray-900 border border-gray-800 rounded-2xl p-6 cursor-pointer hover:bg-gray-800 transition-all duration-200 select-none"
      style={{ WebkitTouchCallout: 'none', WebkitUserSelect: 'none' }}
    >
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-medium text-white uppercase tracking-wide">Macros</h3>
        <ChevronRight className="w-5 h-5 text-gray-600" />
      </div>
      
      <div className="grid grid-cols-3 gap-4 mb-4">
        <div className="text-center">
          <MacroRing percentage={proteinPercentage} color="#10B981" />
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">Protein</p>
          <p className="text-sm font-semibold text-gray-900 dark:text-white">
            {Math.round(dailyNutrition.protein)}g
          </p>
        </div>
        
        <div className="text-center">
          <MacroRing percentage={carbsPercentage} color="#3B82F6" />
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">Carbs</p>
          <p className="text-sm font-semibold text-gray-900 dark:text-white">
            {Math.round(dailyNutrition.carbs)}g
          </p>
        </div>
        
        <div className="text-center">
          <MacroRing percentage={fatsPercentage} color="#F59E0B" />
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">Fats</p>
          <p className="text-sm font-semibold text-gray-900 dark:text-white">
            {Math.round(dailyNutrition.fats)}g
          </p>
        </div>
      </div>
    </section>
    ),
  workout: ({ todaysWorkout, setLocation }: any) => (
    <section 
      data-widget-click
      onClick={() => setLocation('/workouts')}
      onContextMenu={(e) => e.preventDefault()}
      className="bg-gray-900 border border-gray-800 rounded-2xl p-6 cursor-pointer hover:bg-gray-800 transition-all duration-200 select-none"
      style={{ WebkitTouchCallout: 'none', WebkitUserSelect: 'none' }}
    >
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-medium text-white uppercase tracking-wide">Today's Workout</h3>
        <ChevronRight className="w-5 h-5 text-gray-600" />
      </div>
      
      {todaysWorkout ? (
        <div>
          <h4 className="text-xl font-semibold text-white mb-2">{todaysWorkout.workoutPlan?.name || 'Workout'}</h4>
          <div className="flex justify-between text-sm text-gray-400 mb-4">
            <span>{todaysWorkout.workoutPlan?.duration || 45}min</span>
            <span>{todaysWorkout.workoutPlan?.exercises?.length || 0} exercises</span>
          </div>
        </div>
      ) : (
        <div className="text-center py-8">
          <p className="text-gray-400">No workout scheduled</p>
        </div>
      )}
    </section>
  ),
  water: () => <WaterTracker />,
  streak: () => <WorkoutStreakWidget />,
  recovery: () => <RecoveryWidget />,
  aiAssistant: () => <AIAssistantWidget />,
};

export default function Home() {
  const { user } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  const [chatMessage, setChatMessage] = useState("");
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState<Array<{
    id: string;
    content: string;
    isUser: boolean;
    timestamp: Date;
  }>>([]);

  // Widget configuration state
  const [widgets, setWidgets] = useState([
    { id: 'calories', name: 'Calories', component: WIDGET_COMPONENTS.calories, enabled: true, order: 0, size: 'full' },
    { id: 'macros', name: 'Macros', component: WIDGET_COMPONENTS.macros, enabled: true, order: 1, size: 'full' },
    { id: 'workout', name: "Today's Workout", component: WIDGET_COMPONENTS.workout, enabled: true, order: 2, size: 'full' },
    { id: 'water', name: 'Water Tracker', component: WIDGET_COMPONENTS.water, enabled: false, order: 3, size: 'half' },
    { id: 'streak', name: 'Workout Streak', component: WIDGET_COMPONENTS.streak, enabled: false, order: 4, size: 'half' },
    { id: 'recovery', name: 'Recovery Status', component: WIDGET_COMPONENTS.recovery, enabled: false, order: 5, size: 'half' },
    { id: 'aiAssistant', name: 'AI Assistant', component: WIDGET_COMPONENTS.aiAssistant, enabled: false, order: 6, size: 'full' },
  ]);

  // Drag and drop state
  const [isDragging, setIsDragging] = useState(false);
  const [draggedWidget, setDraggedWidget] = useState<string | null>(null);
  const [dragPosition, setDragPosition] = useState({ x: 0, y: 0 });
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [draggedOverWidget, setDraggedOverWidget] = useState<string | null>(null);
  const [dragTimer, setDragTimer] = useState<NodeJS.Timeout | null>(null);
  const [reorderedWidgets, setReorderedWidgets] = useState<any[]>([]);

  // Load widget configuration from localStorage
  useEffect(() => {
    const savedWidgets = localStorage.getItem('vitra-widgets');
    const defaultWidgets = [
      { id: 'calories', name: 'Calories', enabled: true, order: 0, size: 'full' },
      { id: 'macros', name: 'Macros', enabled: true, order: 1, size: 'full' },
      { id: 'workout', name: "Today's Workout", enabled: true, order: 2, size: 'full' },
      { id: 'water', name: 'Water Tracker', enabled: false, order: 3, size: 'half' },
      { id: 'streak', name: 'Workout Streak', enabled: false, order: 4, size: 'half' },
      { id: 'recovery', name: 'Recovery Status', enabled: false, order: 5, size: 'half' },
      { id: 'aiAssistant', name: 'AI Assistant', enabled: false, order: 6, size: 'full' },
    ];

    if (savedWidgets) {
      try {
        const parsed = JSON.parse(savedWidgets);
        // Check if new widgets are missing and add them
        const existingIds = parsed.map((w: any) => w.id);
        const missingWidgets = defaultWidgets.filter(w => !existingIds.includes(w.id));
        
        const updatedWidgets = [...parsed, ...missingWidgets].map((w: any) => ({
          ...w,
          component: WIDGET_COMPONENTS[w.id as keyof typeof WIDGET_COMPONENTS]
        }));
        
        setWidgets(updatedWidgets);
        
        // Update localStorage if we added missing widgets
        if (missingWidgets.length > 0) {
          const saveData = updatedWidgets.map(({ component, ...widget }) => widget);
          localStorage.setItem('vitra-widgets', JSON.stringify(saveData));
        }
      } catch (error) {
        console.error('Failed to load widget configuration:', error);
        // Fallback to default widgets with components
        const defaultWithComponents = defaultWidgets.map(w => ({
          ...w,
          component: WIDGET_COMPONENTS[w.id as keyof typeof WIDGET_COMPONENTS]
        }));
        setWidgets(defaultWithComponents);
      }
    } else {
      // First time - set default widgets with components
      const defaultWithComponents = defaultWidgets.map(w => ({
        ...w,
        component: WIDGET_COMPONENTS[w.id as keyof typeof WIDGET_COMPONENTS]
      }));
      setWidgets(defaultWithComponents);
    }
  }, []);

  // Save widget configuration to localStorage
  const handleUpdateWidgets = (updatedWidgets: any[]) => {
    setWidgets(updatedWidgets);
    // Save without component functions
    const saveData = updatedWidgets.map(({ component, ...widget }) => widget);
    localStorage.setItem('vitra-widgets', JSON.stringify(saveData));
  };

  // Drag and drop handlers
  const handleTouchStart = (e: React.TouchEvent, widgetId: string) => {
    const touch = e.touches[0];
    const rect = e.currentTarget.getBoundingClientRect();
    const startTime = Date.now();
    
    const offset = {
      x: touch.clientX - rect.left,
      y: touch.clientY - rect.top
    };
    
    let timer: NodeJS.Timeout | null = null;
    let isCurrentlyDragging = false;
    
    // Start drag after hold time
    timer = setTimeout(() => {
      isCurrentlyDragging = true;
      setIsDragging(true);
      setDraggedWidget(widgetId);
      setDragOffset(offset);
      setDragPosition({
        x: touch.clientX - offset.x,
        y: touch.clientY - offset.y
      });
      
      if (navigator.vibrate) {
        navigator.vibrate(50);
      }
    }, 400);

    const handleTouchMove = (moveEvent: TouchEvent) => {
      if (isCurrentlyDragging) {
        moveEvent.preventDefault();
        const moveTouch = moveEvent.touches[0];
        
        setDragPosition({
          x: moveTouch.clientX - offset.x,
          y: moveTouch.clientY - offset.y
        });
        
        // Handle real-time reordering
        handleRealTimeReorder(moveTouch.clientX, moveTouch.clientY, widgetId);
      }
    };

    const handleTouchEnd = () => {
      if (timer) clearTimeout(timer);
      
      const endTime = Date.now();
      const wasQuickTap = (endTime - startTime) < 400;
      
      if (wasQuickTap && !isCurrentlyDragging) {
        // Handle click
        const widgetElement = e.currentTarget?.querySelector('[data-widget-click]') as HTMLElement;
        if (widgetElement) {
          widgetElement.click();
        }
      }
      
      if (isCurrentlyDragging) {
        handleDragEnd();
      }
      
      document.removeEventListener('touchmove', handleTouchMove);
      document.removeEventListener('touchend', handleTouchEnd);
    };

    document.addEventListener('touchmove', handleTouchMove, { passive: false });
    document.addEventListener('touchend', handleTouchEnd, { once: true });
  };

  const handleMouseDown = (e: React.MouseEvent, widgetId: string) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const startTime = Date.now();
    
    const offset = {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    };
    
    let timer: NodeJS.Timeout | null = null;
    let isCurrentlyDragging = false;

    timer = setTimeout(() => {
      isCurrentlyDragging = true;
      setIsDragging(true);
      setDraggedWidget(widgetId);
      setDragOffset(offset);
      setDragPosition({
        x: e.clientX - offset.x,
        y: e.clientY - offset.y
      });
    }, 400);

    const handleMouseMove = (moveEvent: MouseEvent) => {
      if (isCurrentlyDragging) {
        moveEvent.preventDefault();
        
        setDragPosition({
          x: moveEvent.clientX - offset.x,
          y: moveEvent.clientY - offset.y
        });
        
        // Handle real-time reordering
        handleRealTimeReorder(moveEvent.clientX, moveEvent.clientY, widgetId);
      }
    };

    const handleMouseUp = () => {
      if (timer) clearTimeout(timer);
      
      const endTime = Date.now();
      const wasQuickTap = (endTime - startTime) < 400;
      
      if (wasQuickTap && !isCurrentlyDragging) {
        const widgetElement = e.currentTarget?.querySelector('[data-widget-click]') as HTMLElement;
        if (widgetElement) {
          widgetElement.click();
        }
      }
      
      if (isCurrentlyDragging) {
        handleDragEnd();
      }
      
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp, { once: true });
  };

  // Handle real-time widget reordering during drag
  const handleRealTimeReorder = (clientX: number, clientY: number, draggedWidgetId: string) => {
    const enabledWidgets = widgets.filter(w => w.enabled).sort((a, b) => a.order - b.order);
    const draggedIndex = enabledWidgets.findIndex(w => w.id === draggedWidgetId);
    
    if (draggedIndex === -1) return;

    // Calculate the drop position based on Y coordinate
    let newIndex = 0;
    
    // Get positions of all non-dragged widgets
    for (let i = 0; i < enabledWidgets.length; i++) {
      if (enabledWidgets[i].id === draggedWidgetId) continue;
      
      const element = document.querySelector(`[data-widget-id="${enabledWidgets[i].id}"]`) as HTMLElement;
      if (element) {
        const rect = element.getBoundingClientRect();
        const centerY = rect.top + rect.height / 2;
        
        if (clientY > centerY) {
          newIndex = i + 1;
        }
      }
    }
    
    // Adjust index if we're moving past the dragged widget's original position
    if (newIndex > draggedIndex) {
      newIndex = newIndex - 1;
    }

    // Only reorder if position actually changed
    if (newIndex !== draggedIndex) {
      const newWidgets = [...widgets];
      const draggedWidget = enabledWidgets[draggedIndex];
      
      // Create new order for enabled widgets
      const reorderedEnabled = enabledWidgets.filter(w => w.id !== draggedWidgetId);
      reorderedEnabled.splice(newIndex, 0, draggedWidget);
      
      // Update orders for all widgets
      reorderedEnabled.forEach((widget, index) => {
        const widgetToUpdate = newWidgets.find(w => w.id === widget.id);
        if (widgetToUpdate) {
          widgetToUpdate.order = index;
        }
      });
      
      setReorderedWidgets(newWidgets);
    }
  };

  const handleDragEnd = () => {
    // Apply the final reordering if any changes were made
    if (reorderedWidgets.length > 0) {
      setWidgets(reorderedWidgets);
      handleUpdateWidgets(reorderedWidgets);
      setReorderedWidgets([]);
    }
    
    // Clean up drag state
    setIsDragging(false);
    setDraggedWidget(null);
    setDraggedOverWidget(null);
    setDragPosition({ x: 0, y: 0 });
    setDragOffset({ x: 0, y: 0 });
  };

  // Fetch dashboard stats
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
    refetchInterval: 10000, // Reduced frequency for better performance
    staleTime: 5000, // Allow 5 second cache
  });

  // Fetch all scheduled workouts
  const { data: scheduledWorkouts } = useQuery({
    queryKey: ["/api/workouts/scheduled"],
  });

  // Fetch workout plans to get today's workout
  const { data: workoutPlans } = useQuery({
    queryKey: ["/api/workouts"],
  });

  // Fetch user supplements
  const { data: supplements } = useQuery({
    queryKey: ["/api/supplements"],
  });

  // Get today's scheduled workout
  const getTodaysWorkout = () => {
    const today = new Date().toISOString().split('T')[0];
    
    if (Array.isArray(scheduledWorkouts)) {
      const todaysScheduled = scheduledWorkouts.find((sw: any) => sw.scheduledDate === today);
      return todaysScheduled || null;
    }
    
    return null;
  };

  const todaysWorkout = getTodaysWorkout();
  const todayName = new Date().toLocaleDateString('en-US', { weekday: 'long' });

  // AI Chat mutation
  const chatMutation = useMutation({
    mutationFn: async (message: string) => {
      const response = await apiRequest("POST", "/api/ai/chat", { message });
      return response.json();
    },
    onMutate: (message: string) => {
      // Add user message immediately
      const userMessage = {
        id: Date.now().toString(),
        content: message,
        isUser: true,
        timestamp: new Date(),
      };
      setChatMessages(prev => [...prev, userMessage]);
      setChatMessage("");
    },
    onSuccess: (data) => {
      // Add AI response
      const aiMessage = {
        id: (Date.now() + 1).toString(),
        content: data.response,
        isUser: false,
        timestamp: new Date(),
      };
      setChatMessages(prev => [...prev, aiMessage]);
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = () => {
    if (chatMessage.trim()) {
      chatMutation.mutate(chatMessage.trim());
    }
  };

  if (statsLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  const dailyNutrition = (stats as any)?.dailyNutrition || { calories: 0, protein: 0, carbs: 0, fats: 0, targetCalories: 2100, targetProtein: 150, targetCarbs: 250, targetFats: 70 };
  const weeklyWorkouts = (stats as any)?.weeklyWorkouts || { completed: 0, total: 6 };

  const proteinPercentage = dailyNutrition.targetProtein ? (dailyNutrition.protein / dailyNutrition.targetProtein) * 100 : 0;
  const carbsPercentage = dailyNutrition.targetCarbs ? (dailyNutrition.carbs / dailyNutrition.targetCarbs) * 100 : 0;
  const fatsPercentage = dailyNutrition.targetFats ? (dailyNutrition.fats / dailyNutrition.targetFats) * 100 : 0;
  const caloriesPercentage = dailyNutrition.targetCalories ? (dailyNutrition.calories / dailyNutrition.targetCalories) * 100 : 0;
  const workoutPercentage = weeklyWorkouts.total ? (weeklyWorkouts.completed / weeklyWorkouts.total) * 100 : 0;

  // Get enabled widgets sorted by order
  const enabledWidgets = widgets
    .filter(w => w.enabled)
    .sort((a, b) => a.order - b.order);

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black">
      {/* Sticky Header */}
      <div className="sticky top-0 z-50 bg-gray-900/80 backdrop-blur-md border-b border-gray-800/50">
        <div className="px-6 py-4 pt-[6px] pb-[6px]">
          <div className="flex items-center justify-between">
            {/* Profile Circle */}
            <button 
              onClick={() => setLocation('/profile')}
              onContextMenu={(e) => e.preventDefault()}
              className="w-10 h-10 bg-gray-700 rounded-full flex items-center justify-center border-2 border-gray-600 hover:border-gray-500 transition-colors select-none"
              style={{ WebkitTouchCallout: 'none', WebkitUserSelect: 'none' }}
            >
              <User className="w-5 h-5 text-white" />
            </button>
            
            {/* Centered Brand */}
            <h1 className="text-2xl font-light text-white tracking-wider uppercase">
              VITRA
            </h1>
            
            {/* Widget Manager */}
            <WidgetManager widgets={widgets} onUpdateWidgets={handleUpdateWidgets} />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="px-6 py-6 pb-32 space-y-6 relative" style={{ touchAction: isDragging ? 'none' : 'auto' }}>
        {(isDragging && reorderedWidgets.length > 0 ? 
          reorderedWidgets.filter(w => w.enabled).sort((a, b) => a.order - b.order) : 
          enabledWidgets
        ).reduce((acc, widget, index) => {
          const WidgetComponent = widget.component;
          const isHalfWidth = widget.size === 'half';
          const isBeingDragged = draggedWidget === widget.id;
          
          const widgetElement = (
            <div 
              key={widget.id}
              data-widget-id={widget.id}
              onTouchStart={(e) => handleTouchStart(e, widget.id)}
              onMouseDown={(e) => handleMouseDown(e, widget.id)}
              className={`select-none cursor-pointer ${isHalfWidth ? 'flex-1' : 'w-full'} ${
                isBeingDragged ? '' : 'relative'
              } ${
                isDragging && !isBeingDragged ? 'opacity-60' : ''
              } ${
                !isDragging ? 'transition-all duration-300 ease-out' : ''
              }`}
              style={{
                zIndex: isBeingDragged ? 1000 : 1,
                position: isBeingDragged ? 'fixed' : 'relative',
                left: isBeingDragged ? `${dragPosition.x}px` : 'auto',
                top: isBeingDragged ? `${dragPosition.y}px` : 'auto',
                transform: isBeingDragged ? 'rotate(2deg) scale(1.02)' : 'none',
                opacity: isBeingDragged ? 0.95 : 1,
                pointerEvents: isBeingDragged ? 'none' : 'auto',
                width: isBeingDragged ? 'calc(100vw - 48px)' : isHalfWidth ? 'auto' : 'auto',
                maxWidth: isBeingDragged ? '500px' : 'auto',
                touchAction: 'none',
                userSelect: 'none',
                WebkitUserSelect: 'none',
              }}
            >
              {WidgetComponent({
                dailyNutrition,
                weeklyWorkouts,
                todaysWorkout,
                proteinPercentage,
                carbsPercentage,
                fatsPercentage,
                setLocation,
                size: widget.size,
              })}
            </div>
          );

          // Group half-width widgets together
          if (isHalfWidth) {
            // Check if the last item in acc is a half-width container
            const lastItem = acc[acc.length - 1];
            if (lastItem && lastItem.type === 'half-container' && lastItem.children.length === 1) {
              // Add to existing half-width container
              lastItem.children.push(widgetElement);
            } else {
              // Create new half-width container
              acc.push({
                type: 'half-container',
                key: `half-${index}`,
                children: [widgetElement]
              });
            }
          } else {
            // Full-width widget
            acc.push({
              type: 'full-widget',
              key: widget.id,
              element: widgetElement
            });
          }
          
          return acc;
        }, [] as any[]).map((item) => {
          if (item.type === 'half-container') {
            return (
              <div key={item.key} className="flex gap-4">
                {item.children}
              </div>
            );
          } else {
            return item.element;
          }
        })}
        
        {enabledWidgets.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-400 mb-4">No widgets enabled</p>
            <p className="text-sm text-gray-500">
              Click the plus icon in the header to add widgets
            </p>
          </div>
        )}
      </div>

      {/* AI Chat Dialog */}
      <Dialog open={isChatOpen} onOpenChange={setIsChatOpen}>
        <DialogContent className="sm:max-w-[500px] max-h-[600px] p-0 bg-gradient-to-b from-gray-900 to-gray-800 border-gray-700 text-white">
          <DialogHeader className="px-6 py-4 border-b border-gray-700">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-teal-400 to-blue-500 flex items-center justify-center">
                <MessageCircle className="w-5 h-5 text-white" />
              </div>
              <div>
                <DialogTitle className="text-lg font-semibold text-white">AI Coach</DialogTitle>
                <DialogDescription className="text-sm text-gray-400">
                  Powered by GPT-4o • Online
                </DialogDescription>
              </div>
            </div>
          </DialogHeader>
          
          <div className="flex-1 overflow-hidden flex flex-col">
            {/* Chat Messages */}
            <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4 max-h-[400px]">
              {chatMessages.length === 0 ? (
                <div className="text-center py-8">
                  <MessageCircle className="w-12 h-12 text-gray-500 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-white mb-2">Start a conversation</h3>
                  <p className="text-gray-400 text-sm mb-4">
                    Ask me anything about fitness, nutrition, or workouts
                  </p>
                </div>
              ) : (
                <>
                  {chatMessages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.isUser ? "justify-end" : "justify-start"}`}
                    >
                      <div className="flex items-start space-x-2 max-w-[80%]">
                        {!message.isUser && (
                          <div className="w-6 h-6 rounded-full bg-gradient-to-br from-teal-400 to-blue-500 flex items-center justify-center flex-shrink-0 mt-1">
                            <MessageCircle className="w-3 h-3 text-white" />
                          </div>
                        )}
                        <div
                          className={`rounded-2xl px-4 py-3 ${
                            message.isUser
                              ? "bg-teal-500 text-white"
                              : "bg-gray-700 text-gray-100"
                          }`}
                        >
                          <p className="text-sm leading-relaxed whitespace-pre-wrap">
                            {message.content}
                          </p>
                        </div>
                        {message.isUser && (
                          <div className="w-6 h-6 rounded-full bg-gray-600 flex items-center justify-center flex-shrink-0 mt-1">
                            <User className="w-3 h-3 text-white" />
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                  {chatMutation.isPending && (
                    <div className="flex justify-start">
                      <div className="flex items-start space-x-2 max-w-[80%]">
                        <div className="w-6 h-6 rounded-full bg-gradient-to-br from-teal-400 to-blue-500 flex items-center justify-center flex-shrink-0 mt-1">
                          <MessageCircle className="w-3 h-3 text-white" />
                        </div>
                        <div className="bg-gray-700 text-gray-100 rounded-2xl px-4 py-3">
                          <div className="flex items-center space-x-1">
                            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "0.1s" }}></div>
                            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "0.2s" }}></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>
            
            {/* Chat Input */}
            <div className="px-6 py-4 border-t border-gray-700">
              <div className="flex space-x-2">
                <Input
                  value={chatMessage}
                  onChange={(e) => setChatMessage(e.target.value)}
                  placeholder="Ask me anything about fitness..."
                  className="flex-1 bg-gray-800 border-gray-600 text-white placeholder-gray-400 focus:border-teal-500"
                  onKeyPress={(e) => {
                    if (e.key === "Enter" && !chatMutation.isPending) {
                      handleSendMessage();
                    }
                  }}
                  disabled={chatMutation.isPending}
                />
                <Button
                  onClick={handleSendMessage}
                  disabled={!chatMessage.trim() || chatMutation.isPending}
                  className="bg-teal-500 hover:bg-teal-400 text-white px-4"
                >
                  Send
                </Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <BottomNavigation />
    </div>
  );
}