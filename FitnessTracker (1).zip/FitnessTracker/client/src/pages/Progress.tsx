import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts";

export default function Progress() {
  const [timeRange, setTimeRange] = useState("7d");

  // Mock data for charts - in a real app this would come from the API
  const weightData = [
    { date: "Jan 1", weight: 75 },
    { date: "Jan 8", weight: 74.5 },
    { date: "Jan 15", weight: 74.2 },
    { date: "Jan 22", weight: 73.8 },
    { date: "Jan 29", weight: 73.5 },
    { date: "Feb 5", weight: 73.2 },
    { date: "Feb 12", weight: 72.8 },
  ];

  const calorieData = [
    { date: "Mon", calories: 2100, target: 2100 },
    { date: "Tue", calories: 1950, target: 2100 },
    { date: "Wed", calories: 2200, target: 2100 },
    { date: "Thu", calories: 2050, target: 2100 },
    { date: "Fri", calories: 2150, target: 2100 },
    { date: "Sat", calories: 2300, target: 2100 },
    { date: "Sun", calories: 1980, target: 2100 },
  ];

  const workoutData = [
    { date: "Week 1", workouts: 4 },
    { date: "Week 2", workouts: 5 },
    { date: "Week 3", workouts: 3 },
    { date: "Week 4", workouts: 6 },
  ];

  return (
    <div className="max-w-md mx-auto bg-white dark:bg-gray-800 min-h-screen shadow-xl">
      {/* Header */}
      <header className="gradient-bg text-white p-4 relative overflow-hidden">
        <div className="relative z-10">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                <i className="fas fa-chart-line text-white"></i>
              </div>
              <h1 className="text-xl font-bold">Progress</h1>
            </div>
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-20 bg-white/20 border-white/30 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7d">7D</SelectItem>
                <SelectItem value="30d">30D</SelectItem>
                <SelectItem value="90d">90D</SelectItem>
                <SelectItem value="1y">1Y</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16"></div>
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full translate-y-12 -translate-x-12"></div>
      </header>

      <main className="p-4 space-y-6 pb-24">
        {/* Key Stats */}
        <div className="grid grid-cols-2 gap-4">
          <Card className="card-shadow">
            <CardContent className="p-4 text-center">
              <div className="w-12 h-12 bg-emerald-100 dark:bg-emerald-900/20 rounded-full flex items-center justify-center mx-auto mb-2">
                <i className="fas fa-weight text-emerald-600 text-lg"></i>
              </div>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">-2.2</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">kg lost</p>
              <p className="text-xs text-emerald-600 dark:text-emerald-400">↓ 2.9%</p>
            </CardContent>
          </Card>

          <Card className="card-shadow">
            <CardContent className="p-4 text-center">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-2">
                <i className="fas fa-dumbbell text-primary text-lg"></i>
              </div>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">18</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">workouts</p>
              <p className="text-xs text-primary">this month</p>
            </CardContent>
          </Card>
        </div>

        {/* Weight Progress */}
        <Card className="card-shadow">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <i className="fas fa-weight text-emerald-600"></i>
              <span>Weight Progress</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={weightData}>
                  <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                  <XAxis 
                    dataKey="date" 
                    axisLine={false}
                    tickLine={false}
                    tick={{ fontSize: 12 }}
                    className="text-gray-600 dark:text-gray-400"
                  />
                  <YAxis 
                    axisLine={false}
                    tickLine={false}
                    tick={{ fontSize: 12 }}
                    className="text-gray-600 dark:text-gray-400"
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'var(--card)',
                      border: '1px solid var(--border)',
                      borderRadius: '8px',
                      color: 'var(--card-foreground)'
                    }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="weight" 
                    stroke="hsl(173, 58%, 39%)" 
                    strokeWidth={3}
                    dot={{ fill: "hsl(173, 58%, 39%)", strokeWidth: 2, r: 4 }}
                    activeDot={{ r: 6, stroke: "hsl(173, 58%, 39%)", strokeWidth: 2 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 text-center">
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Current: <span className="font-semibold text-gray-900 dark:text-white">72.8 kg</span>
              </p>
              <p className="text-xs text-emerald-600 dark:text-emerald-400 mt-1">
                Goal: 70 kg (2.8 kg to go)
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Calorie Intake */}
        <Card className="card-shadow">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <i className="fas fa-fire text-orange-500"></i>
              <span>Weekly Calories</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={calorieData}>
                  <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                  <XAxis 
                    dataKey="date"
                    axisLine={false}
                    tickLine={false}
                    tick={{ fontSize: 12 }}
                    className="text-gray-600 dark:text-gray-400"
                  />
                  <YAxis 
                    axisLine={false}
                    tickLine={false}
                    tick={{ fontSize: 12 }}
                    className="text-gray-600 dark:text-gray-400"
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'var(--card)',
                      border: '1px solid var(--border)',
                      borderRadius: '8px',
                      color: 'var(--card-foreground)'
                    }}
                  />
                  <Bar dataKey="calories" fill="hsl(43, 74%, 66%)" radius={[4, 4, 0, 0]} />
                  <Line 
                    type="monotone" 
                    dataKey="target" 
                    stroke="hsl(0, 84%, 60%)" 
                    strokeWidth={2}
                    strokeDasharray="5 5"
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 text-center">
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Daily average: <span className="font-semibold text-gray-900 dark:text-white">2,104 cal</span>
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Workout Frequency */}
        <Card className="card-shadow">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <i className="fas fa-dumbbell text-primary"></i>
              <span>Workout Frequency</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={workoutData}>
                  <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                  <XAxis 
                    dataKey="date"
                    axisLine={false}
                    tickLine={false}
                    tick={{ fontSize: 12 }}
                    className="text-gray-600 dark:text-gray-400"
                  />
                  <YAxis 
                    axisLine={false}
                    tickLine={false}
                    tick={{ fontSize: 12 }}
                    className="text-gray-600 dark:text-gray-400"
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'var(--card)',
                      border: '1px solid var(--border)',
                      borderRadius: '8px',
                      color: 'var(--card-foreground)'
                    }}
                  />
                  <Bar dataKey="workouts" fill="hsl(262, 83%, 67%)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 text-center">
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Weekly average: <span className="font-semibold text-gray-900 dark:text-white">4.5 workouts</span>
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Achievements */}
        <Card className="card-shadow">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <i className="fas fa-trophy text-yellow-500"></i>
              <span>Recent Achievements</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center space-x-3 p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg border border-yellow-200 dark:border-yellow-800">
                <div className="w-10 h-10 bg-yellow-100 dark:bg-yellow-900 rounded-full flex items-center justify-center">
                  <i className="fas fa-fire text-yellow-600"></i>
                </div>
                <div>
                  <p className="font-medium text-gray-900 dark:text-white">Week Streak!</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">7 days of hitting calorie goals</p>
                </div>
              </div>

              <div className="flex items-center space-x-3 p-3 bg-primary/5 rounded-lg border border-primary/20">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                  <i className="fas fa-dumbbell text-primary"></i>
                </div>
                <div>
                  <p className="font-medium text-gray-900 dark:text-white">Consistency Champion</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">4 weeks of regular workouts</p>
                </div>
              </div>

              <div className="flex items-center space-x-3 p-3 bg-emerald-50 dark:bg-emerald-900/20 rounded-lg border border-emerald-200 dark:border-emerald-800">
                <div className="w-10 h-10 bg-emerald-100 dark:bg-emerald-900 rounded-full flex items-center justify-center">
                  <i className="fas fa-weight text-emerald-600"></i>
                </div>
                <div>
                  <p className="font-medium text-gray-900 dark:text-white">Weight Milestone</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Lost 2kg this month</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Progress Summary */}
        <Card className="card-shadow">
          <CardHeader>
            <CardTitle>This Month Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4 text-center">
              <div>
                <p className="text-2xl font-bold text-primary">18</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Workouts completed</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-emerald-600">-2.2kg</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Weight change</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-orange-500">2,104</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Avg daily calories</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-blue-500">87%</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Goal adherence</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-1/2 transform -translate-x-1/2 max-w-md w-full bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 px-4 py-2">
        <div className="flex items-center justify-around">
          <Link href="/">
            <Button variant="ghost" className="flex flex-col items-center space-y-1 py-2 px-3 text-gray-400 dark:text-gray-500">
              <i className="fas fa-home text-lg"></i>
              <span className="text-xs">Home</span>
            </Button>
          </Link>
          <Link href="/workouts">
            <Button variant="ghost" className="flex flex-col items-center space-y-1 py-2 px-3 text-gray-400 dark:text-gray-500">
              <i className="fas fa-dumbbell text-lg"></i>
              <span className="text-xs">Workouts</span>
            </Button>
          </Link>
          <Link href="/nutrition">
            <Button variant="ghost" className="flex flex-col items-center space-y-1 py-2 px-3 text-gray-400 dark:text-gray-500">
              <i className="fas fa-utensils text-lg"></i>
              <span className="text-xs">Nutrition</span>
            </Button>
          </Link>
          <Button variant="ghost" className="flex flex-col items-center space-y-1 py-2 px-3 text-primary">
            <i className="fas fa-chart-line text-lg"></i>
            <span className="text-xs font-medium">Progress</span>
          </Button>
          <Link href="/profile">
            <Button variant="ghost" className="flex flex-col items-center space-y-1 py-2 px-3 text-gray-400 dark:text-gray-500">
              <i className="fas fa-user text-lg"></i>
              <span className="text-xs">Profile</span>
            </Button>
          </Link>
        </div>
      </nav>
    </div>
  );
}
