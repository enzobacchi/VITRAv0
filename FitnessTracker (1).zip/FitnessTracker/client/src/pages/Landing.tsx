import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-teal/5 dark:from-primary/10 dark:to-teal/10">
      <div className="max-w-md mx-auto bg-white dark:bg-gray-800 min-h-screen shadow-xl">
        <div className="gradient-bg text-white p-8 text-center relative overflow-hidden">
          <div className="relative z-10">
            <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <i className="fas fa-dumbbell text-3xl text-white"></i>
            </div>
            <h1 className="text-3xl font-bold mb-2">FitAI</h1>
            <p className="text-white/90 text-lg">Your AI-Powered Fitness Companion</p>
          </div>
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16"></div>
          <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full translate-y-12 -translate-x-12"></div>
        </div>

        <div className="p-6 space-y-6">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
              Transform Your Fitness Journey
            </h2>
            <p className="text-gray-600 dark:text-gray-400 mb-8">
              Get personalized workouts, track your nutrition, and receive AI-powered insights to reach your goals faster.
            </p>
          </div>

          <div className="space-y-4">
            <Card className="card-shadow">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                    <svg className="w-5 h-5 text-primary" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M12 2L13.09 8.26L22 9L13.09 9.74L12 16L10.91 9.74L2 9L10.91 8.26L12 2Z" fill="currentColor"/>
                      <path d="M12 8C14.21 8 16 9.79 16 12C16 14.21 14.21 16 12 16C9.79 16 8 14.21 8 12C8 9.79 9.79 8 12 8Z" stroke="currentColor" strokeWidth="1.5" fill="none"/>
                      <path d="M7 19L9 17M17 19L15 17M12 21V19" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                    </svg>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 dark:text-white">AI-Powered Plans</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Personalized workouts and nutrition tailored to you</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="card-shadow">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-emerald-100 dark:bg-emerald-900/20 rounded-full flex items-center justify-center">
                    <i className="fas fa-chart-line text-emerald-600"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 dark:text-white">Progress Tracking</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Monitor your journey with detailed analytics</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="card-shadow">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-teal/10 rounded-full flex items-center justify-center">
                    <i className="fas fa-utensils text-teal"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 dark:text-white">Smart Nutrition</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Track macros and get supplement insights</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="pt-4">
            <Button 
              onClick={() => window.location.href = '/api/login'}
              className="w-full h-12 text-lg font-semibold bg-gradient-to-r from-primary to-teal hover:from-primary/90 hover:to-teal/90"
            >
              Get Started
            </Button>
            <p className="text-center text-sm text-gray-500 dark:text-gray-400 mt-4">
              Sign in with your Google account to begin
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
