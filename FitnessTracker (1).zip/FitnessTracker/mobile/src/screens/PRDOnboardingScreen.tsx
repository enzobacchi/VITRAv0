import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { Colors } from '../utils/colors';

const { width, height } = Dimensions.get('window');

interface PRDOnboardingScreenProps {
  onComplete: (answers: Record<string, string>) => void;
}

interface Question {
  id: string;
  title: string;
  subtitle?: string;
  options: Array<{
    id: string;
    label: string;
    description: string;
    icon: keyof typeof Ionicons.glyphMap;
  }>;
}

const questions: Question[] = [
  {
    id: 'user_type',
    title: 'What describes you best?',
    subtitle: 'This helps us create your perfect plan',
    options: [
      {
        id: 'strength_first',
        label: 'Strength-First',
        description: 'Hypertrophy & macro accuracy',
        icon: 'barbell'
      },
      {
        id: 'calisthenics',
        label: 'Calisthenics Explorer',
        description: 'Skills & progressions',
        icon: 'body'
      },
      {
        id: 'endurance_hybrid',
        label: 'Endurance Hybrid',
        description: 'Running/cycling + strength',
        icon: 'bicycle'
      },
      {
        id: 'casual_starter',
        label: 'Casual Starter',
        description: 'Just getting started',
        icon: 'walk'
      },
    ],
  },
  {
    id: 'training_frequency',
    title: 'How often can you train?',
    subtitle: 'We\'ll build your schedule around this',
    options: [
      {
        id: '2-3',
        label: '2-3 times per week',
        description: 'Balanced approach',
        icon: 'calendar'
      },
      {
        id: '4-5',
        label: '4-5 times per week',
        description: 'Consistent progress',
        icon: 'calendar-outline'
      },
      {
        id: '6-7',
        label: '6-7 times per week',
        description: 'Maximum dedication',
        icon: 'flame'
      },
    ],
  },
  {
    id: 'experience_level',
    title: 'What\'s your training experience?',
    subtitle: 'This determines your program complexity',
    options: [
      {
        id: 'beginner',
        label: 'Beginner',
        description: '0-1 year experience',
        icon: 'leaf'
      },
      {
        id: 'intermediate',
        label: 'Intermediate',
        description: '1-3 years experience',
        icon: 'trending-up'
      },
      {
        id: 'advanced',
        label: 'Advanced',
        description: '3+ years experience',
        icon: 'trophy'
      },
    ],
  },
];

export default function PRDOnboardingScreen({ onComplete }: PRDOnboardingScreenProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [slideAnim] = useState(new Animated.Value(0));
  const [progressAnims] = useState(questions.map(() => new Animated.Value(0)));

  useEffect(() => {
    // Animate slide in
    Animated.spring(slideAnim, {
      toValue: 1,
      useNativeDriver: true,
      tension: 50,
      friction: 8,
    }).start();

    // Animate progress dots
    progressAnims.forEach((anim, index) => {
      if (index <= currentQuestion) {
        Animated.spring(anim, {
          toValue: 1,
          useNativeDriver: true,
          delay: index * 100,
        }).start();
      }
    });
  }, [currentQuestion]);

  const handleOptionSelect = (optionId: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    
    const newAnswers = {
      ...answers,
      [questions[currentQuestion].id]: optionId,
    };
    setAnswers(newAnswers);

    if (currentQuestion < questions.length - 1) {
      // Move to next question
      setTimeout(() => {
        setCurrentQuestion(currentQuestion + 1);
        slideAnim.setValue(0);
        Animated.spring(slideAnim, {
          toValue: 1,
          useNativeDriver: true,
          tension: 50,
          friction: 8,
        }).start();
      }, 300);
    } else {
      // Complete onboarding
      setTimeout(() => {
        onComplete(newAnswers);
      }, 500);
    }
  };

  const question = questions[currentQuestion];

  return (
    <LinearGradient colors={Colors.primaryGradient} style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.stepText}>
          {currentQuestion + 1} of {questions.length}
        </Text>
        
        {/* Animated Progress Dots */}
        <View style={styles.progressContainer}>
          {questions.map((_, index) => (
            <Animated.View
              key={index}
              style={[
                styles.progressDot,
                {
                  backgroundColor: index <= currentQuestion ? Colors.teal : Colors.gray,
                  transform: [
                    {
                      scale: progressAnims[index].interpolate({
                        inputRange: [0, 1],
                        outputRange: [0.6, 1],
                      }),
                    },
                  ],
                },
              ]}
            />
          ))}
        </View>
      </View>

      <Animated.View
        style={[
          styles.questionContainer,
          {
            opacity: slideAnim,
            transform: [
              {
                translateY: slideAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [50, 0],
                }),
              },
            ],
          },
        ]}
      >
        <Text style={styles.title}>{question.title}</Text>
        {question.subtitle && (
          <Text style={styles.subtitle}>{question.subtitle}</Text>
        )}

        <View style={styles.optionsContainer}>
          {question.options.map((option, index) => (
            <TouchableOpacity
              key={option.id}
              style={styles.optionCard}
              onPress={() => handleOptionSelect(option.id)}
              activeOpacity={0.8}
            >
              <View style={styles.optionIcon}>
                <Ionicons name={option.icon} size={24} color={Colors.teal} />
              </View>
              <View style={styles.optionContent}>
                <Text style={styles.optionLabel}>{option.label}</Text>
                <Text style={styles.optionDescription}>{option.description}</Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color={Colors.gray} />
            </TouchableOpacity>
          ))}
        </View>
      </Animated.View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 60,
  },
  header: {
    paddingHorizontal: 24,
    marginBottom: 40,
  },
  stepText: {
    color: Colors.gray,
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 16,
  },
  progressContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 8,
  },
  progressDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  questionContainer: {
    flex: 1,
    paddingHorizontal: 24,
  },
  title: {
    color: Colors.white,
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 8,
  },
  subtitle: {
    color: Colors.gray,
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 40,
  },
  optionsContainer: {
    gap: 16,
  },
  optionCard: {
    backgroundColor: Colors.surface,
    borderRadius: 16,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  optionIcon: {
    width: 48,
    height: 48,
    backgroundColor: Colors.teal + '20',
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  optionContent: {
    flex: 1,
  },
  optionLabel: {
    color: Colors.white,
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  optionDescription: {
    color: Colors.gray,
    fontSize: 14,
  },
});