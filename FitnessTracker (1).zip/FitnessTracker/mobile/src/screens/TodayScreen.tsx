import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { Colors } from '../utils/colors';

const { width } = Dimensions.get('window');

interface MacroData {
  protein: { current: number; target: number };
  carbs: { current: number; target: number };
  fats: { current: number; target: number };
  calories: { current: number; target: number };
}

interface WorkoutData {
  name: string;
  duration: number;
  exercises: number;
  completed: boolean;
}

interface RecoveryData {
  score: number | null;
  sleep: number | null;
  hrv: number | null;
  restingHR: number | null;
  deviceConnected: boolean;
}

export default function TodayScreen() {
  const [macros, setMacros] = useState<MacroData>({
    protein: { current: 85, target: 150 },
    carbs: { current: 120, target: 250 },
    fats: { current: 45, target: 70 },
    calories: { current: 1240, target: 2100 },
  });

  const [workout, setWorkout] = useState<WorkoutData>({
    name: "Upper Body Strength",
    duration: 45,
    exercises: 6,
    completed: false,
  });

  const [recovery, setRecovery] = useState<RecoveryData>({
    score: null,
    sleep: null,
    hrv: null,
    restingHR: null,
    deviceConnected: false,
  });

  const getRecoveryColor = (score: number | null) => {
    if (score === null) return Colors.gray;
    if (score >= 80) return Colors.green;
    if (score >= 60) return Colors.yellow;
    return Colors.red;
  };

  const handleConnectDevice = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    // In real app: navigate to device connection flow
    // For demo: simulate connecting a device
    setRecovery({
      score: 85,
      sleep: 7.5,
      hrv: 42,
      restingHR: 58,
      deviceConnected: true,
    });
  };

  const getMacroPercentage = (current: number, target: number) => {
    return Math.min((current / target) * 100, 100);
  };

  const handleWorkoutStart = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    // Navigate to workout details
  };

  const formatDate = () => {
    const today = new Date();
    return today.toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
    });
  };

  return (
    <LinearGradient colors={Colors.primaryGradient} style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Good morning</Text>
            <Text style={styles.date}>{formatDate()}</Text>
          </View>
          <TouchableOpacity style={styles.profileButton}>
            <Ionicons name="person-circle" size={32} color={Colors.teal} />
          </TouchableOpacity>
        </View>

        {/* Recovery Card */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Text style={styles.cardTitle}>Recovery</Text>
            {recovery.deviceConnected ? (
              <View style={[styles.recoveryBadge, { backgroundColor: getRecoveryColor(recovery.score) }]}>
                <Text style={styles.recoveryScore}>{recovery.score}%</Text>
              </View>
            ) : (
              <View style={[styles.recoveryBadge, { backgroundColor: Colors.gray }]}>
                <Text style={styles.recoveryScore}>--</Text>
              </View>
            )}
          </View>
          
          {recovery.deviceConnected ? (
            <View style={styles.recoveryMetrics}>
              <View style={styles.metric}>
                <Ionicons name="bed" size={20} color={Colors.blue} />
                <Text style={styles.metricLabel}>Sleep</Text>
                <Text style={styles.metricValue}>{recovery.sleep}h</Text>
              </View>
              <View style={styles.metric}>
                <Ionicons name="heart" size={20} color={Colors.red} />
                <Text style={styles.metricLabel}>HRV</Text>
                <Text style={styles.metricValue}>{recovery.hrv}ms</Text>
              </View>
              <View style={styles.metric}>
                <Ionicons name="pulse" size={20} color={Colors.teal} />
                <Text style={styles.metricLabel}>RHR</Text>
                <Text style={styles.metricValue}>{recovery.restingHR}</Text>
              </View>
            </View>
          ) : (
            <View style={styles.noDeviceContainer}>
              <Ionicons name="watch" size={48} color={Colors.gray} />
              <Text style={styles.noDeviceText}>Connect a wearable device</Text>
              <Text style={styles.noDeviceSubtext}>
                Track HRV, sleep, and heart rate data from Apple Watch, Garmin, or Fitbit
              </Text>
              <TouchableOpacity 
                style={styles.connectButton} 
                onPress={handleConnectDevice}
              >
                <Text style={styles.connectButtonText}>Connect Device</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>

        {/* Today's Workout */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Text style={styles.cardTitle}>Today's Workout</Text>
            <View style={styles.workoutStatus}>
              <Ionicons 
                name={workout.completed ? "checkmark-circle" : "time"} 
                size={16} 
                color={workout.completed ? Colors.green : Colors.yellow} 
              />
              <Text style={[styles.statusText, { color: workout.completed ? Colors.green : Colors.yellow }]}>
                {workout.completed ? "Complete" : "Scheduled"}
              </Text>
            </View>
          </View>
          
          <Text style={styles.workoutName}>{workout.name}</Text>
          
          <View style={styles.workoutDetails}>
            <View style={styles.workoutDetail}>
              <Ionicons name="time" size={16} color={Colors.gray} />
              <Text style={styles.workoutDetailText}>{workout.duration} min</Text>
            </View>
            <View style={styles.workoutDetail}>
              <Ionicons name="barbell" size={16} color={Colors.gray} />
              <Text style={styles.workoutDetailText}>{workout.exercises} exercises</Text>
            </View>
          </View>

          <TouchableOpacity style={styles.startButton} onPress={handleWorkoutStart}>
            <Text style={styles.startButtonText}>
              {workout.completed ? "View Details" : "Start Workout"}
            </Text>
            <Ionicons name="chevron-forward" size={20} color={Colors.background} />
          </TouchableOpacity>
        </View>

        {/* Nutrition Overview */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Text style={styles.cardTitle}>Nutrition</Text>
            <Text style={styles.caloriesText}>
              {macros.calories.current} / {macros.calories.target} cal
            </Text>
          </View>

          <View style={styles.macroGrid}>
            {Object.entries(macros).filter(([key]) => key !== 'calories').map(([key, data]) => (
              <View key={key} style={styles.macroItem}>
                <View style={styles.macroHeader}>
                  <Text style={styles.macroLabel}>{key.charAt(0).toUpperCase() + key.slice(1)}</Text>
                  <Text style={styles.macroValue}>{data.current}g</Text>
                </View>
                <View style={styles.macroBar}>
                  <View 
                    style={[
                      styles.macroProgress, 
                      { 
                        width: `${getMacroPercentage(data.current, data.target)}%`,
                        backgroundColor: key === 'protein' ? Colors.blue : 
                                       key === 'carbs' ? Colors.teal : Colors.yellow
                      }
                    ]} 
                  />
                </View>
                <Text style={styles.macroTarget}>/{data.target}g</Text>
              </View>
            ))}
          </View>

          <TouchableOpacity style={styles.logFoodButton}>
            <Ionicons name="add" size={20} color={Colors.teal} />
            <Text style={styles.logFoodText}>Log Food</Text>
          </TouchableOpacity>
        </View>

        {/* Quick Actions */}
        <View style={styles.quickActions}>
          <TouchableOpacity style={styles.actionButton}>
            <Ionicons name="barcode" size={24} color={Colors.teal} />
            <Text style={styles.actionText}>Scan</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionButton}>
            <Ionicons name="chatbubbles" size={24} color={Colors.teal} />
            <Text style={styles.actionText}>AI Coach</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionButton}>
            <Ionicons name="analytics" size={24} color={Colors.teal} />
            <Text style={styles.actionText}>Progress</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingTop: 60,
    paddingBottom: 24,
  },
  greeting: {
    color: Colors.white,
    fontSize: 28,
    fontWeight: 'bold',
  },
  date: {
    color: Colors.gray,
    fontSize: 16,
    marginTop: 4,
  },
  profileButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  card: {
    backgroundColor: Colors.surface,
    marginHorizontal: 24,
    marginBottom: 16,
    borderRadius: 16,
    padding: 20,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  cardTitle: {
    color: Colors.white,
    fontSize: 18,
    fontWeight: 'bold',
  },
  recoveryBadge: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  recoveryScore: {
    color: Colors.background,
    fontSize: 14,
    fontWeight: 'bold',
  },
  recoveryMetrics: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  metric: {
    alignItems: 'center',
    flex: 1,
  },
  metricLabel: {
    color: Colors.gray,
    fontSize: 12,
    marginTop: 4,
  },
  metricValue: {
    color: Colors.white,
    fontSize: 16,
    fontWeight: 'bold',
    marginTop: 2,
  },
  workoutStatus: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  workoutName: {
    color: Colors.white,
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  workoutDetails: {
    flexDirection: 'row',
    gap: 16,
    marginBottom: 16,
  },
  workoutDetail: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  workoutDetailText: {
    color: Colors.gray,
    fontSize: 14,
  },
  startButton: {
    backgroundColor: Colors.teal,
    borderRadius: 12,
    height: 48,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  startButtonText: {
    color: Colors.background,
    fontSize: 16,
    fontWeight: 'bold',
  },
  caloriesText: {
    color: Colors.gray,
    fontSize: 14,
    fontWeight: '600',
  },
  macroGrid: {
    gap: 12,
  },
  macroItem: {
    marginBottom: 8,
  },
  macroHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  macroLabel: {
    color: Colors.gray,
    fontSize: 14,
    fontWeight: '600',
  },
  macroValue: {
    color: Colors.white,
    fontSize: 14,
    fontWeight: 'bold',
  },
  macroBar: {
    height: 4,
    backgroundColor: Colors.darkGray,
    borderRadius: 2,
    marginBottom: 2,
  },
  macroProgress: {
    height: 4,
    borderRadius: 2,
  },
  macroTarget: {
    color: Colors.gray,
    fontSize: 12,
    textAlign: 'right',
  },
  logFoodButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginTop: 12,
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: Colors.teal,
  },
  logFoodText: {
    color: Colors.teal,
    fontSize: 16,
    fontWeight: '600',
  },
  quickActions: {
    flexDirection: 'row',
    paddingHorizontal: 24,
    paddingBottom: 24,
    gap: 12,
  },
  actionButton: {
    flex: 1,
    backgroundColor: Colors.surface,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    gap: 8,
  },
  actionText: {
    color: Colors.white,
    fontSize: 12,
    fontWeight: '600',
  },
  noDeviceContainer: {
    alignItems: 'center',
    paddingVertical: 20,
  },
  noDeviceText: {
    color: Colors.white,
    fontSize: 16,
    fontWeight: 'bold',
    marginTop: 12,
    textAlign: 'center',
  },
  noDeviceSubtext: {
    color: Colors.gray,
    fontSize: 14,
    textAlign: 'center',
    marginTop: 8,
    lineHeight: 20,
  },
  connectButton: {
    backgroundColor: Colors.teal,
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 24,
    marginTop: 16,
  },
  connectButtonText: {
    color: Colors.background,
    fontSize: 14,
    fontWeight: 'bold',
  },
});