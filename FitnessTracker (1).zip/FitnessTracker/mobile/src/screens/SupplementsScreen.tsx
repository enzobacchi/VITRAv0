import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Modal,
  TextInput,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { Colors } from '../utils/colors';

interface Supplement {
  id: string;
  name: string;
  dosage: string;
  unit: string;
  frequency: string;
  taken: boolean;
  timesTaken: number;
  totalDoses: number;
  category: 'vitamin' | 'mineral' | 'protein' | 'performance' | 'other';
}

interface SupplementAnalysis {
  insights: string[];
  recommendations: string[];
  warnings: string[];
  deficiencies: string[];
  excesses: string[];
}

export default function SupplementsScreen() {
  const [supplements, setSupplements] = useState<Supplement[]>([
    {
      id: '1',
      name: 'Vitamin D3',
      dosage: '2000',
      unit: 'IU',
      frequency: 'Daily',
      taken: true,
      timesTaken: 1,
      totalDoses: 1,
      category: 'vitamin',
    },
    {
      id: '2',
      name: 'Whey Protein',
      dosage: '25',
      unit: 'g',
      frequency: '2x Daily',
      taken: false,
      timesTaken: 1,
      totalDoses: 2,
      category: 'protein',
    },
    {
      id: '3',
      name: 'Creatine',
      dosage: '5',
      unit: 'g',
      frequency: 'Daily',
      taken: true,
      timesTaken: 1,
      totalDoses: 1,
      category: 'performance',
    },
    {
      id: '4',
      name: 'Omega-3',
      dosage: '1000',
      unit: 'mg',
      frequency: 'Daily',
      taken: false,
      timesTaken: 0,
      totalDoses: 1,
      category: 'other',
    },
  ]);

  const [analysis, setAnalysis] = useState<SupplementAnalysis>({
    insights: [
      'Your vitamin D levels are optimized for bone health',
      'Protein intake supports muscle recovery',
      'Consider timing creatine post-workout for better absorption',
    ],
    recommendations: [
      'Add magnesium to support vitamin D absorption',
      'Consider B-complex for energy metabolism',
    ],
    warnings: [],
    deficiencies: ['Magnesium', 'Vitamin B12'],
    excesses: [],
  });

  const [addModalVisible, setAddModalVisible] = useState(false);
  const [newSupplement, setNewSupplement] = useState({
    name: '',
    dosage: '',
    unit: 'mg',
    frequency: 'Daily',
  });

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'vitamin': return Colors.yellow;
      case 'mineral': return Colors.blue;
      case 'protein': return Colors.teal;
      case 'performance': return Colors.red;
      default: return Colors.gray;
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'vitamin': return 'sunny';
      case 'mineral': return 'diamond';
      case 'protein': return 'barbell';
      case 'performance': return 'flash';
      default: return 'medical';
    }
  };

  const handleToggleSupplement = (id: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setSupplements(prev => prev.map(supplement => {
      if (supplement.id === id) {
        const newTimesTaken = supplement.taken ? 
          Math.max(0, supplement.timesTaken - 1) : 
          Math.min(supplement.totalDoses, supplement.timesTaken + 1);
        
        return {
          ...supplement,
          taken: newTimesTaken === supplement.totalDoses,
          timesTaken: newTimesTaken,
        };
      }
      return supplement;
    }));
  };

  const handleAnalyzeSupplements = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    // Call AI analysis endpoint
    try {
      const response = await fetch('/api/supplements/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ supplements }),
      });
      if (response.ok) {
        const result = await response.json();
        setAnalysis(result);
      }
    } catch (error) {
      console.error('Analysis failed:', error);
    }
  };

  const handleAddSupplement = () => {
    if (!newSupplement.name || !newSupplement.dosage) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }

    const supplement: Supplement = {
      id: Date.now().toString(),
      name: newSupplement.name,
      dosage: newSupplement.dosage,
      unit: newSupplement.unit,
      frequency: newSupplement.frequency,
      taken: false,
      timesTaken: 0,
      totalDoses: newSupplement.frequency.includes('2x') ? 2 : 1,
      category: 'other',
    };

    setSupplements(prev => [...prev, supplement]);
    setNewSupplement({ name: '', dosage: '', unit: 'mg', frequency: 'Daily' });
    setAddModalVisible(false);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  const renderSupplementCard = (supplement: Supplement) => (
    <TouchableOpacity
      key={supplement.id}
      style={[
        styles.supplementCard,
        supplement.taken && styles.supplementCardTaken,
      ]}
      onPress={() => handleToggleSupplement(supplement.id)}
    >
      <View style={styles.supplementHeader}>
        <View style={styles.supplementInfo}>
          <View style={styles.supplementNameRow}>
            <View style={[
              styles.categoryIcon,
              { backgroundColor: getCategoryColor(supplement.category) }
            ]}>
              <Ionicons 
                name={getCategoryIcon(supplement.category)} 
                size={16} 
                color={Colors.background} 
              />
            </View>
            <Text style={[
              styles.supplementName,
              supplement.taken && styles.supplementNameTaken,
            ]}>
              {supplement.name}
            </Text>
          </View>
          <Text style={styles.supplementDosage}>
            {supplement.dosage} {supplement.unit} • {supplement.frequency}
          </Text>
        </View>
        
        <View style={styles.supplementStatus}>
          <Text style={styles.progressText}>
            {supplement.timesTaken}/{supplement.totalDoses}
          </Text>
          <View style={[
            styles.checkBox,
            supplement.taken && styles.checkBoxTaken,
          ]}>
            {supplement.taken && (
              <Ionicons name="checkmark" size={16} color={Colors.background} />
            )}
          </View>
        </View>
      </View>

      <View style={styles.progressBar}>
        <View style={styles.progressTrack} />
        <View 
          style={[
            styles.progressFill,
            { 
              width: `${(supplement.timesTaken / supplement.totalDoses) * 100}%`,
              backgroundColor: getCategoryColor(supplement.category),
            }
          ]} 
        />
      </View>
    </TouchableOpacity>
  );

  const renderAnalysisSection = (title: string, items: string[], color: string, icon: string) => {
    if (items.length === 0) return null;

    return (
      <View style={styles.analysisSection}>
        <View style={styles.analysisSectionHeader}>
          <Ionicons name={icon} size={20} color={color} />
          <Text style={[styles.analysisSectionTitle, { color }]}>{title}</Text>
        </View>
        {items.map((item, index) => (
          <Text key={index} style={styles.analysisItem}>• {item}</Text>
        ))}
      </View>
    );
  };

  return (
    <LinearGradient colors={Colors.primaryGradient} style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Supplements</Text>
        <TouchableOpacity 
          style={styles.analyzeButton}
          onPress={handleAnalyzeSupplements}
        >
          <Ionicons name="analytics" size={20} color={Colors.background} />
          <Text style={styles.analyzeButtonText}>AI Analysis</Text>
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Daily Progress */}
        <View style={styles.progressOverview}>
          <Text style={styles.progressTitle}>Today's Progress</Text>
          <View style={styles.progressStats}>
            <View style={styles.progressStat}>
              <Text style={styles.progressStatValue}>
                {supplements.filter(s => s.taken).length}
              </Text>
              <Text style={styles.progressStatLabel}>Completed</Text>
            </View>
            <View style={styles.progressStat}>
              <Text style={styles.progressStatValue}>
                {supplements.reduce((sum, s) => sum + s.timesTaken, 0)}
              </Text>
              <Text style={styles.progressStatLabel}>Total Doses</Text>
            </View>
            <View style={styles.progressStat}>
              <Text style={styles.progressStatValue}>
                {Math.round((supplements.filter(s => s.taken).length / supplements.length) * 100)}%
              </Text>
              <Text style={styles.progressStatLabel}>Adherence</Text>
            </View>
          </View>
        </View>

        {/* Supplements List */}
        <View style={styles.supplementsList}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Your Supplements</Text>
            <TouchableOpacity onPress={() => setAddModalVisible(true)}>
              <Ionicons name="add" size={24} color={Colors.teal} />
            </TouchableOpacity>
          </View>
          
          {supplements.map(renderSupplementCard)}
        </View>

        {/* AI Analysis */}
        <View style={styles.analysisCard}>
          <Text style={styles.analysisTitle}>AI Insights</Text>
          
          {renderAnalysisSection(
            'Insights', 
            analysis.insights, 
            Colors.teal, 
            'bulb'
          )}
          
          {renderAnalysisSection(
            'Recommendations', 
            analysis.recommendations, 
            Colors.blue, 
            'medical'
          )}
          
          {renderAnalysisSection(
            'Potential Deficiencies', 
            analysis.deficiencies, 
            Colors.yellow, 
            'warning'
          )}
          
          {renderAnalysisSection(
            'Warnings', 
            analysis.warnings, 
            Colors.red, 
            'alert-circle'
          )}
        </View>
      </ScrollView>

      {/* Add Supplement Modal */}
      <Modal
        visible={addModalVisible}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <TouchableOpacity onPress={() => setAddModalVisible(false)}>
              <Text style={styles.modalCancelText}>Cancel</Text>
            </TouchableOpacity>
            <Text style={styles.modalTitle}>Add Supplement</Text>
            <TouchableOpacity onPress={handleAddSupplement}>
              <Text style={styles.modalDoneText}>Add</Text>
            </TouchableOpacity>
          </View>
          
          <ScrollView style={styles.modalContent}>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Name *</Text>
              <TextInput
                style={styles.textInput}
                placeholder="e.g. Vitamin C"
                placeholderTextColor={Colors.gray}
                value={newSupplement.name}
                onChangeText={(text) => setNewSupplement(prev => ({ ...prev, name: text }))}
              />
            </View>

            <View style={styles.inputRow}>
              <View style={[styles.inputGroup, { flex: 2 }]}>
                <Text style={styles.inputLabel}>Dosage *</Text>
                <TextInput
                  style={styles.textInput}
                  placeholder="1000"
                  placeholderTextColor={Colors.gray}
                  value={newSupplement.dosage}
                  onChangeText={(text) => setNewSupplement(prev => ({ ...prev, dosage: text }))}
                  keyboardType="numeric"
                />
              </View>
              <View style={[styles.inputGroup, { flex: 1 }]}>
                <Text style={styles.inputLabel}>Unit</Text>
                <View style={styles.pickerContainer}>
                  <Text style={styles.pickerText}>{newSupplement.unit}</Text>
                </View>
              </View>
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Frequency</Text>
              <View style={styles.frequencyOptions}>
                {['Daily', '2x Daily', 'Weekly'].map((freq) => (
                  <TouchableOpacity
                    key={freq}
                    style={[
                      styles.frequencyOption,
                      newSupplement.frequency === freq && styles.frequencyOptionSelected,
                    ]}
                    onPress={() => setNewSupplement(prev => ({ ...prev, frequency: freq }))}
                  >
                    <Text style={[
                      styles.frequencyOptionText,
                      newSupplement.frequency === freq && styles.frequencyOptionTextSelected,
                    ]}>
                      {freq}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          </ScrollView>
        </View>
      </Modal>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingTop: 60,
    paddingBottom: 16,
  },
  title: {
    color: Colors.white,
    fontSize: 28,
    fontWeight: 'bold',
  },
  analyzeButton: {
    backgroundColor: Colors.teal,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    gap: 6,
  },
  analyzeButtonText: {
    color: Colors.background,
    fontSize: 14,
    fontWeight: 'bold',
  },
  progressOverview: {
    backgroundColor: Colors.surface,
    marginHorizontal: 24,
    marginBottom: 16,
    borderRadius: 16,
    padding: 20,
  },
  progressTitle: {
    color: Colors.white,
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  progressStats: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  progressStat: {
    alignItems: 'center',
  },
  progressStatValue: {
    color: Colors.white,
    fontSize: 24,
    fontWeight: 'bold',
  },
  progressStatLabel: {
    color: Colors.gray,
    fontSize: 12,
    marginTop: 4,
  },
  supplementsList: {
    paddingHorizontal: 24,
    marginBottom: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    color: Colors.white,
    fontSize: 18,
    fontWeight: 'bold',
  },
  supplementCard: {
    backgroundColor: Colors.surface,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  supplementCardTaken: {
    borderColor: Colors.green,
    backgroundColor: Colors.darkGray,
  },
  supplementHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  supplementInfo: {
    flex: 1,
  },
  supplementNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 4,
  },
  categoryIcon: {
    width: 24,
    height: 24,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  supplementName: {
    color: Colors.white,
    fontSize: 16,
    fontWeight: 'bold',
    flex: 1,
  },
  supplementNameTaken: {
    color: Colors.gray,
  },
  supplementDosage: {
    color: Colors.gray,
    fontSize: 14,
  },
  supplementStatus: {
    alignItems: 'center',
    gap: 4,
  },
  progressText: {
    color: Colors.gray,
    fontSize: 12,
    fontWeight: '600',
  },
  checkBox: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: Colors.gray,
    justifyContent: 'center',
    alignItems: 'center',
  },
  checkBoxTaken: {
    backgroundColor: Colors.green,
    borderColor: Colors.green,
  },
  progressBar: {
    height: 4,
    borderRadius: 2,
    position: 'relative',
  },
  progressTrack: {
    position: 'absolute',
    width: '100%',
    height: 4,
    backgroundColor: Colors.darkGray,
    borderRadius: 2,
  },
  progressFill: {
    height: 4,
    borderRadius: 2,
  },
  analysisCard: {
    backgroundColor: Colors.surface,
    marginHorizontal: 24,
    marginBottom: 24,
    borderRadius: 16,
    padding: 20,
  },
  analysisTitle: {
    color: Colors.white,
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  analysisSection: {
    marginBottom: 16,
  },
  analysisSectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 8,
  },
  analysisSectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  analysisItem: {
    color: Colors.lightGray,
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 4,
  },
  modalContainer: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingTop: 60,
    paddingBottom: 16,
  },
  modalCancelText: {
    color: Colors.gray,
    fontSize: 16,
  },
  modalTitle: {
    color: Colors.white,
    fontSize: 18,
    fontWeight: 'bold',
  },
  modalDoneText: {
    color: Colors.teal,
    fontSize: 16,
    fontWeight: '600',
  },
  modalContent: {
    flex: 1,
    paddingHorizontal: 24,
  },
  inputGroup: {
    marginBottom: 20,
  },
  inputRow: {
    flexDirection: 'row',
    gap: 12,
  },
  inputLabel: {
    color: Colors.white,
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
  },
  textInput: {
    backgroundColor: Colors.surface,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    color: Colors.white,
    fontSize: 16,
  },
  pickerContainer: {
    backgroundColor: Colors.surface,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  pickerText: {
    color: Colors.white,
    fontSize: 16,
  },
  frequencyOptions: {
    flexDirection: 'row',
    gap: 8,
  },
  frequencyOption: {
    flex: 1,
    backgroundColor: Colors.surface,
    borderRadius: 12,
    paddingVertical: 12,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
  },
  frequencyOptionSelected: {
    borderColor: Colors.teal,
    backgroundColor: Colors.teal,
  },
  frequencyOptionText: {
    color: Colors.white,
    fontSize: 14,
    fontWeight: '600',
  },
  frequencyOptionTextSelected: {
    color: Colors.background,
  },
});