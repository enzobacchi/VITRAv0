import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  PanGestureHandler,
  State,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { Colors } from '../utils/colors';

interface Exercise {
  id: string;
  name: string;
  sets: string;
  reps: string;
  weight?: string;
  notes?: string;
}

interface WorkoutDay {
  id: string;
  day: string;
  name: string;
  exercises: Exercise[];
}

interface PlanEditorScreenProps {
  workoutPlan: WorkoutDay[];
  onSave: (plan: WorkoutDay[]) => void;
  onBack: () => void;
}

export default function PlanEditorScreen({ workoutPlan, onSave, onBack }: PlanEditorScreenProps) {
  const [plan, setPlan] = useState<WorkoutDay[]>(workoutPlan);
  const [selectedDay, setSelectedDay] = useState(0);
  const [draggedExercise, setDraggedExercise] = useState<string | null>(null);

  const handleExerciseReorder = (fromIndex: number, toIndex: number) => {
    const newPlan = [...plan];
    const currentDay = newPlan[selectedDay];
    const exercises = [...currentDay.exercises];
    
    const [movedExercise] = exercises.splice(fromIndex, 1);
    exercises.splice(toIndex, 0, movedExercise);
    
    newPlan[selectedDay] = { ...currentDay, exercises };
    setPlan(newPlan);
    
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleDeleteExercise = (exerciseIndex: number) => {
    Alert.alert(
      'Delete Exercise',
      'Are you sure you want to remove this exercise?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => {
            const newPlan = [...plan];
            const currentDay = newPlan[selectedDay];
            const exercises = currentDay.exercises.filter((_, index) => index !== exerciseIndex);
            newPlan[selectedDay] = { ...currentDay, exercises };
            setPlan(newPlan);
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          },
        },
      ]
    );
  };

  const handleDuplicateDay = () => {
    const currentDay = plan[selectedDay];
    const duplicatedDay: WorkoutDay = {
      id: Date.now().toString(),
      day: `${currentDay.day} (Copy)`,
      name: `${currentDay.name} - Copy`,
      exercises: currentDay.exercises.map(ex => ({ ...ex, id: Date.now().toString() + Math.random() })),
    };
    
    setPlan([...plan, duplicatedDay]);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  const handleAITweak = (context: string, exerciseIndex?: number) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    
    // Simulate AI modification
    Alert.alert(
      'AI Workout Tweak',
      `Would you like to modify this ${context}?`,
      [
        { text: 'Make it shorter', onPress: () => applyAITweak('shorter', exerciseIndex) },
        { text: 'Make it harder', onPress: () => applyAITweak('harder', exerciseIndex) },
        { text: 'Replace exercise', onPress: () => applyAITweak('replace', exerciseIndex) },
        { text: 'Cancel', style: 'cancel' },
      ]
    );
  };

  const applyAITweak = (modification: string, exerciseIndex?: number) => {
    const newPlan = [...plan];
    const currentDay = newPlan[selectedDay];
    
    if (exerciseIndex !== undefined) {
      // Modify specific exercise
      const exercise = currentDay.exercises[exerciseIndex];
      let modifiedExercise = { ...exercise };
      
      switch (modification) {
        case 'shorter':
          modifiedExercise.sets = (parseInt(exercise.sets) - 1).toString();
          break;
        case 'harder':
          modifiedExercise.reps = exercise.reps.includes('-') 
            ? exercise.reps.replace(/(\d+)-(\d+)/, (_, start, end) => `${parseInt(start) + 2}-${parseInt(end) + 2}`)
            : (parseInt(exercise.reps) + 3).toString();
          break;
        case 'replace':
          modifiedExercise.name = getAlternativeExercise(exercise.name);
          break;
      }
      
      currentDay.exercises[exerciseIndex] = modifiedExercise;
    } else {
      // Modify entire workout
      if (modification === 'shorter') {
        currentDay.exercises = currentDay.exercises.slice(0, -1);
      } else if (modification === 'harder') {
        currentDay.exercises.forEach(ex => {
          ex.sets = (parseInt(ex.sets) + 1).toString();
        });
      }
    }
    
    newPlan[selectedDay] = currentDay;
    setPlan(newPlan);
    
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  const getAlternativeExercise = (exerciseName: string): string => {
    const alternatives: Record<string, string[]> = {
      'Bench Press': ['Incline Dumbbell Press', 'Push-ups', 'Dumbbell Flyes'],
      'Squat': ['Leg Press', 'Goblet Squats', 'Lunges'],
      'Pull-ups': ['Lat Pulldowns', 'Assisted Pull-ups', 'Cable Rows'],
      'Deadlift': ['Romanian Deadlift', 'Sumo Deadlift', 'Trap Bar Deadlift'],
    };
    
    const exerciseAlts = alternatives[exerciseName] || ['Modified Exercise'];
    return exerciseAlts[Math.floor(Math.random() * exerciseAlts.length)];
  };

  const renderExerciseCard = (exercise: Exercise, index: number) => (
    <View key={exercise.id} style={styles.exerciseCard}>
      <View style={styles.dragHandle}>
        <Ionicons name="reorder-three" size={20} color={Colors.gray} />
      </View>
      
      <View style={styles.exerciseContent}>
        <Text style={styles.exerciseName}>{exercise.name}</Text>
        <View style={styles.exerciseDetails}>
          <Text style={styles.exerciseDetailText}>{exercise.sets} sets</Text>
          <Text style={styles.exerciseDetailText}>•</Text>
          <Text style={styles.exerciseDetailText}>{exercise.reps} reps</Text>
          {exercise.weight && (
            <>
              <Text style={styles.exerciseDetailText}>•</Text>
              <Text style={styles.exerciseDetailText}>{exercise.weight}</Text>
            </>
          )}
        </View>
        {exercise.notes && (
          <Text style={styles.exerciseNotes}>{exercise.notes}</Text>
        )}
      </View>
      
      <View style={styles.exerciseActions}>
        <TouchableOpacity 
          style={styles.actionButton}
          onPress={() => handleAITweak('exercise', index)}
        >
          <Ionicons name="sparkles" size={16} color={Colors.teal} />
          <Text style={styles.actionButtonText}>Tweak</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.deleteButton}
          onPress={() => handleDeleteExercise(index)}
        >
          <Ionicons name="trash" size={16} color={Colors.red} />
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <LinearGradient colors={Colors.primaryGradient} style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color={Colors.white} />
        </TouchableOpacity>
        <Text style={styles.title}>Edit Plan</Text>
        <TouchableOpacity onPress={() => onSave(plan)} style={styles.saveButton}>
          <Text style={styles.saveButtonText}>Save</Text>
        </TouchableOpacity>
      </View>

      {/* Day Selector */}
      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        style={styles.daySelector}
        contentContainerStyle={styles.daySelectorContent}
      >
        {plan.map((day, index) => (
          <TouchableOpacity
            key={day.id}
            style={[
              styles.dayTab,
              selectedDay === index && styles.dayTabActive
            ]}
            onPress={() => setSelectedDay(index)}
          >
            <Text style={[
              styles.dayTabText,
              selectedDay === index && styles.dayTabTextActive
            ]}>
              {day.day}
            </Text>
            <Text style={[
              styles.dayTabSubtext,
              selectedDay === index && styles.dayTabSubtextActive
            ]}>
              {day.name}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.workoutHeader}>
          <Text style={styles.workoutTitle}>{plan[selectedDay]?.name}</Text>
          <TouchableOpacity 
            style={styles.aiTweakButton}
            onPress={() => handleAITweak('workout')}
          >
            <Ionicons name="sparkles" size={20} color={Colors.teal} />
            <Text style={styles.aiTweakButtonText}>AI Tweak Workout</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.exercisesList}>
          {plan[selectedDay]?.exercises.map((exercise, index) => 
            renderExerciseCard(exercise, index)
          )}
        </View>

        {/* Action Buttons */}
        <View style={styles.actionButtons}>
          <TouchableOpacity style={styles.actionButtonLarge} onPress={handleDuplicateDay}>
            <Ionicons name="copy" size={20} color={Colors.teal} />
            <Text style={styles.actionButtonLargeText}>Duplicate Day</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.actionButtonLarge}>
            <Ionicons name="add" size={20} color={Colors.teal} />
            <Text style={styles.actionButtonLargeText}>Add Exercise</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 24,
    paddingTop: 60,
    paddingBottom: 16,
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
  },
  title: {
    color: Colors.white,
    fontSize: 20,
    fontWeight: 'bold',
    flex: 1,
    textAlign: 'center',
  },
  saveButton: {
    backgroundColor: Colors.teal,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  saveButtonText: {
    color: Colors.background,
    fontSize: 14,
    fontWeight: 'bold',
  },
  daySelector: {
    maxHeight: 80,
  },
  daySelectorContent: {
    paddingHorizontal: 24,
    gap: 12,
  },
  dayTab: {
    backgroundColor: Colors.surface,
    borderRadius: 12,
    padding: 12,
    minWidth: 100,
    alignItems: 'center',
  },
  dayTabActive: {
    backgroundColor: Colors.teal,
  },
  dayTabText: {
    color: Colors.white,
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 2,
  },
  dayTabTextActive: {
    color: Colors.background,
  },
  dayTabSubtext: {
    color: Colors.gray,
    fontSize: 10,
  },
  dayTabSubtextActive: {
    color: Colors.background,
    opacity: 0.8,
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
    paddingTop: 16,
  },
  workoutHeader: {
    marginBottom: 24,
  },
  workoutTitle: {
    color: Colors.white,
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  aiTweakButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.surface,
    borderRadius: 12,
    padding: 12,
    gap: 8,
    alignSelf: 'flex-start',
  },
  aiTweakButtonText: {
    color: Colors.teal,
    fontSize: 14,
    fontWeight: '600',
  },
  exercisesList: {
    gap: 12,
    marginBottom: 24,
  },
  exerciseCard: {
    backgroundColor: Colors.surface,
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  dragHandle: {
    padding: 4,
  },
  exerciseContent: {
    flex: 1,
  },
  exerciseName: {
    color: Colors.white,
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  exerciseDetails: {
    flexDirection: 'row',
    gap: 8,
    alignItems: 'center',
  },
  exerciseDetailText: {
    color: Colors.gray,
    fontSize: 14,
  },
  exerciseNotes: {
    color: Colors.gray,
    fontSize: 12,
    marginTop: 4,
    fontStyle: 'italic',
  },
  exerciseActions: {
    flexDirection: 'row',
    gap: 8,
    alignItems: 'center',
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.teal + '20',
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 6,
    gap: 4,
  },
  actionButtonText: {
    color: Colors.teal,
    fontSize: 12,
    fontWeight: '600',
  },
  deleteButton: {
    padding: 8,
  },
  actionButtons: {
    gap: 12,
    paddingBottom: 24,
  },
  actionButtonLarge: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.surface,
    borderRadius: 12,
    padding: 16,
    gap: 8,
    borderWidth: 1,
    borderColor: Colors.teal,
  },
  actionButtonLargeText: {
    color: Colors.teal,
    fontSize: 16,
    fontWeight: '600',
  },
});