import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { Colors } from '../utils/colors';

const { width } = Dimensions.get('window');

interface Exercise {
  name: string;
  sets: number;
  reps: string;
  weight?: string;
  completed: boolean;
}

interface Workout {
  id: string;
  name: string;
  date: string;
  duration: number;
  difficulty: 'Easy' | 'Moderate' | 'Hard';
  exercises: Exercise[];
  completed: boolean;
}

const workoutData: Workout[] = [
  {
    id: '1',
    name: 'Upper Body Strength',
    date: '2025-06-22',
    duration: 45,
    difficulty: 'Moderate',
    completed: false,
    exercises: [
      { name: 'Bench Press', sets: 4, reps: '8-10', weight: '185 lbs', completed: false },
      { name: 'Pull-ups', sets: 3, reps: '6-8', completed: false },
      { name: 'Shoulder Press', sets: 3, reps: '10-12', weight: '135 lbs', completed: false },
      { name: 'Barbell Rows', sets: 4, reps: '8-10', weight: '155 lbs', completed: false },
      { name: 'Dips', sets: 3, reps: '10-12', completed: false },
      { name: 'Face Pulls', sets: 3, reps: '15-20', weight: '40 lbs', completed: false },
    ],
  },
  {
    id: '2',
    name: 'Lower Body Power',
    date: '2025-06-23',
    duration: 50,
    difficulty: 'Hard',
    completed: false,
    exercises: [
      { name: 'Squats', sets: 5, reps: '5', weight: '225 lbs', completed: false },
      { name: 'Romanian Deadlifts', sets: 4, reps: '8-10', weight: '185 lbs', completed: false },
      { name: 'Bulgarian Split Squats', sets: 3, reps: '10 each', completed: false },
      { name: 'Hip Thrusts', sets: 3, reps: '12-15', weight: '155 lbs', completed: false },
    ],
  },
];

export default function WorkoutsScreen() {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [workouts, setWorkouts] = useState(workoutData);

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Easy': return Colors.green;
      case 'Moderate': return Colors.yellow;
      case 'Hard': return Colors.red;
      default: return Colors.gray;
    }
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
    });
  };

  const handleWorkoutPress = (workoutId: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    // Navigate to workout detail screen
  };

  const handleGenerateWorkout = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    // Call AI to generate new workout
  };

  const renderCalendarHeader = () => {
    const dates = [];
    const today = new Date();
    
    for (let i = -3; i <= 3; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);
      dates.push(date);
    }

    return (
      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        style={styles.calendarContainer}
        contentContainerStyle={styles.calendarContent}
      >
        {dates.map((date, index) => {
          const isSelected = date.toDateString() === selectedDate.toDateString();
          const isToday = date.toDateString() === today.toDateString();
          
          return (
            <TouchableOpacity
              key={index}
              style={[
                styles.dateItem,
                isSelected && styles.dateItemSelected,
              ]}
              onPress={() => setSelectedDate(date)}
            >
              <Text style={[
                styles.dayText,
                isSelected && styles.dayTextSelected,
              ]}>
                {date.toLocaleDateString('en-US', { weekday: 'short' })}
              </Text>
              <Text style={[
                styles.dateText,
                isSelected && styles.dateTextSelected,
                isToday && styles.todayText,
              ]}>
                {date.getDate()}
              </Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>
    );
  };

  const renderWorkoutCard = (workout: Workout) => (
    <TouchableOpacity
      key={workout.id}
      style={styles.workoutCard}
      onPress={() => handleWorkoutPress(workout.id)}
    >
      <View style={styles.workoutHeader}>
        <View style={styles.workoutInfo}>
          <Text style={styles.workoutName}>{workout.name}</Text>
          <Text style={styles.workoutDate}>{formatDate(workout.date)}</Text>
        </View>
        <View style={[
          styles.difficultyBadge,
          { backgroundColor: getDifficultyColor(workout.difficulty) }
        ]}>
          <Text style={styles.difficultyText}>{workout.difficulty}</Text>
        </View>
      </View>

      <View style={styles.workoutStats}>
        <View style={styles.stat}>
          <Ionicons name="time" size={16} color={Colors.blue} />
          <Text style={styles.statText}>{workout.duration} min</Text>
        </View>
        <View style={styles.stat}>
          <Ionicons name="barbell" size={16} color={Colors.teal} />
          <Text style={styles.statText}>{workout.exercises.length} exercises</Text>
        </View>
        <View style={styles.stat}>
          <Ionicons 
            name={workout.completed ? "checkmark-circle" : "time"} 
            size={16} 
            color={workout.completed ? Colors.green : Colors.yellow} 
          />
          <Text style={styles.statText}>
            {workout.completed ? "Complete" : "Scheduled"}
          </Text>
        </View>
      </View>

      <View style={styles.exercisePreview}>
        {workout.exercises.slice(0, 3).map((exercise, index) => (
          <Text key={index} style={styles.exerciseText}>
            • {exercise.name} {exercise.sets}x{exercise.reps}
          </Text>
        ))}
        {workout.exercises.length > 3 && (
          <Text style={styles.moreExercises}>
            +{workout.exercises.length - 3} more exercises
          </Text>
        )}
      </View>

      <View style={styles.workoutActions}>
        <TouchableOpacity style={styles.actionButton}>
          <Ionicons name="play" size={16} color={Colors.teal} />
          <Text style={styles.actionButtonText}>Start</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.actionButton}>
          <Ionicons name="create" size={16} color={Colors.blue} />
          <Text style={styles.actionButtonText}>Edit</Text>
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );

  return (
    <LinearGradient colors={Colors.primaryGradient} style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Workouts</Text>
        <TouchableOpacity 
          style={styles.generateButton}
          onPress={handleGenerateWorkout}
        >
          <Ionicons name="sparkles" size={20} color={Colors.background} />
          <Text style={styles.generateButtonText}>AI Generate</Text>
        </TouchableOpacity>
      </View>

      {renderCalendarHeader()}

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.workoutsList}>
          {workouts.map(renderWorkoutCard)}
        </View>

        <TouchableOpacity style={styles.addWorkoutButton}>
          <Ionicons name="add" size={24} color={Colors.teal} />
          <Text style={styles.addWorkoutText}>Create Custom Workout</Text>
        </TouchableOpacity>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingTop: 60,
    paddingBottom: 16,
  },
  title: {
    color: Colors.white,
    fontSize: 28,
    fontWeight: 'bold',
  },
  generateButton: {
    backgroundColor: Colors.teal,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    gap: 6,
  },
  generateButtonText: {
    color: Colors.background,
    fontSize: 14,
    fontWeight: 'bold',
  },
  calendarContainer: {
    marginBottom: 16,
  },
  calendarContent: {
    paddingHorizontal: 20,
    gap: 8,
  },
  dateItem: {
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 12,
    minWidth: 60,
  },
  dateItemSelected: {
    backgroundColor: Colors.teal,
  },
  dayText: {
    color: Colors.gray,
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 4,
  },
  dayTextSelected: {
    color: Colors.background,
  },
  dateText: {
    color: Colors.white,
    fontSize: 16,
    fontWeight: 'bold',
  },
  dateTextSelected: {
    color: Colors.background,
  },
  todayText: {
    color: Colors.teal,
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
  },
  workoutsList: {
    gap: 16,
  },
  workoutCard: {
    backgroundColor: Colors.surface,
    borderRadius: 16,
    padding: 20,
  },
  workoutHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  workoutInfo: {
    flex: 1,
  },
  workoutName: {
    color: Colors.white,
    fontSize: 18,
    fontWeight: 'bold',
  },
  workoutDate: {
    color: Colors.gray,
    fontSize: 14,
    marginTop: 2,
  },
  difficultyBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  difficultyText: {
    color: Colors.background,
    fontSize: 12,
    fontWeight: 'bold',
  },
  workoutStats: {
    flexDirection: 'row',
    gap: 16,
    marginBottom: 16,
  },
  stat: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  statText: {
    color: Colors.gray,
    fontSize: 14,
  },
  exercisePreview: {
    marginBottom: 16,
  },
  exerciseText: {
    color: Colors.lightGray,
    fontSize: 14,
    marginBottom: 2,
  },
  moreExercises: {
    color: Colors.teal,
    fontSize: 12,
    fontStyle: 'italic',
    marginTop: 4,
  },
  workoutActions: {
    flexDirection: 'row',
    gap: 12,
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  actionButtonText: {
    color: Colors.white,
    fontSize: 14,
    fontWeight: '600',
  },
  addWorkoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginTop: 16,
    marginBottom: 24,
    padding: 20,
    borderRadius: 16,
    borderWidth: 2,
    borderColor: Colors.teal,
    borderStyle: 'dashed',
  },
  addWorkoutText: {
    color: Colors.teal,
    fontSize: 16,
    fontWeight: '600',
  },
});