import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { Colors } from '../utils/colors';

interface WorkoutPlan {
  id: string;
  name: string;
  description: string;
  duration: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  days: Array<{
    day: string;
    name: string;
    exercises: Array<{
      name: string;
      sets: string;
      reps: string;
      notes?: string;
    }>;
  }>;
  macroTargets: {
    calories: number;
    protein: number;
    carbs: number;
    fats: number;
  };
}

interface PlanGeneratorScreenProps {
  userAnswers: Record<string, string>;
  onPlanAdopted: (plan: WorkoutPlan) => void;
  onBack: () => void;
}

export default function PlanGeneratorScreen({ userAnswers, onPlanAdopted, onBack }: PlanGeneratorScreenProps) {
  const [isGenerating, setIsGenerating] = useState(true);
  const [generatedPlan, setGeneratedPlan] = useState<WorkoutPlan | null>(null);
  const [adoptAnimation] = useState(new Animated.Value(1));

  // Simulate AI plan generation based on user answers
  React.useEffect(() => {
    const generatePlan = () => {
      setTimeout(() => {
        const plan: WorkoutPlan = generatePlanFromAnswers(userAnswers);
        setGeneratedPlan(plan);
        setIsGenerating(false);
      }, 3000);
    };
    generatePlan();
  }, [userAnswers]);

  const generatePlanFromAnswers = (answers: Record<string, string>): WorkoutPlan => {
    const userType = answers.user_type;
    const frequency = answers.training_frequency;
    const experience = answers.experience_level;

    // Generate plan based on user type
    if (userType === 'strength_first') {
      return {
        id: '1',
        name: 'Strength-First Hypertrophy',
        description: 'Focus on compound movements and progressive overload for maximum muscle growth',
        duration: '8 weeks',
        difficulty: experience as any,
        days: [
          {
            day: 'Monday',
            name: 'Upper Push',
            exercises: [
              { name: 'Bench Press', sets: '4', reps: '6-8' },
              { name: 'Overhead Press', sets: '3', reps: '8-10' },
              { name: 'Incline Dumbbell Press', sets: '3', reps: '10-12' },
              { name: 'Dips', sets: '3', reps: '12-15' },
              { name: 'Lateral Raises', sets: '4', reps: '15-20' }
            ]
          },
          {
            day: 'Tuesday',
            name: 'Lower Body',
            exercises: [
              { name: 'Squat', sets: '4', reps: '6-8' },
              { name: 'Romanian Deadlift', sets: '3', reps: '8-10' },
              { name: 'Bulgarian Split Squats', sets: '3', reps: '10-12' },
              { name: 'Leg Curls', sets: '3', reps: '12-15' },
              { name: 'Calf Raises', sets: '4', reps: '15-20' }
            ]
          },
          {
            day: 'Thursday',
            name: 'Upper Pull',
            exercises: [
              { name: 'Pull-ups', sets: '4', reps: '6-8' },
              { name: 'Barbell Rows', sets: '3', reps: '8-10' },
              { name: 'Lat Pulldowns', sets: '3', reps: '10-12' },
              { name: 'Face Pulls', sets: '3', reps: '15-20' },
              { name: 'Barbell Curls', sets: '3', reps: '12-15' }
            ]
          }
        ],
        macroTargets: {
          calories: 2400,
          protein: 180,
          carbs: 240,
          fats: 80
        }
      };
    } else if (userType === 'calisthenics') {
      return {
        id: '2',
        name: 'Calisthenics Skill Development',
        description: 'Progressive skill-based training for muscle-ups, handstands, and levers',
        duration: '12 weeks',
        difficulty: experience as any,
        days: [
          {
            day: 'Monday',
            name: 'Push Skills',
            exercises: [
              { name: 'Handstand Practice', sets: '5', reps: '30-60s' },
              { name: 'Pike Push-ups', sets: '4', reps: '8-12' },
              { name: 'Archer Push-ups', sets: '3', reps: '5-8 each' },
              { name: 'Dips Progression', sets: '3', reps: '8-15' },
              { name: 'Planche Lean', sets: '3', reps: '20-30s' }
            ]
          },
          {
            day: 'Wednesday',
            name: 'Pull Skills',
            exercises: [
              { name: 'Muscle-up Negatives', sets: '5', reps: '3-5' },
              { name: 'Pull-up Variations', sets: '4', reps: '6-10' },
              { name: 'Front Lever Progression', sets: '3', reps: '10-20s' },
              { name: 'Archer Pull-ups', sets: '3', reps: '3-6 each' },
              { name: 'Skin the Cat', sets: '3', reps: '5-8' }
            ]
          },
          {
            day: 'Friday',
            name: 'Core & Flow',
            exercises: [
              { name: 'L-sit Progression', sets: '4', reps: '15-30s' },
              { name: 'Human Flag Progression', sets: '3', reps: '10-20s' },
              { name: 'Dragon Squats', sets: '3', reps: '8-12' },
              { name: 'Flow Sequence', sets: '3', reps: '5-8 rounds' },
              { name: 'Hollow Body Hold', sets: '3', reps: '30-60s' }
            ]
          }
        ],
        macroTargets: {
          calories: 2200,
          protein: 150,
          carbs: 220,
          fats: 75
        }
      };
    } else {
      // Default plan for casual starters or endurance hybrid
      return {
        id: '3',
        name: 'Balanced Fitness Foundation',
        description: 'Well-rounded program combining strength, cardio, and flexibility',
        duration: '6 weeks',
        difficulty: 'Beginner',
        days: [
          {
            day: 'Monday',
            name: 'Full Body Strength',
            exercises: [
              { name: 'Bodyweight Squats', sets: '3', reps: '10-15' },
              { name: 'Push-ups', sets: '3', reps: '8-12' },
              { name: 'Assisted Pull-ups', sets: '3', reps: '5-8' },
              { name: 'Plank', sets: '3', reps: '30-45s' },
              { name: 'Glute Bridges', sets: '3', reps: '12-15' }
            ]
          },
          {
            day: 'Wednesday',
            name: 'Cardio & Core',
            exercises: [
              { name: 'Brisk Walk/Jog', sets: '1', reps: '20-30 min' },
              { name: 'Mountain Climbers', sets: '3', reps: '30s' },
              { name: 'Bicycle Crunches', sets: '3', reps: '20 each' },
              { name: 'Burpees', sets: '3', reps: '5-8' },
              { name: 'Side Plank', sets: '2', reps: '15-30s each' }
            ]
          },
          {
            day: 'Friday',
            name: 'Flexibility & Balance',
            exercises: [
              { name: 'Dynamic Warm-up', sets: '1', reps: '10 min' },
              { name: 'Yoga Flow', sets: '1', reps: '15-20 min' },
              { name: 'Single Leg Balance', sets: '3', reps: '30s each' },
              { name: 'Hip Flexor Stretch', sets: '2', reps: '30s each' },
              { name: 'Cat-Cow Stretch', sets: '2', reps: '10-15' }
            ]
          }
        ],
        macroTargets: {
          calories: 1900,
          protein: 120,
          carbs: 190,
          fats: 65
        }
      };
    }
  };

  const handleAddToPlan = () => {
    if (!generatedPlan) return;

    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    
    // Animate the button
    Animated.sequence([
      Animated.timing(adoptAnimation, {
        toValue: 0.95,
        duration: 100,
        useNativeDriver: true,
      }),
      Animated.timing(adoptAnimation, {
        toValue: 1,
        duration: 100,
        useNativeDriver: true,
      }),
    ]).start();

    setTimeout(() => {
      onPlanAdopted(generatedPlan);
    }, 500);
  };

  if (isGenerating) {
    return (
      <LinearGradient colors={Colors.primaryGradient} style={styles.container}>
        <View style={styles.generatingContainer}>
          <Animated.View style={styles.loadingIcon}>
            <Ionicons name="fitness" size={48} color={Colors.teal} />
          </Animated.View>
          <Text style={styles.generatingTitle}>Creating Your Perfect Plan</Text>
          <Text style={styles.generatingSubtitle}>
            Analyzing your answers and generating a personalized 4-week program
          </Text>
          <View style={styles.loadingDots}>
            <View style={[styles.dot, { backgroundColor: Colors.teal }]} />
            <View style={[styles.dot, { backgroundColor: Colors.teal, opacity: 0.7 }]} />
            <View style={[styles.dot, { backgroundColor: Colors.teal, opacity: 0.4 }]} />
          </View>
        </View>
      </LinearGradient>
    );
  }

  return (
    <LinearGradient colors={Colors.primaryGradient} style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <TouchableOpacity onPress={onBack} style={styles.backButton}>
            <Ionicons name="arrow-back" size={24} color={Colors.white} />
          </TouchableOpacity>
          <Text style={styles.title}>Your Personalized Plan</Text>
        </View>

        {generatedPlan && (
          <View style={styles.planContainer}>
            <View style={styles.planHeader}>
              <Text style={styles.planTitle}>{generatedPlan.name}</Text>
              <View style={styles.planMeta}>
                <View style={styles.metaItem}>
                  <Ionicons name="time" size={16} color={Colors.teal} />
                  <Text style={styles.metaText}>{generatedPlan.duration}</Text>
                </View>
                <View style={styles.metaItem}>
                  <Ionicons name="trending-up" size={16} color={Colors.teal} />
                  <Text style={styles.metaText}>{generatedPlan.difficulty}</Text>
                </View>
              </View>
              <Text style={styles.planDescription}>{generatedPlan.description}</Text>
            </View>

            {/* Workout Days Preview */}
            <View style={styles.workoutPreview}>
              <Text style={styles.sectionTitle}>Workout Schedule</Text>
              {generatedPlan.days.map((day, index) => (
                <View key={index} style={styles.dayCard}>
                  <View style={styles.dayHeader}>
                    <Text style={styles.dayName}>{day.day}</Text>
                    <Text style={styles.dayWorkout}>{day.name}</Text>
                  </View>
                  <Text style={styles.exerciseCount}>
                    {day.exercises.length} exercises
                  </Text>
                </View>
              ))}
            </View>

            {/* Macro Targets */}
            <View style={styles.macroTargets}>
              <Text style={styles.sectionTitle}>Daily Nutrition Targets</Text>
              <View style={styles.macroGrid}>
                <View style={styles.macroItem}>
                  <Text style={styles.macroValue}>{generatedPlan.macroTargets.calories}</Text>
                  <Text style={styles.macroLabel}>Calories</Text>
                </View>
                <View style={styles.macroItem}>
                  <Text style={styles.macroValue}>{generatedPlan.macroTargets.protein}g</Text>
                  <Text style={styles.macroLabel}>Protein</Text>
                </View>
                <View style={styles.macroItem}>
                  <Text style={styles.macroValue}>{generatedPlan.macroTargets.carbs}g</Text>
                  <Text style={styles.macroLabel}>Carbs</Text>
                </View>
                <View style={styles.macroItem}>
                  <Text style={styles.macroValue}>{generatedPlan.macroTargets.fats}g</Text>
                  <Text style={styles.macroLabel}>Fats</Text>
                </View>
              </View>
            </View>

            {/* Add to Plan Button */}
            <Animated.View style={[styles.adoptButtonContainer, { transform: [{ scale: adoptAnimation }] }]}>
              <TouchableOpacity style={styles.adoptButton} onPress={handleAddToPlan}>
                <Ionicons name="add-circle" size={24} color={Colors.background} />
                <Text style={styles.adoptButtonText}>Add to My Plan</Text>
              </TouchableOpacity>
            </Animated.View>
          </View>
        )}
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  generatingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 24,
  },
  loadingIcon: {
    marginBottom: 24,
  },
  generatingTitle: {
    color: Colors.white,
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 12,
  },
  generatingSubtitle: {
    color: Colors.gray,
    fontSize: 16,
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 32,
  },
  loadingDots: {
    flexDirection: 'row',
    gap: 8,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingTop: 60,
    paddingBottom: 24,
  },
  backButton: {
    marginRight: 16,
  },
  title: {
    color: Colors.white,
    fontSize: 20,
    fontWeight: 'bold',
  },
  planContainer: {
    paddingHorizontal: 24,
    paddingBottom: 24,
  },
  planHeader: {
    marginBottom: 24,
  },
  planTitle: {
    color: Colors.white,
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  planMeta: {
    flexDirection: 'row',
    gap: 16,
    marginBottom: 12,
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  metaText: {
    color: Colors.gray,
    fontSize: 14,
  },
  planDescription: {
    color: Colors.gray,
    fontSize: 16,
    lineHeight: 24,
  },
  workoutPreview: {
    marginBottom: 24,
  },
  sectionTitle: {
    color: Colors.white,
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  dayCard: {
    backgroundColor: Colors.surface,
    borderRadius: 12,
    padding: 16,
    marginBottom: 8,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  dayHeader: {
    flex: 1,
  },
  dayName: {
    color: Colors.white,
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  dayWorkout: {
    color: Colors.gray,
    fontSize: 14,
  },
  exerciseCount: {
    color: Colors.teal,
    fontSize: 12,
    fontWeight: '600',
  },
  macroTargets: {
    marginBottom: 32,
  },
  macroGrid: {
    flexDirection: 'row',
    gap: 12,
  },
  macroItem: {
    flex: 1,
    backgroundColor: Colors.surface,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  macroValue: {
    color: Colors.white,
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  macroLabel: {
    color: Colors.gray,
    fontSize: 12,
  },
  adoptButtonContainer: {
    marginBottom: 24,
  },
  adoptButton: {
    backgroundColor: Colors.teal,
    borderRadius: 16,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  adoptButtonText: {
    color: Colors.background,
    fontSize: 18,
    fontWeight: 'bold',
  },
});