import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Modal,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { Colors } from '../utils/colors';

const { width } = Dimensions.get('window');

interface MacroData {
  protein: { current: number; target: number; color: string };
  carbs: { current: number; target: number; color: string };
  fats: { current: number; target: number; color: string };
  calories: { current: number; target: number };
}

interface FoodItem {
  id: string;
  name: string;
  brand?: string;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  servingSize: string;
  time: string;
}

export default function NutritionScreen() {
  const [macros, setMacros] = useState<MacroData>({
    protein: { current: 85, target: 150, color: Colors.blue },
    carbs: { current: 120, target: 250, color: Colors.teal },
    fats: { current: 45, target: 70, color: Colors.yellow },
    calories: { current: 1240, target: 2100 },
  });

  const [foodLog, setFoodLog] = useState<FoodItem[]>([
    {
      id: '1',
      name: 'Greek Yogurt',
      brand: 'Chobani',
      calories: 130,
      protein: 20,
      carbs: 9,
      fats: 0,
      servingSize: '170g',
      time: '8:30 AM',
    },
    {
      id: '2',
      name: 'Banana',
      calories: 105,
      protein: 1,
      carbs: 27,
      fats: 0,
      servingSize: '1 medium',
      time: '8:35 AM',
    },
    {
      id: '3',
      name: 'Chicken Breast',
      calories: 165,
      protein: 31,
      carbs: 0,
      fats: 4,
      servingSize: '100g',
      time: '12:30 PM',
    },
  ]);

  const [searchModalVisible, setSearchModalVisible] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showBarcodeScanner, setShowBarcodeScanner] = useState(false);

  const getMacroPercentage = (current: number, target: number) => {
    return Math.min((current / target) * 100, 100);
  };

  const getCaloriePercentage = () => {
    return (macros.calories.current / macros.calories.target) * 100;
  };

  const handleBarcodeScan = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setShowBarcodeScanner(true);
  };

  const handleBarcodeScanned = ({ type, data }: { type: string; data: string }) => {
    setShowBarcodeScanner(false);
    // Simulate barcode lookup
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    
    // Mock food data from barcode scan
    const scannedFood: FoodItem = {
      id: Date.now().toString(),
      name: 'Protein Bar',
      brand: 'Quest',
      calories: 200,
      protein: 20,
      carbs: 15,
      fats: 8,
      servingSize: '1 bar (60g)',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setFoodLog(prev => [scannedFood, ...prev]);
    
    // Update macros
    setMacros(prev => ({
      ...prev,
      protein: { ...prev.protein, current: prev.protein.current + scannedFood.protein },
      carbs: { ...prev.carbs, current: prev.carbs.current + scannedFood.carbs },
      fats: { ...prev.fats, current: prev.fats.current + scannedFood.fats },
      calories: { ...prev.calories, current: prev.calories.current + scannedFood.calories },
    }));
  };

  const handleQuickAdd = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setSearchModalVisible(true);
  };

  const renderMacroRing = (macro: string, data: { current: number; target: number; color: string }) => {
    const percentage = getMacroPercentage(data.current, data.target);
    const radius = 40;
    const strokeWidth = 6;
    const normalizedRadius = radius - strokeWidth * 2;
    const circumference = normalizedRadius * 2 * Math.PI;
    const strokeDasharray = `${circumference} ${circumference}`;
    const strokeDashoffset = circumference - (percentage / 100) * circumference;

    return (
      <View style={styles.macroRing}>
        <View style={styles.macroRingContainer}>
          <View style={[styles.macroRingBackground, { borderColor: Colors.darkGray }]} />
          <View 
            style={[
              styles.macroRingProgress,
              { 
                borderColor: data.color,
                transform: [{ rotate: '-90deg' }],
                borderWidth: strokeWidth,
              }
            ]}
          />
        </View>
        <View style={styles.macroRingContent}>
          <Text style={styles.macroRingValue}>{data.current}g</Text>
          <Text style={styles.macroRingLabel}>{macro}</Text>
          <Text style={styles.macroRingTarget}>/{data.target}g</Text>
        </View>
      </View>
    );
  };

  const renderFoodItem = (item: FoodItem) => (
    <TouchableOpacity key={item.id} style={styles.foodItem}>
      <View style={styles.foodItemHeader}>
        <View style={styles.foodItemInfo}>
          <Text style={styles.foodItemName}>{item.name}</Text>
          {item.brand && <Text style={styles.foodItemBrand}>{item.brand}</Text>}
          <Text style={styles.foodItemServing}>{item.servingSize}</Text>
        </View>
        <View style={styles.foodItemStats}>
          <Text style={styles.foodItemCalories}>{item.calories} cal</Text>
          <Text style={styles.foodItemTime}>{item.time}</Text>
        </View>
      </View>
      <View style={styles.foodItemMacros}>
        <View style={styles.macroStat}>
          <Text style={styles.macroStatLabel}>P</Text>
          <Text style={styles.macroStatValue}>{item.protein}g</Text>
        </View>
        <View style={styles.macroStat}>
          <Text style={styles.macroStatLabel}>C</Text>
          <Text style={styles.macroStatValue}>{item.carbs}g</Text>
        </View>
        <View style={styles.macroStat}>
          <Text style={styles.macroStatLabel}>F</Text>
          <Text style={styles.macroStatValue}>{item.fats}g</Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <LinearGradient colors={Colors.primaryGradient} style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Nutrition</Text>
        <TouchableOpacity style={styles.scanButton} onPress={handleBarcodeScan}>
          <Ionicons name="barcode" size={24} color={Colors.background} />
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Daily Overview */}
        <View style={styles.overviewCard}>
          <View style={styles.calorieProgress}>
            <View style={styles.calorieRing}>
              <Text style={styles.calorieValue}>{macros.calories.current}</Text>
              <Text style={styles.calorieLabel}>calories</Text>
              <Text style={styles.calorieTarget}>/{macros.calories.target}</Text>
            </View>
            <View style={styles.calorieBar}>
              <View style={styles.calorieBarTrack} />
              <View 
                style={[
                  styles.calorieBarFill,
                  { width: `${Math.min(getCaloriePercentage(), 100)}%` }
                ]} 
              />
            </View>
          </View>

          <View style={styles.macroRings}>
            {Object.entries(macros).filter(([key]) => key !== 'calories').map(([key, data]) => (
              <View key={key}>
                {renderMacroRing(key.charAt(0).toUpperCase() + key.slice(1), data)}
              </View>
            ))}
          </View>
        </View>

        {/* Quick Actions */}
        <View style={styles.quickActions}>
          <TouchableOpacity style={styles.actionButton} onPress={handleQuickAdd}>
            <Ionicons name="add" size={20} color={Colors.teal} />
            <Text style={styles.actionButtonText}>Quick Add</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionButton}>
            <Ionicons name="camera" size={20} color={Colors.blue} />
            <Text style={styles.actionButtonText}>Photo Log</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionButton}>
            <Ionicons name="restaurant" size={20} color={Colors.yellow} />
            <Text style={styles.actionButtonText}>Meal Plan</Text>
          </TouchableOpacity>
        </View>

        {/* Food Log */}
        <View style={styles.foodLogSection}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Today's Food Log</Text>
            <TouchableOpacity>
              <Text style={styles.seeAllText}>See All</Text>
            </TouchableOpacity>
          </View>
          
          <View style={styles.foodLogList}>
            {foodLog.map(renderFoodItem)}
          </View>
        </View>

        {/* Water Intake */}
        <View style={styles.waterSection}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Water Intake</Text>
            <Text style={styles.waterAmount}>1.2L / 2.5L</Text>
          </View>
          <View style={styles.waterProgress}>
            <View style={styles.waterBarTrack} />
            <View style={[styles.waterBarFill, { width: '48%' }]} />
          </View>
          <View style={styles.waterActions}>
            <TouchableOpacity style={styles.waterButton}>
              <Text style={styles.waterButtonText}>250ml</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.waterButton}>
              <Text style={styles.waterButtonText}>500ml</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.waterButton}>
              <Text style={styles.waterButtonText}>Custom</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>

      {/* Search Modal */}
      <Modal
        visible={searchModalVisible}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <TouchableOpacity onPress={() => setSearchModalVisible(false)}>
              <Text style={styles.modalCancelText}>Cancel</Text>
            </TouchableOpacity>
            <Text style={styles.modalTitle}>Add Food</Text>
            <TouchableOpacity>
              <Text style={styles.modalDoneText}>Done</Text>
            </TouchableOpacity>
          </View>
          
          <View style={styles.searchContainer}>
            <Ionicons name="search" size={20} color={Colors.gray} />
            <TextInput
              style={styles.searchInput}
              placeholder="Search foods..."
              placeholderTextColor={Colors.gray}
              value={searchQuery}
              onChangeText={setSearchQuery}
              autoFocus
            />
          </View>
          
          {/* Search results would go here */}
          <ScrollView style={styles.searchResults}>
            <Text style={styles.noResultsText}>Start typing to search for foods</Text>
          </ScrollView>
        </View>
      </Modal>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingTop: 60,
    paddingBottom: 16,
  },
  title: {
    color: Colors.white,
    fontSize: 28,
    fontWeight: 'bold',
  },
  scanButton: {
    backgroundColor: Colors.teal,
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
  },
  overviewCard: {
    backgroundColor: Colors.surface,
    marginHorizontal: 24,
    marginBottom: 16,
    borderRadius: 16,
    padding: 20,
  },
  calorieProgress: {
    alignItems: 'center',
    marginBottom: 24,
  },
  calorieRing: {
    alignItems: 'center',
    marginBottom: 12,
  },
  calorieValue: {
    color: Colors.white,
    fontSize: 32,
    fontWeight: 'bold',
  },
  calorieLabel: {
    color: Colors.gray,
    fontSize: 14,
    marginTop: 2,
  },
  calorieTarget: {
    color: Colors.gray,
    fontSize: 12,
    marginTop: 2,
  },
  calorieBar: {
    width: '100%',
    height: 8,
    borderRadius: 4,
    position: 'relative',
  },
  calorieBarTrack: {
    position: 'absolute',
    width: '100%',
    height: 8,
    backgroundColor: Colors.darkGray,
    borderRadius: 4,
  },
  calorieBarFill: {
    height: 8,
    backgroundColor: Colors.teal,
    borderRadius: 4,
  },
  macroRings: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  macroRing: {
    alignItems: 'center',
  },
  macroRingContainer: {
    width: 80,
    height: 80,
    position: 'relative',
  },
  macroRingBackground: {
    position: 'absolute',
    width: 80,
    height: 80,
    borderRadius: 40,
    borderWidth: 6,
  },
  macroRingProgress: {
    position: 'absolute',
    width: 80,
    height: 80,
    borderRadius: 40,
    borderWidth: 6,
    borderStyle: 'solid',
  },
  macroRingContent: {
    position: 'absolute',
    width: 80,
    height: 80,
    justifyContent: 'center',
    alignItems: 'center',
  },
  macroRingValue: {
    color: Colors.white,
    fontSize: 14,
    fontWeight: 'bold',
  },
  macroRingLabel: {
    color: Colors.gray,
    fontSize: 10,
    marginTop: 2,
  },
  macroRingTarget: {
    color: Colors.gray,
    fontSize: 8,
    marginTop: 1,
  },
  quickActions: {
    flexDirection: 'row',
    paddingHorizontal: 24,
    marginBottom: 16,
    gap: 12,
  },
  actionButton: {
    flex: 1,
    backgroundColor: Colors.surface,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    gap: 8,
  },
  actionButtonText: {
    color: Colors.white,
    fontSize: 12,
    fontWeight: '600',
  },
  foodLogSection: {
    paddingHorizontal: 24,
    marginBottom: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionTitle: {
    color: Colors.white,
    fontSize: 18,
    fontWeight: 'bold',
  },
  seeAllText: {
    color: Colors.teal,
    fontSize: 14,
    fontWeight: '600',
  },
  foodLogList: {
    gap: 12,
  },
  foodItem: {
    backgroundColor: Colors.surface,
    borderRadius: 12,
    padding: 16,
  },
  foodItemHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  foodItemInfo: {
    flex: 1,
  },
  foodItemName: {
    color: Colors.white,
    fontSize: 16,
    fontWeight: 'bold',
  },
  foodItemBrand: {
    color: Colors.gray,
    fontSize: 12,
    marginTop: 2,
  },
  foodItemServing: {
    color: Colors.gray,
    fontSize: 12,
    marginTop: 2,
  },
  foodItemStats: {
    alignItems: 'flex-end',
  },
  foodItemCalories: {
    color: Colors.white,
    fontSize: 14,
    fontWeight: 'bold',
  },
  foodItemTime: {
    color: Colors.gray,
    fontSize: 12,
    marginTop: 2,
  },
  foodItemMacros: {
    flexDirection: 'row',
    gap: 16,
  },
  macroStat: {
    alignItems: 'center',
  },
  macroStatLabel: {
    color: Colors.gray,
    fontSize: 10,
    fontWeight: '600',
  },
  macroStatValue: {
    color: Colors.white,
    fontSize: 12,
    fontWeight: 'bold',
    marginTop: 2,
  },
  waterSection: {
    paddingHorizontal: 24,
    marginBottom: 24,
  },
  waterAmount: {
    color: Colors.gray,
    fontSize: 14,
    fontWeight: '600',
  },
  waterProgress: {
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.darkGray,
    marginBottom: 12,
    position: 'relative',
  },
  waterBarTrack: {
    position: 'absolute',
    width: '100%',
    height: 8,
    backgroundColor: Colors.darkGray,
    borderRadius: 4,
  },
  waterBarFill: {
    height: 8,
    backgroundColor: Colors.blue,
    borderRadius: 4,
  },
  waterActions: {
    flexDirection: 'row',
    gap: 8,
  },
  waterButton: {
    flex: 1,
    backgroundColor: Colors.surface,
    borderRadius: 8,
    paddingVertical: 8,
    alignItems: 'center',
  },
  waterButtonText: {
    color: Colors.white,
    fontSize: 12,
    fontWeight: '600',
  },
  modalContainer: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingTop: 60,
    paddingBottom: 16,
  },
  modalCancelText: {
    color: Colors.gray,
    fontSize: 16,
  },
  modalTitle: {
    color: Colors.white,
    fontSize: 18,
    fontWeight: 'bold',
  },
  modalDoneText: {
    color: Colors.teal,
    fontSize: 16,
    fontWeight: '600',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.surface,
    marginHorizontal: 24,
    marginBottom: 16,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 12,
    gap: 12,
  },
  searchInput: {
    flex: 1,
    color: Colors.white,
    fontSize: 16,
  },
  searchResults: {
    flex: 1,
    paddingHorizontal: 24,
  },
  noResultsText: {
    color: Colors.gray,
    fontSize: 16,
    textAlign: 'center',
    marginTop: 40,
  },
});