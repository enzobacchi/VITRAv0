import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  ScrollView,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { Colors } from '../utils/colors';

const { width, height } = Dimensions.get('window');

interface OnboardingScreenProps {
  onComplete: () => void;
}

interface Question {
  id: string;
  title: string;
  subtitle?: string;
  options: Array<{
    id: string;
    label: string;
    icon?: keyof typeof Ionicons.glyphMap;
  }>;
}

const questions: Question[] = [
  {
    id: 'goal',
    title: 'What\'s your primary fitness goal?',
    subtitle: 'This helps us personalize your experience',
    options: [
      { id: 'weight_loss', label: 'Lose Weight', icon: 'trending-down' },
      { id: 'muscle_gain', label: 'Build Muscle', icon: 'barbell' },
      { id: 'endurance', label: 'Improve Endurance', icon: 'heart' },
      { id: 'strength', label: 'Get Stronger', icon: 'flash' },
      { id: 'general', label: 'General Fitness', icon: 'fitness' },
    ],
  },
  {
    id: 'training_style',
    title: 'What\'s your preferred training style?',
    options: [
      { id: 'weights', label: 'Weight Training', icon: 'barbell' },
      { id: 'bodyweight', label: 'Bodyweight/Calisthenics', icon: 'body' },
      { id: 'cardio', label: 'Cardio/Endurance', icon: 'heart' },
      { id: 'hybrid', label: 'Mixed Training', icon: 'shuffle' },
    ],
  },
  {
    id: 'experience',
    title: 'What\'s your training experience?',
    options: [
      { id: 'beginner', label: 'Beginner (0-6 months)', icon: 'leaf' },
      { id: 'intermediate', label: 'Intermediate (6 months - 2 years)', icon: 'trending-up' },
      { id: 'advanced', label: 'Advanced (2+ years)', icon: 'trophy' },
    ],
  },
  {
    id: 'equipment',
    title: 'What equipment do you have access to?',
    options: [
      { id: 'full_gym', label: 'Full Gym', icon: 'business' },
      { id: 'home_gym', label: 'Home Gym Setup', icon: 'home' },
      { id: 'basic', label: 'Basic Equipment', icon: 'cube' },
      { id: 'bodyweight', label: 'No Equipment', icon: 'person' },
    ],
  },
  {
    id: 'diet_style',
    title: 'What\'s your dietary approach?',
    options: [
      { id: 'balanced', label: 'Balanced Diet', icon: 'restaurant' },
      { id: 'keto', label: 'Ketogenic', icon: 'nutrition' },
      { id: 'vegetarian', label: 'Vegetarian', icon: 'leaf' },
      { id: 'vegan', label: 'Vegan', icon: 'flower' },
      { id: 'paleo', label: 'Paleo', icon: 'fish' },
    ],
  },
  {
    id: 'session_length',
    title: 'How long do you prefer to train?',
    options: [
      { id: '15-30', label: '15-30 minutes', icon: 'time' },
      { id: '30-45', label: '30-45 minutes', icon: 'timer' },
      { id: '45-60', label: '45-60 minutes', icon: 'stopwatch' },
      { id: '60+', label: '60+ minutes', icon: 'hourglass' },
    ],
  },
];

export default function OnboardingScreen({ onComplete }: OnboardingScreenProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [selectedOption, setSelectedOption] = useState<string | null>(null);

  const question = questions[currentQuestion];
  const progress = (currentQuestion + 1) / questions.length;

  const handleOptionSelect = (optionId: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setSelectedOption(optionId);
  };

  const handleNext = async () => {
    if (!selectedOption) return;

    const newAnswers = { ...answers, [question.id]: selectedOption };
    setAnswers(newAnswers);

    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedOption(null);
    } else {
      // Generate AI plan with collected answers
      try {
        const response = await fetch('/api/ai/generate-initial-plan', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(newAnswers),
        });
        
        if (response.ok) {
          onComplete();
        }
      } catch (error) {
        console.error('Failed to generate initial plan:', error);
        onComplete(); // Continue anyway
      }
    }
  };

  const handleBack = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
      setSelectedOption(answers[questions[currentQuestion - 1].id] || null);
    }
  };

  return (
    <LinearGradient colors={Colors.primaryGradient} style={styles.container}>
      <View style={styles.header}>
        <View style={styles.progressContainer}>
          <View style={styles.progressTrack}>
            <View style={[styles.progressFill, { width: `${progress * 100}%` }]} />
          </View>
          <Text style={styles.progressText}>
            {currentQuestion + 1} of {questions.length}
          </Text>
        </View>

        {currentQuestion > 0 && (
          <TouchableOpacity onPress={handleBack} style={styles.backButton}>
            <Ionicons name="chevron-back" size={24} color={Colors.white} />
          </TouchableOpacity>
        )}
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.questionContainer}>
          <Text style={styles.questionTitle}>{question.title}</Text>
          {question.subtitle && (
            <Text style={styles.questionSubtitle}>{question.subtitle}</Text>
          )}
        </View>

        <View style={styles.optionsContainer}>
          {question.options.map((option) => (
            <TouchableOpacity
              key={option.id}
              style={[
                styles.optionButton,
                selectedOption === option.id && styles.optionButtonSelected,
              ]}
              onPress={() => handleOptionSelect(option.id)}
            >
              <View style={styles.optionContent}>
                {option.icon && (
                  <Ionicons
                    name={option.icon}
                    size={24}
                    color={
                      selectedOption === option.id ? Colors.background : Colors.teal
                    }
                    style={styles.optionIcon}
                  />
                )}
                <Text
                  style={[
                    styles.optionText,
                    selectedOption === option.id && styles.optionTextSelected,
                  ]}
                >
                  {option.label}
                </Text>
              </View>
              {selectedOption === option.id && (
                <Ionicons name="checkmark" size={20} color={Colors.background} />
              )}
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>

      <View style={styles.footer}>
        <TouchableOpacity
          style={[
            styles.nextButton,
            !selectedOption && styles.nextButtonDisabled,
          ]}
          onPress={handleNext}
          disabled={!selectedOption}
        >
          <Text style={styles.nextButtonText}>
            {currentQuestion === questions.length - 1 ? 'Get Started' : 'Next'}
          </Text>
          <Ionicons name="chevron-forward" size={20} color={Colors.background} />
        </TouchableOpacity>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingTop: 60,
    paddingHorizontal: 24,
    paddingBottom: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  progressContainer: {
    flex: 1,
  },
  progressTrack: {
    height: 4,
    backgroundColor: Colors.darkGray,
    borderRadius: 2,
    marginBottom: 8,
  },
  progressFill: {
    height: 4,
    backgroundColor: Colors.teal,
    borderRadius: 2,
  },
  progressText: {
    color: Colors.gray,
    fontSize: 12,
    fontWeight: '500',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.surface,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 16,
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
  },
  questionContainer: {
    marginBottom: 40,
  },
  questionTitle: {
    color: Colors.white,
    fontSize: 28,
    fontWeight: 'bold',
    lineHeight: 36,
    marginBottom: 8,
  },
  questionSubtitle: {
    color: Colors.gray,
    fontSize: 16,
    lineHeight: 24,
  },
  optionsContainer: {
    gap: 12,
  },
  optionButton: {
    backgroundColor: Colors.surface,
    borderRadius: 16,
    padding: 20,
    borderWidth: 2,
    borderColor: 'transparent',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  optionButtonSelected: {
    backgroundColor: Colors.teal,
    borderColor: Colors.teal,
  },
  optionContent: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  optionIcon: {
    marginRight: 16,
  },
  optionText: {
    color: Colors.white,
    fontSize: 16,
    fontWeight: '600',
    flex: 1,
  },
  optionTextSelected: {
    color: Colors.background,
  },
  footer: {
    paddingHorizontal: 24,
    paddingBottom: 40,
    paddingTop: 20,
  },
  nextButton: {
    backgroundColor: Colors.teal,
    borderRadius: 16,
    height: 56,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  nextButtonDisabled: {
    backgroundColor: Colors.darkGray,
  },
  nextButtonText: {
    color: Colors.background,
    fontSize: 18,
    fontWeight: 'bold',
  },
});