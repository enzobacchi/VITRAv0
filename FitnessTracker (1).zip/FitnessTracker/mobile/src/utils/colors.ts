// WHOOP-inspired color palette
export const Colors = {
  // Base colors
  background: '#101518',
  backgroundGradient: '#283339',
  surface: '#1E2529',
  border: '#2A3137',
  
  // Primary colors
  teal: '#00F19F',
  blue: '#0093E7',
  
  // Status colors
  green: '#16EC06',
  yellow: '#FFDE00',
  red: '#FF0026',
  
  // Text colors
  white: '#FFFFFF',
  gray: '#8B9499',
  lightGray: '#B5BCC1',
  darkGray: '#2A3137',
  
  // Gradients
  primaryGradient: ['#283339', '#101518'],
  cardGradient: ['#1E2529', '#181C20'],
};

export const createGradient = (colors: string[]) => ({
  colors,
  start: { x: 0, y: 0 },
  end: { x: 1, y: 1 },
});