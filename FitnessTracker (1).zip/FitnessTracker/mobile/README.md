# FitAI Mobile - React Native Fitness App

A cross-platform mobile fitness application with WHOOP-inspired dark UI, built with React Native and Expo. Features AI-powered workout planning, macro tracking, supplement analysis, and conversational AI coaching.

## Features

### 🎯 Core Functionality
- **Onboarding Flow**: Single-question paginated setup with AI plan generation
- **Today Dashboard**: Recovery metrics, workout preview, macro progress overview
- **Workouts**: Weekly calendar view with drag-and-drop, AI workout generation
- **Nutrition**: Macro tracking with pie charts, barcode scanning, food logging
- **Supplements**: Progress tracking with AI analysis and deficiency detection
- **AI Coach**: Chat interface with quick actions and contextual suggestions

### 🎨 Design System
- **Color Palette**: WHOOP-inspired dark gradients
  - Background: `#101518` → `#283339`
  - Accent Teal: `#00F19F`
  - Workout Blue: `#0093E7`
  - Recovery Colors: Green `#16EC06`, Yellow `#FFDE00`, Red `#FF0026`
- **Typography**: System fonts with weight hierarchy
- **Interactions**: Haptic feedback on all major actions
- **Navigation**: Bottom tabs with stack navigation

## Getting Started

### Prerequisites
- Node.js 18+ 
- Expo CLI
- iOS Simulator or Android Emulator (for testing)
- Backend server running on localhost:5000

### Installation

1. **Install Expo CLI globally**
   ```bash
   npm install -g @expo/cli
   ```

2. **Navigate to mobile directory**
   ```bash
   cd mobile
   ```

3. **Install dependencies**
   ```bash
   npm install
   ```

4. **Start the development server**
   ```bash
   npx expo start
   ```

5. **Run on device/simulator**
   - Press `i` for iOS Simulator
   - Press `a` for Android Emulator
   - Scan QR code with Expo Go app on physical device

### Backend Setup

The mobile app requires the backend server to be running:

1. **Start backend server**
   ```bash
   # From project root
   npm run dev
   ```

2. **Ensure API endpoints are accessible**
   - Backend runs on port 5000
   - Mobile app connects to localhost:5000 in development
   - For physical device testing, update API URLs to your local IP

## Project Structure

```
mobile/
├── App.tsx                 # Main app entry with navigation
├── app.json               # Expo configuration
├── package.json           # Dependencies
├── src/
│   ├── screens/          # Main application screens
│   │   ├── OnboardingScreen.tsx    # First-run setup flow
│   │   ├── TodayScreen.tsx         # Dashboard overview
│   │   ├── WorkoutsScreen.tsx      # Workout calendar
│   │   ├── NutritionScreen.tsx     # Macro tracking
│   │   ├── SupplementsScreen.tsx   # Supplement management
│   │   └── CoachScreen.tsx         # AI chat interface
│   ├── components/       # Reusable UI components
│   └── utils/
│       └── colors.ts     # WHOOP-inspired color palette
└── assets/              # Images and icons
```

## Key Screens

### Onboarding Flow
- Paginated single-question format
- Questions: goal, training style, experience, equipment, diet, session length
- AI plan generation on completion
- Progress indicator and haptic feedback

### Today Dashboard
- Recovery score with color-coded status
- Today's workout preview with start button
- Macro progress with visual indicators
- Quick action buttons for common tasks

### Workouts Calendar
- Horizontal date picker
- Workout cards with difficulty indicators
- Exercise preview and action buttons
- AI generation with sparkles icon

### Nutrition Tracking
- Circular macro progress rings
- Daily calorie overview
- Food log with macro breakdown
- Water intake tracking
- Barcode scanner integration

### Supplements Manager
- Daily progress overview
- Category-coded supplements with icons
- AI analysis with insights and recommendations
- Progress tracking with completion states

### AI Coach Chat
- WhatsApp-style chat interface
- Quick action buttons for common requests
- Contextual suggestions
- Typing indicators and message timestamps

## API Integration

### Required Endpoints
- `POST /api/ai/generate-initial-plan` - Onboarding flow completion
- `GET /api/profile` - User profile data
- `POST /api/profile` - Profile updates
- `GET /api/workouts` - Workout plans
- `POST /api/ai/generate-workout` - AI workout generation
- `GET /api/nutrition` - Nutrition data
- `POST /api/nutrition/log` - Food logging
- `GET /api/supplements` - User supplements
- `POST /api/supplements/analyze` - AI supplement analysis
- `POST /api/ai/chat` - AI coaching chat

### Authentication
- Uses existing Replit Auth system
- Session-based authentication
- Protected routes with middleware

## Development Notes

### State Management
- React hooks for local state
- No external state management library
- API calls directly in components

### Navigation
- React Navigation v6
- Bottom tab navigator for main screens
- Stack navigator for onboarding flow
- Deep linking support ready

### Performance
- Optimized for 60fps animations
- Haptic feedback on interactions
- Lazy loading for large lists
- Image optimization for assets

## Deployment

### Expo Application Services (EAS)
1. **Install EAS CLI**
   ```bash
   npm install -g eas-cli
   ```

2. **Configure EAS**
   ```bash
   eas build:configure
   ```

3. **Build for production**
   ```bash
   # iOS
   eas build --platform ios
   
   # Android
   eas build --platform android
   ```

### App Store Deployment
- Update app.json with store-ready configuration
- Add app icons and splash screens
- Configure app signing
- Submit through EAS Submit

## Environment Variables

For production deployment, configure:
- `API_BASE_URL` - Backend API endpoint
- `OPENAI_API_KEY` - AI functionality
- Any additional service keys

## Contributing

1. Follow React Native and Expo best practices
2. Maintain WHOOP-inspired design consistency
3. Add haptic feedback to new interactions
4. Test on both iOS and Android
5. Update this README for new features

## Technical Stack

- **Frontend**: React Native 0.74, Expo SDK 51
- **Navigation**: React Navigation v6
- **UI**: Custom components with WHOOP design system
- **Icons**: Expo Vector Icons (Ionicons)
- **Interactions**: Expo Haptics
- **Backend**: Node.js/Express with existing API
- **Database**: PostgreSQL with Drizzle ORM
- **AI**: OpenAI GPT-4o integration