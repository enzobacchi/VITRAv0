import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  decimal,
  boolean,
  date,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table (mandatory for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table (mandatory for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// User profile and preferences
export const userProfiles = pgTable("user_profiles", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  age: integer("age"),
  gender: varchar("gender", { length: 10 }),
  height: decimal("height", { precision: 5, scale: 2 }), // in cm
  weight: decimal("weight", { precision: 5, scale: 2 }), // in kg
  activityLevel: varchar("activity_level", { length: 20 }),
  fitnessGoals: text("fitness_goals").array(),
  dietaryPreferences: text("dietary_preferences").array(),
  targetCalories: integer("target_calories"),
  targetProtein: integer("target_protein"),
  targetCarbs: integer("target_carbs"),
  targetFats: integer("target_fats"),
  targetFiber: integer("target_fiber"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Workout plans
export const workoutPlans = pgTable("workout_plans", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  duration: integer("duration"), // in minutes
  difficulty: varchar("difficulty", { length: 20 }),
  exercises: jsonb("exercises").notNull(), // Array of exercise objects
  isAiGenerated: boolean("is_ai_generated").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Scheduled workouts
export const scheduledWorkouts = pgTable("scheduled_workouts", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  workoutPlanId: integer("workout_plan_id").references(() => workoutPlans.id, { onDelete: "cascade" }),
  scheduledDate: date("scheduled_date").notNull(),
  completed: boolean("completed").default(false),
  completedAt: timestamp("completed_at"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Workout logs
export const workoutLogs = pgTable("workout_logs", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  scheduledWorkoutId: integer("scheduled_workout_id").references(() => scheduledWorkouts.id),
  exerciseName: varchar("exercise_name", { length: 255 }).notNull(),
  sets: integer("sets"),
  reps: integer("reps"),
  weight: decimal("weight", { precision: 5, scale: 2 }),
  duration: integer("duration"), // in seconds
  rpe: integer("rpe"), // Rate of Perceived Exertion (1-10)
  notes: text("notes"),
  loggedAt: timestamp("logged_at").defaultNow(),
});

// Food database
export const foods = pgTable("foods", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  brand: varchar("brand", { length: 255 }),
  servingSize: decimal("serving_size", { precision: 8, scale: 2 }),
  servingUnit: varchar("serving_unit", { length: 50 }),
  caloriesPerServing: decimal("calories_per_serving", { precision: 8, scale: 2 }),
  proteinPerServing: decimal("protein_per_serving", { precision: 8, scale: 2 }),
  carbsPerServing: decimal("carbs_per_serving", { precision: 8, scale: 2 }),
  fatsPerServing: decimal("fats_per_serving", { precision: 8, scale: 2 }),
  fiberPerServing: decimal("fiber_per_serving", { precision: 8, scale: 2 }),
  sugarPerServing: decimal("sugar_per_serving", { precision: 8, scale: 2 }),
  sodiumPerServing: decimal("sodium_per_serving", { precision: 8, scale: 2 }),
  barcode: varchar("barcode", { length: 50 }),
  createdAt: timestamp("created_at").defaultNow(),
});

// Food log entries
export const foodLogs = pgTable("food_logs", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  foodId: integer("food_id").references(() => foods.id),
  customFoodName: varchar("custom_food_name", { length: 255 }),
  servings: decimal("servings", { precision: 8, scale: 2 }).default("1"),
  mealType: varchar("meal_type", { length: 50 }), // breakfast, lunch, dinner, snack
  calories: decimal("calories", { precision: 8, scale: 2 }),
  protein: decimal("protein", { precision: 8, scale: 2 }),
  carbs: decimal("carbs", { precision: 8, scale: 2 }),
  fats: decimal("fats", { precision: 8, scale: 2 }),
  fiber: decimal("fiber", { precision: 8, scale: 2 }),
  loggedAt: timestamp("logged_at").defaultNow(),
  loggedDate: date("logged_date").notNull(),
});

// Supplements
export const supplements = pgTable("supplements", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  brand: varchar("brand", { length: 255 }),
  ingredients: jsonb("ingredients").notNull(), // Array of ingredient objects with amounts
  servingSize: varchar("serving_size", { length: 100 }),
  instructions: text("instructions"),
  warnings: text("warnings"),
  createdAt: timestamp("created_at").defaultNow(),
});

// User supplements
export const userSupplements = pgTable("user_supplements", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  supplementId: integer("supplement_id").references(() => supplements.id),
  customName: varchar("custom_name", { length: 255 }),
  dosage: varchar("dosage", { length: 100 }),
  frequency: varchar("frequency", { length: 100 }),
  timeOfDay: varchar("time_of_day", { length: 100 }),
  isActive: boolean("is_active").default(true),
  startDate: date("start_date"),
  endDate: date("end_date"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Supplement logs
export const supplementLogs = pgTable("supplement_logs", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  userSupplementId: integer("user_supplement_id").references(() => userSupplements.id, { onDelete: "cascade" }),
  taken: boolean("taken").default(true),
  dosageTaken: varchar("dosage_taken", { length: 100 }),
  notes: text("notes"),
  loggedAt: timestamp("logged_at").defaultNow(),
  loggedDate: date("logged_date").notNull(),
});

// AI chat messages
export const aiChatMessages = pgTable("ai_chat_messages", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  message: text("message").notNull(),
  response: text("response").notNull(),
  messageType: varchar("message_type", { length: 50 }), // question, request, log
  workoutPlan: text("workout_plan"), // JSON string of workout plan
  weeklyWorkouts: text("weekly_workouts"), // JSON string of weekly workouts
  expiresAt: timestamp("expires_at"), // When workout data expires
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ one, many }) => ({
  profile: one(userProfiles, {
    fields: [users.id],
    references: [userProfiles.userId],
  }),
  workoutPlans: many(workoutPlans),
  scheduledWorkouts: many(scheduledWorkouts),
  workoutLogs: many(workoutLogs),
  foodLogs: many(foodLogs),
  userSupplements: many(userSupplements),
  supplementLogs: many(supplementLogs),
  aiChatMessages: many(aiChatMessages),
}));

export const userProfilesRelations = relations(userProfiles, ({ one }) => ({
  user: one(users, {
    fields: [userProfiles.userId],
    references: [users.id],
  }),
}));

export const workoutPlansRelations = relations(workoutPlans, ({ one, many }) => ({
  user: one(users, {
    fields: [workoutPlans.userId],
    references: [users.id],
  }),
  scheduledWorkouts: many(scheduledWorkouts),
}));

export const scheduledWorkoutsRelations = relations(scheduledWorkouts, ({ one, many }) => ({
  user: one(users, {
    fields: [scheduledWorkouts.userId],
    references: [users.id],
  }),
  workoutPlan: one(workoutPlans, {
    fields: [scheduledWorkouts.workoutPlanId],
    references: [workoutPlans.id],
  }),
  workoutLogs: many(workoutLogs),
}));

export const workoutLogsRelations = relations(workoutLogs, ({ one }) => ({
  user: one(users, {
    fields: [workoutLogs.userId],
    references: [users.id],
  }),
  scheduledWorkout: one(scheduledWorkouts, {
    fields: [workoutLogs.scheduledWorkoutId],
    references: [scheduledWorkouts.id],
  }),
}));

export const foodsRelations = relations(foods, ({ many }) => ({
  foodLogs: many(foodLogs),
}));

export const foodLogsRelations = relations(foodLogs, ({ one }) => ({
  user: one(users, {
    fields: [foodLogs.userId],
    references: [users.id],
  }),
  food: one(foods, {
    fields: [foodLogs.foodId],
    references: [foods.id],
  }),
}));

export const supplementsRelations = relations(supplements, ({ many }) => ({
  userSupplements: many(userSupplements),
}));

export const userSupplementsRelations = relations(userSupplements, ({ one, many }) => ({
  user: one(users, {
    fields: [userSupplements.userId],
    references: [users.id],
  }),
  supplement: one(supplements, {
    fields: [userSupplements.supplementId],
    references: [supplements.id],
  }),
  supplementLogs: many(supplementLogs),
}));

export const supplementLogsRelations = relations(supplementLogs, ({ one }) => ({
  user: one(users, {
    fields: [supplementLogs.userId],
    references: [users.id],
  }),
  userSupplement: one(userSupplements, {
    fields: [supplementLogs.userSupplementId],
    references: [userSupplements.id],
  }),
}));

export const aiChatMessagesRelations = relations(aiChatMessages, ({ one }) => ({
  user: one(users, {
    fields: [aiChatMessages.userId],
    references: [users.id],
  }),
}));

// Insert schemas
export const insertUserProfileSchema = createInsertSchema(userProfiles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  height: z.union([z.string(), z.number(), z.null()]).transform((val) => val === null ? null : String(val)).optional(),
  weight: z.union([z.string(), z.number(), z.null()]).transform((val) => val === null ? null : String(val)).optional(),
  age: z.union([z.number(), z.null()]).optional(),
  gender: z.union([z.string(), z.null()]).optional(),
  activityLevel: z.union([z.string(), z.null()]).optional(),
  fitnessGoals: z.union([z.array(z.string()), z.null()]).optional(),
  dietaryPreferences: z.union([z.array(z.string()), z.null()]).optional(),
  targetCalories: z.union([z.number(), z.null()]).optional(),
  targetProtein: z.union([z.number(), z.null()]).optional(),
  targetCarbs: z.union([z.number(), z.null()]).optional(),
  targetFats: z.union([z.number(), z.null()]).optional(),
  targetFiber: z.union([z.number(), z.null()]).optional(),
});

export const insertWorkoutPlanSchema = createInsertSchema(workoutPlans).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertScheduledWorkoutSchema = createInsertSchema(scheduledWorkouts).omit({
  id: true,
  createdAt: true,
});

export const insertWorkoutLogSchema = createInsertSchema(workoutLogs).omit({
  id: true,
  loggedAt: true,
});

export const insertFoodSchema = createInsertSchema(foods).omit({
  id: true,
  createdAt: true,
});

export const insertFoodLogSchema = createInsertSchema(foodLogs).omit({
  id: true,
  loggedAt: true,
});

export const insertSupplementSchema = createInsertSchema(supplements).omit({
  id: true,
  createdAt: true,
});

export const insertUserSupplementSchema = createInsertSchema(userSupplements).omit({
  id: true,
  createdAt: true,
});

export const insertSupplementLogSchema = createInsertSchema(supplementLogs).omit({
  id: true,
  loggedAt: true,
});

export const insertAiChatMessageSchema = createInsertSchema(aiChatMessages).omit({
  id: true,
  createdAt: true,
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

export type InsertUserProfile = z.infer<typeof insertUserProfileSchema>;
export type UserProfile = typeof userProfiles.$inferSelect;

export type InsertWorkoutPlan = z.infer<typeof insertWorkoutPlanSchema>;
export type WorkoutPlan = typeof workoutPlans.$inferSelect;

export type InsertScheduledWorkout = z.infer<typeof insertScheduledWorkoutSchema>;
export type ScheduledWorkout = typeof scheduledWorkouts.$inferSelect;

export type InsertWorkoutLog = z.infer<typeof insertWorkoutLogSchema>;
export type WorkoutLog = typeof workoutLogs.$inferSelect;

export type InsertFood = z.infer<typeof insertFoodSchema>;
export type Food = typeof foods.$inferSelect;

export type InsertFoodLog = z.infer<typeof insertFoodLogSchema>;
export type FoodLog = typeof foodLogs.$inferSelect;

export type InsertSupplement = z.infer<typeof insertSupplementSchema>;
export type Supplement = typeof supplements.$inferSelect;

export type InsertUserSupplement = z.infer<typeof insertUserSupplementSchema>;
export type UserSupplement = typeof userSupplements.$inferSelect;

export type InsertSupplementLog = z.infer<typeof insertSupplementLogSchema>;
export type SupplementLog = typeof supplementLogs.$inferSelect;

export type InsertAiChatMessage = z.infer<typeof insertAiChatMessageSchema>;
export type AiChatMessage = typeof aiChatMessages.$inferSelect;
