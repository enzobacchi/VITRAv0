import type { Express } from "express";
import { createServer, type Server } from "http";
import path from "path";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { 
  insertUserProfileSchema,
  insertWorkoutPlanSchema,
  insertScheduledWorkoutSchema,
  insertWorkoutLogSchema,
  insertFoodLogSchema,
  insertUserSupplementSchema,
  insertSupplementLogSchema,
  insertAiChatMessageSchema
} from "@shared/schema";
import { z } from "zod";
import { OpenAIService } from "./services/openai";
import { NutritionService } from "./services/nutrition";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  const openaiService = new OpenAIService();
  const nutritionService = new NutritionService();

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // User Profile routes
  app.get('/api/profile', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const profile = await storage.getUserProfile(userId);
      res.json(profile);
    } catch (error) {
      console.error("Error fetching profile:", error);
      res.status(500).json({ message: "Failed to fetch profile" });
    }
  });

  app.post('/api/profile', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const profileData = insertUserProfileSchema.parse({ ...req.body, userId });
      
      const profile = await storage.upsertUserProfile(profileData);
      
      // Generate initial workout and nutrition plan if this is first time setup
      const existingProfile = await storage.getUserProfile(userId);
      if (!existingProfile) {
        const aiPlan = await openaiService.generateInitialPlan(profileData);
        if (aiPlan.workoutPlan) {
          await storage.createWorkoutPlan({
            userId,
            ...aiPlan.workoutPlan,
            isAiGenerated: true
          });
        }
      }
      
      res.json(profile);
    } catch (error) {
      console.error("Error updating profile:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  // Profile photo upload endpoint
  app.post('/api/profile/photo', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // Generate a unique avatar URL using DiceBear API
      const avatarUrl = `https://api.dicebear.com/7.x/avataaars/svg?seed=${userId}&backgroundColor=0891b2`;
      
      // Update user's profile image URL
      await storage.upsertUser({
        id: userId,
        profileImageUrl: avatarUrl
      });
      
      res.json({ 
        profileImageUrl: avatarUrl,
        message: "Profile photo updated successfully" 
      });
    } catch (error) {
      console.error("Error uploading photo:", error);
      res.status(500).json({ message: "Failed to upload photo" });
    }
  });

  // Workout routes
  app.get('/api/workouts', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const workouts = await storage.getWorkoutPlans(userId);
      res.json(workouts);
    } catch (error) {
      console.error("Error fetching workouts:", error);
      res.status(500).json({ message: "Failed to fetch workouts" });
    }
  });

  app.post('/api/workouts', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const workoutData = insertWorkoutPlanSchema.parse({ ...req.body, userId });
      const workout = await storage.createWorkoutPlan(workoutData);
      res.json(workout);
    } catch (error) {
      console.error("Error creating workout:", error);
      res.status(500).json({ message: "Failed to create workout" });
    }
  });

  app.get('/api/workouts/scheduled', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { date } = req.query;
      const scheduledWorkouts = await storage.getScheduledWorkouts(userId, date as string);
      res.json(scheduledWorkouts);
    } catch (error) {
      console.error("Error fetching scheduled workouts:", error);
      res.status(500).json({ message: "Failed to fetch scheduled workouts" });
    }
  });

  app.post('/api/workouts/schedule', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const scheduleData = insertScheduledWorkoutSchema.parse({ ...req.body, userId });
      const scheduled = await storage.scheduleWorkout(scheduleData);
      res.json(scheduled);
    } catch (error) {
      console.error("Error scheduling workout:", error);
      res.status(500).json({ message: "Failed to schedule workout" });
    }
  });

  app.post('/api/workouts/replace', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { workoutPlan, scheduledDate } = req.body;
      
      // Create the new workout plan
      const workoutData = insertWorkoutPlanSchema.parse({ 
        ...workoutPlan, 
        userId 
      });
      const newWorkout = await storage.createWorkoutPlan(workoutData);
      
      // Find and replace existing scheduled workout for this date
      const existingScheduled = await storage.getScheduledWorkouts(userId, scheduledDate);
      
      if (existingScheduled.length > 0) {
        // Replace existing workout with new one by creating new schedule
        const scheduleData = insertScheduledWorkoutSchema.parse({ 
          workoutPlanId: newWorkout.id,
          scheduledDate,
          userId 
        });
        const scheduled = await storage.scheduleWorkout(scheduleData);
        res.json({ workout: newWorkout, scheduled });
      } else {
        // Create new schedule entry
        const scheduleData = insertScheduledWorkoutSchema.parse({ 
          workoutPlanId: newWorkout.id,
          scheduledDate,
          userId 
        });
        const scheduled = await storage.scheduleWorkout(scheduleData);
        res.json({ workout: newWorkout, scheduled });
      }
    } catch (error) {
      console.error("Error replacing workout:", error);
      res.status(500).json({ message: "Failed to replace workout" });
    }
  });

  app.post('/api/workouts/schedule-weekly', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { weeklyWorkouts } = req.body;
      
      // First, clear existing workouts for this user
      await storage.clearUserWorkouts(userId);
      
      const results = [];
      const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
      
      for (const [dayName, workoutData] of Object.entries(weeklyWorkouts)) {
        if (workoutData && (workoutData as any).exercises && (workoutData as any).exercises.length > 0) {
          // Create workout plan for this day
          const workoutPlanData = insertWorkoutPlanSchema.parse({ 
            ...(workoutData as any), 
            userId,
            isAiGenerated: true
          });
          const newWorkout = await storage.createWorkoutPlan(workoutPlanData);
          
          // Calculate date for this day in the current week
          const today = new Date();
          const currentDay = today.getDay();
          const targetDay = dayNames.indexOf(dayName);
          const daysFromToday = targetDay - currentDay;
          const targetDate = new Date(today);
          targetDate.setDate(today.getDate() + daysFromToday);
          const scheduledDate = targetDate.toISOString().split('T')[0];
          
          // Remove any existing scheduled workout for this date
          await storage.removeScheduledWorkout(userId, scheduledDate);
          
          // Schedule the workout
          const scheduleData = insertScheduledWorkoutSchema.parse({ 
            workoutPlanId: newWorkout.id,
            scheduledDate,
            userId 
          });
          const scheduled = await storage.scheduleWorkout(scheduleData);
          
          results.push({ day: dayName, workout: newWorkout, scheduled });
        }
      }
      
      res.json({ message: "Weekly workouts scheduled successfully", results });
    } catch (error) {
      console.error("Error scheduling weekly workouts:", error);
      res.status(500).json({ message: "Failed to schedule weekly workouts" });
    }
  });

  app.post('/api/workouts/log', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const logData = insertWorkoutLogSchema.parse({ ...req.body, userId });
      const log = await storage.logWorkout(logData);
      res.json(log);
    } catch (error) {
      console.error("Error logging workout:", error);
      res.status(500).json({ message: "Failed to log workout" });
    }
  });

  app.post('/api/workouts/scheduled/:id/complete', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const scheduledWorkoutId = parseInt(req.params.id);
      const { duration } = req.body;
      
      const result = await storage.completeScheduledWorkout(scheduledWorkoutId, userId, duration);
      res.json(result);
    } catch (error) {
      console.error("Error completing workout:", error);
      res.status(500).json({ message: "Failed to complete workout" });
    }
  });

  app.post('/api/workouts/scheduled/:id/uncomplete', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const scheduledWorkoutId = parseInt(req.params.id);
      
      const result = await storage.uncompleteScheduledWorkout(scheduledWorkoutId, userId);
      res.json(result);
    } catch (error) {
      console.error("Error uncompleting workout:", error);
      res.status(500).json({ message: "Failed to uncomplete workout" });
    }
  });

  app.put('/api/workouts/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const workoutId = parseInt(req.params.id);
      const updates = req.body;
      
      // Verify the workout belongs to the user
      const workoutPlans = await storage.getWorkoutPlans(userId);
      const existingWorkout = workoutPlans.find(plan => plan.id === workoutId);
      
      if (!existingWorkout) {
        return res.status(404).json({ message: "Workout not found" });
      }
      
      // Update the workout plan
      const updatedWorkout = await storage.updateWorkoutPlan(workoutId, updates);
      res.json(updatedWorkout);
    } catch (error) {
      console.error("Error updating workout:", error);
      res.status(500).json({ message: "Failed to update workout" });
    }
  });

  // Nutrition routes
  app.get('/api/nutrition/search', isAuthenticated, async (req: any, res) => {
    try {
      const { query } = req.query;
      if (!query) {
        return res.status(400).json({ message: "Query parameter required" });
      }
      
      const foods = await nutritionService.searchFoods(query as string);
      res.json(foods);
    } catch (error) {
      console.error("Error searching foods:", error);
      res.status(500).json({ message: "Failed to search foods" });
    }
  });

  app.get('/api/nutrition/logs', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { date } = req.query;
      const logs = await storage.getFoodLogs(userId, date as string);
      res.json(logs);
    } catch (error) {
      console.error("Error fetching food logs:", error);
      res.status(500).json({ message: "Failed to fetch food logs" });
    }
  });

  app.post('/api/nutrition/log', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      console.log('Received food log request:', { userId, body: req.body });
      
      // Bypass schema parsing for now and create the data directly
      const logData = {
        userId,
        customFoodName: req.body.customFoodName || 'Manual Entry',
        servings: Number(req.body.servings) || 1,
        mealType: req.body.mealType || 'snack',
        calories: Number(req.body.calories) || 0,
        protein: Number(req.body.protein) || 0,
        carbs: Number(req.body.carbs) || 0,
        fats: Number(req.body.fats) || 0,
        fiber: Number(req.body.fiber) || 0,
        loggedAt: new Date(req.body.loggedAt) || new Date(),
        loggedDate: req.body.loggedDate || new Date().toISOString().split('T')[0],
      };
      
      console.log('Processed log data:', logData);
      
      const log = await storage.logFood(logData);
      console.log('Saved food log:', log);
      
      res.json(log);
    } catch (error) {
      console.error("Error logging food:", error);
      if (error instanceof Error) {
        console.error("Error details:", error.message);
        console.error("Error stack:", error.stack);
      }
      res.status(500).json({ message: "Failed to log food", error: error.message });
    }
  });

  app.get('/api/nutrition/daily-stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const date = req.query.date || new Date().toISOString().split('T')[0];
      console.log(`API: Getting daily nutrition stats for user ${userId}, date: ${date}`);
      const stats = await storage.getDailyNutritionStats(userId, date);
      console.log(`API: Returning stats:`, stats);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching daily stats:", error);
      res.status(500).json({ message: "Failed to fetch daily nutrition stats" });
    }
  });

  // Supplement routes
  app.get('/api/supplements', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const supplements = await storage.getUserSupplements(userId);
      res.json(supplements);
    } catch (error) {
      console.error("Error fetching supplements:", error);
      res.status(500).json({ message: "Failed to fetch supplements" });
    }
  });

  app.post('/api/supplements', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const supplementData = insertUserSupplementSchema.parse({ ...req.body, userId });
      const supplement = await storage.addUserSupplement(supplementData);
      res.json(supplement);
    } catch (error) {
      console.error("Error adding supplement:", error);
      res.status(500).json({ message: "Failed to add supplement" });
    }
  });

  app.post('/api/supplements/analyze', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const userSupplements = await storage.getUserSupplements(userId);
      const profile = await storage.getUserProfile(userId);
      const recentNutrition = await storage.getRecentNutritionData(userId, 7); // Last 7 days
      
      if (!profile) {
        return res.status(400).json({ message: "Profile required for supplement analysis" });
      }
      
      const analysis = await openaiService.analyzeSupplements(userSupplements, profile, recentNutrition);
      res.json(analysis);
    } catch (error) {
      console.error("Error analyzing supplements:", error);
      res.status(500).json({ message: "Failed to analyze supplements" });
    }
  });

  // Mobile onboarding endpoint
  app.post('/api/ai/generate-initial-plan', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const onboardingAnswers = req.body;
      
      // Create profile from onboarding data
      const profileData = {
        userId,
        age: 25, // Default values, could be enhanced to derive from answers
        gender: onboardingAnswers.gender || null,
        activityLevel: onboardingAnswers.training_style || 'moderate',
        fitnessGoals: [onboardingAnswers.goal || 'general'],
        dietaryPreferences: [onboardingAnswers.diet_style || 'balanced'],
        targetCalories: 2100,
        targetProtein: 150,
        targetCarbs: 250,
        targetFats: 70,
      };
      
      // Save profile
      await storage.upsertUserProfile(profileData);
      
      // Generate AI plan
      const aiPlan = await openaiService.generateInitialPlan(profileData);
      
      // Save workout plan if generated
      if (aiPlan.workoutPlan) {
        await storage.createWorkoutPlan({
          userId,
          ...aiPlan.workoutPlan,
          isAiGenerated: true
        });
      }
      
      res.json({ success: true, plan: aiPlan });
    } catch (error) {
      console.error("Error generating initial plan:", error);
      res.status(500).json({ message: "Failed to generate initial plan" });
    }
  });

  // Water tracking routes
  app.get('/api/water/daily', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const date = req.query.date || new Date().toISOString().split('T')[0];
      
      // Get user's water goal from profile or default to 8 cups
      const profile = await storage.getUserProfile(userId);
      const goal = profile?.waterGoal || 8;
      
      // Calculate total water intake for the day (mock data for now)
      const intake = Math.random() * goal; // Replace with actual query
      
      res.json({ intake: Math.round(intake * 10) / 10, goal });
    } catch (error) {
      console.error("Error getting water data:", error);
      res.status(500).json({ message: "Failed to get water data" });
    }
  });

  app.post('/api/water/log', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { cups } = req.body;
      
      // Log water intake (mock response for now)
      const result = { id: Date.now(), userId, cups, loggedAt: new Date() };
      
      res.json(result);
    } catch (error) {
      console.error("Error logging water:", error);
      res.status(500).json({ message: "Failed to log water" });
    }
  });

  // Workout streak routes
  app.get('/api/workouts/streak', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // Calculate streak data (mock for now)
      const streakData = {
        current: Math.floor(Math.random() * 10),
        thisWeek: Math.floor(Math.random() * 7),
        total: Math.floor(Math.random() * 50) + 20
      };
      
      res.json(streakData);
    } catch (error) {
      console.error("Error getting workout streak:", error);
      res.status(500).json({ message: "Failed to get workout streak" });
    }
  });

  // Recovery tracking routes
  app.get('/api/recovery/today', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const date = req.query.date || new Date().toISOString().split('T')[0];
      
      // Get recovery data (mock for now)
      const recoveryData = {
        score: Math.floor(Math.random() * 40) + 60, // 60-100
        sleep: Math.round((Math.random() * 4 + 6) * 2) / 2, // 6-10 hours
        stress: Math.floor(Math.random() * 8) + 1, // 1-8
        status: 'Good'
      };
      
      res.json(recoveryData);
    } catch (error) {
      console.error("Error getting recovery data:", error);
      res.status(500).json({ message: "Failed to get recovery data" });
    }
  });

  app.post('/api/recovery/log', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { score, sleep, stress } = req.body;
      
      // Log recovery data (mock response for now)
      const result = { 
        id: Date.now(), 
        userId, 
        score, 
        sleep, 
        stress, 
        loggedAt: new Date(),
        loggedDate: new Date().toISOString().split('T')[0]
      };
      
      res.json(result);
    } catch (error) {
      console.error("Error logging recovery:", error);
      res.status(500).json({ message: "Failed to log recovery" });
    }
  });

  // AI Chat routes
  app.post('/api/ai/chat', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { message } = req.body;
      
      if (!message) {
        return res.status(400).json({ message: "Message is required" });
      }

      // Get user context for better responses
      const profile = await storage.getUserProfile(userId);
      const recentWorkouts = await storage.getRecentWorkouts(userId, 7);
      const recentNutrition = await storage.getRecentNutritionData(userId, 3);
      
      const result = await openaiService.chatWithAI(message, {
        profile,
        recentWorkouts,
        recentNutrition
      });

      // Save the chat message with workout data and 5-minute expiration
      const chatData = insertAiChatMessageSchema.parse({
        userId,
        message,
        response: result.response,
        messageType: 'question',
        workoutPlan: result.workoutPlan ? JSON.stringify(result.workoutPlan) : null,
        weeklyWorkouts: result.weeklyWorkouts ? JSON.stringify(result.weeklyWorkouts) : null,
        expiresAt: new Date(Date.now() + 5 * 60 * 1000) // Expire in 5 minutes
      });
      await storage.saveChatMessage(chatData);

      res.json(result);
    } catch (error) {
      console.error("Error in AI chat:", error);
      res.status(500).json({ message: "Failed to process AI chat" });
    }
  });

  app.post('/api/ai/generate-weekly-workout', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { preferences } = req.body;
      
      const profile = await storage.getUserProfile(userId);
      if (!profile) {
        return res.status(400).json({ message: "Profile required for workout generation" });
      }
      
      const weeklyWorkouts = await openaiService.generateWeeklyWorkout(profile, preferences);
      res.json({ weeklyWorkouts });
    } catch (error) {
      console.error("Error generating weekly workout:", error);
      res.status(500).json({ message: "Failed to generate weekly workout" });
    }
  });

  app.get('/api/ai/chat-history', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { limit = 50 } = req.query;
      
      // Get recent chat messages from database
      const messages = await storage.getChatHistory(userId, parseInt(limit as string));
      res.json(messages);
    } catch (error) {
      console.error("Error fetching chat history:", error);
      res.status(500).json({ message: "Failed to fetch chat history" });
    }
  });

  // AI Workout Generation
  app.post('/api/ai/generate-workout', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { preferences } = req.body;
      
      const profile = await storage.getUserProfile(userId);
      if (!profile) {
        return res.status(400).json({ message: "Profile required for workout generation" });
      }
      
      const workoutPlan = await openaiService.generateWorkout(profile, preferences);
      
      const createdPlan = await storage.createWorkoutPlan({
        userId,
        ...workoutPlan,
        isAiGenerated: true
      });
      
      res.json(createdPlan);
    } catch (error) {
      console.error("Error generating workout:", error);
      res.status(500).json({ message: "Failed to generate workout" });
    }
  });

  // Dashboard stats
  app.get('/api/dashboard/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const today = new Date().toISOString().split('T')[0];
      
      const [dailyNutrition, weeklyWorkouts, todaySupplements] = await Promise.all([
        storage.getDailyNutritionStats(userId, today),
        storage.getWeeklyWorkoutStats(userId),
        storage.getTodaySupplementStatus(userId, today)
      ]);
      
      res.json({
        dailyNutrition,
        weeklyWorkouts,
        todaySupplements
      });
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  // Mobile demo route
  app.get('/mobile-demo.html', (_req, res) => {
    res.sendFile('mobile-demo.html', { root: process.cwd() });
  });

  const httpServer = createServer(app);
  return httpServer;
}
