import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_SECRET || "your-api-key"
});

interface UserProfile {
  id?: number;
  userId?: string;
  age?: number | null;
  gender?: string | null;
  height?: string | null;
  weight?: string | null;
  activityLevel?: string | null;
  fitnessGoals?: string[] | null;
  dietaryPreferences?: string[] | null;
  targetCalories?: number | null;
  targetProtein?: number | null;
  targetCarbs?: number | null;
  targetFats?: number | null;
  targetFiber?: number | null;
  createdAt?: Date | null;
  updatedAt?: Date | null;
}

interface WorkoutExercise {
  name: string;
  sets: number;
  reps: string;
  weight?: string;
  duration?: number;
  restTime: number;
  notes?: string;
}

interface WorkoutPlan {
  name: string;
  description: string;
  duration: number;
  difficulty: string;
  exercises: WorkoutExercise[];
}

interface NutritionData {
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  fiber: number;
}

interface SupplementAnalysis {
  insights: string[];
  recommendations: string[];
  warnings: string[];
  deficiencies: string[];
  excesses: string[];
}

export class OpenAIService {
  async generateInitialPlan(profile: UserProfile) {
    try {
      const prompt = `
        Based on the following user profile, generate a personalized fitness and nutrition plan:
        
        Profile:
        - Age: ${profile.age || 'Not specified'}
        - Gender: ${profile.gender || 'Not specified'}
        - Height: ${profile.height || 'Not specified'} cm
        - Weight: ${profile.weight || 'Not specified'} kg
        - Activity Level: ${profile.activityLevel || 'Not specified'}
        - Fitness Goals: ${profile.fitnessGoals?.join(', ') || 'Not specified'}
        - Dietary Preferences: ${profile.dietaryPreferences?.join(', ') || 'Not specified'}
        
        Please provide:
        1. A beginner-friendly workout plan for the first week
        2. Updated macro targets if different from current
        
        Respond in JSON format with this structure:
        {
          "workoutPlan": {
            "name": "string",
            "description": "string",
            "duration": number,
            "difficulty": "string",
            "exercises": [
              {
                "name": "string",
                "sets": number,
                "reps": "string",
                "weight": "string or null",
                "duration": number or null,
                "restTime": number,
                "notes": "string or null"
              }
            ]
          },
          "macroAdjustments": {
            "calories": number or null,
            "protein": number or null,
            "carbs": number or null,
            "fats": number or null
          }
        }
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are a certified fitness and nutrition expert. Provide personalized, safe, and effective recommendations based on user profiles."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.7
      });

      return JSON.parse(response.choices[0].message.content || '{}');
    } catch (error) {
      console.error("Error generating initial plan:", error);
      throw new Error("Failed to generate initial plan");
    }
  }

  async generateWeeklyWorkout(profile: UserProfile, preferences: any): Promise<{ [key: string]: WorkoutPlan }> {
    try {
      const prompt = `
        Create a complete 7-day weekly workout plan for the following user:
        
        User Profile:
        - Age: ${profile.age || 'Not specified'}
        - Gender: ${profile.gender || 'Not specified'}
        - Activity Level: ${profile.activityLevel || 'Not specified'}
        - Fitness Goals: ${profile.fitnessGoals?.join(', ') || 'Not specified'}
        
        Preferences:
        - Duration per session: ${preferences.duration || 45} minutes
        - Focus Area: ${preferences.focusArea || 'Full body'}
        - Equipment: ${preferences.equipment || 'Gym equipment'}
        - Difficulty: ${preferences.difficulty || 'Intermediate'}
        
        Create a comprehensive 7-day weekly workout plan that utilizes ALL days of the week.
        Each day should have meaningful workout content - avoid designating any specific days as mandatory rest days.
        Instead, vary workout intensity and focus areas to allow for active recovery.
        Include variety in muscle groups, exercise types, and intensities throughout the week.
        
        Respond in JSON format with this structure:
        {
          "Sunday": {
            "name": "string (e.g., 'Active Recovery & Mobility')",
            "description": "string", 
            "duration": number,
            "difficulty": "string",
            "exercises": [
              {
                "name": "string",
                "sets": number,
                "reps": "string",
                "restTime": number
              }
            ]
          },
          "Monday": { ... },
          "Tuesday": { ... },
          "Wednesday": { ... },
          "Thursday": { ... },
          "Friday": { ... },
          "Saturday": { ... }
        }
        
        Important: Every day should include exercises. Use lighter activities like yoga, stretching, walking, or mobility work for recovery days rather than complete rest.
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "You are a certified personal trainer. Create safe, effective, and engaging weekly workout plans tailored to individual needs and preferences."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.7
      });

      return JSON.parse(response.choices[0].message.content || '{}');
    } catch (error) {
      console.error("Error generating weekly workout:", error);
      throw new Error("Failed to generate weekly workout plan");
    }
  }

  async generateWorkout(profile: UserProfile, preferences: any): Promise<WorkoutPlan> {
    try {
      const prompt = `
        Generate a personalized workout plan based on:
        
        User Profile:
        - Age: ${profile.age || 'Not specified'}
        - Gender: ${profile.gender || 'Not specified'}
        - Activity Level: ${profile.activityLevel || 'Not specified'}
        - Fitness Goals: ${profile.fitnessGoals?.join(', ') || 'Not specified'}
        
        Preferences:
        - Duration: ${preferences.duration || 'Not specified'} minutes
        - Focus Area: ${preferences.focusArea || 'Not specified'}
        - Equipment: ${preferences.equipment || 'Not specified'}
        - Difficulty: ${preferences.difficulty || 'Not specified'}
        
        Create a comprehensive workout with proper warm-up, main exercises, and cool-down.
        
        Respond in JSON format with this structure:
        {
          "name": "string",
          "description": "string", 
          "duration": number,
          "difficulty": "string",
          "exercises": [
            {
              "name": "string",
              "sets": number,
              "reps": "string",
              "weight": "string or null",
              "duration": number or null,
              "restTime": number,
              "notes": "string or null"
            }
          ]
        }
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are a certified personal trainer. Create safe, effective, and engaging workout plans tailored to individual needs and preferences."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.7
      });

      return JSON.parse(response.choices[0].message.content || '{}');
    } catch (error) {
      console.error("Error generating workout:", error);
      throw new Error("Failed to generate workout");
    }
  }

  async analyzeSupplements(
    userSupplements: any[], 
    profile: UserProfile, 
    recentNutrition: NutritionData[]
  ): Promise<SupplementAnalysis> {
    try {
      const avgNutrition = this.calculateNutritionAverage(recentNutrition);
      
      const prompt = `
        Analyze the following supplement regimen for potential issues and provide recommendations:
        
        User Profile:
        - Age: ${profile.age || 'Not specified'}
        - Gender: ${profile.gender || 'Not specified'}
        - Weight: ${profile.weight || 'Not specified'} kg
        - Activity Level: ${profile.activityLevel || 'Not specified'}
        - Fitness Goals: ${profile.fitnessGoals?.join(', ') || 'Not specified'}
        
        Current Supplements:
        ${userSupplements.map(s => `- ${s.customName || s.supplementName}: ${s.dosage} ${s.frequency}`).join('\n')}
        
        Recent Average Daily Nutrition (last 7 days):
        - Calories: ${avgNutrition.calories}
        - Protein: ${avgNutrition.protein}g
        - Carbs: ${avgNutrition.carbs}g
        - Fats: ${avgNutrition.fats}g
        - Fiber: ${avgNutrition.fiber}g
        
        Analyze for:
        1. Potential nutrient deficiencies based on diet and activity
        2. Possible excesses or interactions
        3. Recommendations for optimization
        4. Safety warnings if any
        
        Respond in JSON format:
        {
          "insights": ["insight1", "insight2"],
          "recommendations": ["rec1", "rec2"],
          "warnings": ["warning1", "warning2"],
          "deficiencies": ["def1", "def2"],
          "excesses": ["excess1", "excess2"]
        }
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are a licensed nutritionist and supplement expert. Provide evidence-based analysis and recommendations for supplement regimens."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.3
      });

      return JSON.parse(response.choices[0].message.content || '{}');
    } catch (error) {
      console.error("Error analyzing supplements:", error);
      throw new Error("Failed to analyze supplements");
    }
  }

  async chatWithAI(message: string, context: any): Promise<{ response: string; workoutPlan?: WorkoutPlan; weeklyWorkouts?: { [key: string]: WorkoutPlan } }> {
    try {
      // Check if the message is asking for a weekly workout plan
      const isWeeklyRequest = /\b(weekly|week|7-day|7 day|schedule|calendar)\b/i.test(message);
      const isWorkoutRequest = /\b(workout|exercise|training|routine|plan|generate|create)\b/i.test(message);

      if (isWeeklyRequest && isWorkoutRequest && context.profile) {
        // Generate weekly workout plan
        const weeklyWorkouts = await this.generateWeeklyWorkout(context.profile, {
          duration: 45,
          focusArea: 'full body',
          equipment: 'gym',
          difficulty: 'intermediate'
        });
        
        return {
          response: "I've created a complete 7-day weekly workout plan for you! Each day has a different focus to ensure balanced training and proper recovery.",
          weeklyWorkouts
        };
      } else if (isWorkoutRequest && context.profile) {
        // Generate a workout plan
        const workoutPrompt = `
          User Profile:
          - Age: ${context.profile.age || 'Not specified'}
          - Gender: ${context.profile.gender || 'Not specified'} 
          - Activity Level: ${context.profile.activityLevel || 'moderate'}
          - Fitness Goals: ${context.profile.fitnessGoals?.join(', ') || 'general fitness'}
          
          User Request: ${message}
          
          Create a personalized workout plan based on their request and profile.
          
          Respond in JSON format with this structure:
          {
            "response": "A conversational response explaining the workout plan",
            "workoutPlan": {
              "name": "string",
              "description": "string", 
              "duration": number,
              "difficulty": "string",
              "exercises": [
                {
                  "name": "string",
                  "sets": number,
                  "reps": "string",
                  "weight": "string or null",
                  "duration": number or null,
                  "restTime": number,
                  "notes": "string or null"
                }
              ]
            }
          }
        `;

        const response = await openai.chat.completions.create({
          model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
          messages: [
            {
              role: "system",
              content: "You are a certified personal trainer and fitness expert. Create personalized workout plans and provide encouraging, professional guidance."
            },
            {
              role: "user",
              content: workoutPrompt
            }
          ],
          response_format: { type: "json_object" },
          temperature: 0.7
        });

        const result = JSON.parse(response.choices[0].message.content || '{}');
        return {
          response: result.response || "I've created a workout plan for you!",
          workoutPlan: result.workoutPlan
        };
      } else {
        // Regular chat response
        const contextPrompt = `
          User Context:
          - Profile: ${JSON.stringify(context.profile)}
          - Recent Workouts: ${JSON.stringify(context.recentWorkouts)}
          - Recent Nutrition: ${JSON.stringify(context.recentNutrition)}
          
          User Question: ${message}
          
          Provide a helpful, personalized response based on the user's context and fitness expertise.
        `;

        const response = await openai.chat.completions.create({
          model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
          messages: [
            {
              role: "system",
              content: "You are a knowledgeable fitness and nutrition AI assistant. Provide helpful, accurate, and personalized advice based on the user's profile and recent activity. Keep responses conversational and actionable."
            },
            {
              role: "user",
              content: contextPrompt
            }
          ],
          temperature: 0.7,
          max_tokens: 500
        });

        return {
          response: response.choices[0].message.content || "I'm sorry, I couldn't process your question right now."
        };
      }
    } catch (error) {
      console.error("Error in AI chat:", error);
      throw new Error("Failed to process AI chat");
    }
  }

  private calculateNutritionAverage(nutritionData: NutritionData[]): NutritionData {
    if (nutritionData.length === 0) {
      return { calories: 0, protein: 0, carbs: 0, fats: 0, fiber: 0 };
    }

    const totals = nutritionData.reduce(
      (acc, day) => ({
        calories: acc.calories + day.calories,
        protein: acc.protein + day.protein,
        carbs: acc.carbs + day.carbs,
        fats: acc.fats + day.fats,
        fiber: acc.fiber + day.fiber,
      }),
      { calories: 0, protein: 0, carbs: 0, fats: 0, fiber: 0 }
    );

    return {
      calories: Math.round(totals.calories / nutritionData.length),
      protein: Math.round(totals.protein / nutritionData.length),
      carbs: Math.round(totals.carbs / nutritionData.length),
      fats: Math.round(totals.fats / nutritionData.length),
      fiber: Math.round(totals.fiber / nutritionData.length),
    };
  }
}
