interface NutritionData {
  name: string;
  brand?: string;
  servingSize: number;
  servingUnit: string;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  fiber: number;
  sugar?: number;
  sodium?: number;
}

export class NutritionService {
  private edamamAppId = process.env.EDAMAM_APP_ID || process.env.NUTRITION_APP_ID || "";
  private edamamAppKey = process.env.EDAMAM_APP_KEY || process.env.NUTRITION_APP_KEY || "";

  async searchFoods(query: string): Promise<NutritionData[]> {
    try {
      // If API credentials are available, use Edamam API
      if (this.edamamAppId && this.edamamAppKey) {
        return await this.searchEdamamFoods(query);
      }
      
      // Fallback to basic food database search
      return await this.searchBasicFoods(query);
    } catch (error) {
      console.error("Error searching foods:", error);
      // Return fallback basic search if API fails
      return await this.searchBasicFoods(query);
    }
  }

  private async searchEdamamFoods(query: string): Promise<NutritionData[]> {
    const url = `https://api.edamam.com/api/food-database/v2/parser?app_id=${this.edamamAppId}&app_key=${this.edamamAppKey}&ingr=${encodeURIComponent(query)}&nutrition-type=cooking`;
    
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Edamam API error: ${response.statusText}`);
    }
    
    const data = await response.json();
    
    return data.hints?.slice(0, 10).map((hint: any) => ({
      name: hint.food.label,
      brand: hint.food.brand || undefined,
      servingSize: 100, // Default to 100g
      servingUnit: 'g',
      calories: Math.round(hint.food.nutrients.ENERC_KCAL || 0),
      protein: Math.round(hint.food.nutrients.PROCNT || 0),
      carbs: Math.round(hint.food.nutrients.CHOCDF || 0),
      fats: Math.round(hint.food.nutrients.FAT || 0),
      fiber: Math.round(hint.food.nutrients.FIBTG || 0),
      sugar: Math.round(hint.food.nutrients.SUGAR || 0),
      sodium: Math.round(hint.food.nutrients.NA || 0),
    })) || [];
  }

  private async searchBasicFoods(query: string): Promise<NutritionData[]> {
    // Basic food database for common foods when API is not available
    const basicFoods: NutritionData[] = [
      // Proteins
      { name: "Chicken Breast", servingSize: 100, servingUnit: "g", calories: 165, protein: 31, carbs: 0, fats: 3.6, fiber: 0 },
      { name: "Salmon", servingSize: 100, servingUnit: "g", calories: 208, protein: 20, carbs: 0, fats: 13, fiber: 0 },
      { name: "Eggs", servingSize: 100, servingUnit: "g", calories: 155, protein: 13, carbs: 1.1, fats: 11, fiber: 0 },
      { name: "Greek Yogurt", servingSize: 100, servingUnit: "g", calories: 59, protein: 10, carbs: 3.6, fats: 0.4, fiber: 0 },
      { name: "Tofu", servingSize: 100, servingUnit: "g", calories: 76, protein: 8, carbs: 1.9, fats: 4.8, fiber: 0.3 },
      
      // Carbohydrates
      { name: "Brown Rice", servingSize: 100, servingUnit: "g", calories: 123, protein: 2.6, carbs: 23, fats: 0.9, fiber: 1.8 },
      { name: "Quinoa", servingSize: 100, servingUnit: "g", calories: 120, protein: 4.4, carbs: 22, fats: 1.9, fiber: 2.8 },
      { name: "Oats", servingSize: 100, servingUnit: "g", calories: 389, protein: 17, carbs: 66, fats: 7, fiber: 11 },
      { name: "Sweet Potato", servingSize: 100, servingUnit: "g", calories: 86, protein: 1.6, carbs: 20, fats: 0.1, fiber: 3 },
      { name: "Banana", servingSize: 100, servingUnit: "g", calories: 89, protein: 1.1, carbs: 23, fats: 0.3, fiber: 2.6 },
      
      // Fats
      { name: "Avocado", servingSize: 100, servingUnit: "g", calories: 160, protein: 2, carbs: 9, fats: 15, fiber: 7 },
      { name: "Almonds", servingSize: 100, servingUnit: "g", calories: 579, protein: 21, carbs: 22, fats: 50, fiber: 12 },
      { name: "Olive Oil", servingSize: 100, servingUnit: "g", calories: 884, protein: 0, carbs: 0, fats: 100, fiber: 0 },
      
      // Vegetables
      { name: "Broccoli", servingSize: 100, servingUnit: "g", calories: 34, protein: 2.8, carbs: 7, fats: 0.4, fiber: 2.6 },
      { name: "Spinach", servingSize: 100, servingUnit: "g", calories: 23, protein: 2.9, carbs: 3.6, fats: 0.4, fiber: 2.2 },
      { name: "Bell Pepper", servingSize: 100, servingUnit: "g", calories: 31, protein: 1, carbs: 7, fats: 0.3, fiber: 2.5 },
    ];

    const searchTerm = query.toLowerCase();
    return basicFoods.filter(food => 
      food.name.toLowerCase().includes(searchTerm)
    ).slice(0, 10);
  }

  async getFoodByBarcode(barcode: string): Promise<NutritionData | null> {
    try {
      // If we had a barcode API like Open Food Facts, we would use it here
      // For now, return null as fallback
      return null;
    } catch (error) {
      console.error("Error fetching food by barcode:", error);
      return null;
    }
  }

  calculateMacroPercentages(calories: number, protein: number, carbs: number, fats: number) {
    if (calories === 0) return { protein: 0, carbs: 0, fats: 0 };
    
    const proteinCals = protein * 4;
    const carbsCals = carbs * 4;
    const fatsCals = fats * 9;
    
    return {
      protein: Math.round((proteinCals / calories) * 100),
      carbs: Math.round((carbsCals / calories) * 100),
      fats: Math.round((fatsCals / calories) * 100),
    };
  }

  generateMealPlan(targetCalories: number, targetProtein: number, targetCarbs: number, targetFats: number) {
    // This would generate a meal plan based on targets
    // Implementation would depend on having a comprehensive food database
    return {
      breakfast: [],
      lunch: [],
      dinner: [],
      snacks: []
    };
  }
}
