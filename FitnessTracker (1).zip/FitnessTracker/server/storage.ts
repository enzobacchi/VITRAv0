import {
  users,
  userProfiles,
  workoutPlans,
  scheduledWorkouts,
  workoutLogs,
  foods,
  foodLogs,
  supplements,
  userSupplements,
  supplementLogs,
  aiChatMessages,
  type User,
  type UpsertUser,
  type UserProfile,
  type InsertUserProfile,
  type WorkoutPlan,
  type InsertWorkoutPlan,
  type ScheduledWorkout,
  type InsertScheduledWorkout,
  type InsertWorkoutLog,
  type WorkoutLog,
  type Food,
  type InsertFood,
  type FoodLog,
  type InsertFoodLog,
  type Supplement,
  type UserSupplement,
  type InsertUserSupplement,
  type InsertSupplementLog,
  type InsertAiChatMessage,
  type AiChatMessage,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, sql, gte, lte } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Profile operations
  getUserProfile(userId: string): Promise<UserProfile | undefined>;
  upsertUserProfile(profile: InsertUserProfile): Promise<UserProfile>;
  
  // Workout operations
  getWorkoutPlans(userId: string): Promise<WorkoutPlan[]>;
  createWorkoutPlan(plan: InsertWorkoutPlan): Promise<WorkoutPlan>;
  updateWorkoutPlan(workoutId: number, updates: Partial<WorkoutPlan>): Promise<WorkoutPlan>;
  getScheduledWorkouts(userId: string, date?: string): Promise<ScheduledWorkout[]>;
  scheduleWorkout(schedule: InsertScheduledWorkout): Promise<ScheduledWorkout>;
  clearUserWorkouts(userId: string): Promise<void>;
  removeScheduledWorkout(userId: string, scheduledDate: string): Promise<void>;
  logWorkout(log: InsertWorkoutLog): Promise<WorkoutLog>;
  getRecentWorkouts(userId: string, days: number): Promise<any[]>;
  getWeeklyWorkoutStats(userId: string): Promise<{ completed: number; total: number }>;
  
  // Nutrition operations
  getFoodLogs(userId: string, date?: string): Promise<FoodLog[]>;
  logFood(log: InsertFoodLog): Promise<FoodLog>;
  getDailyNutritionStats(userId: string, date: string): Promise<any>;
  getRecentNutritionData(userId: string, days: number): Promise<any[]>;
  
  // Supplement operations
  getUserSupplements(userId: string): Promise<UserSupplement[]>;
  addUserSupplement(supplement: InsertUserSupplement): Promise<UserSupplement>;
  getTodaySupplementStatus(userId: string, date: string): Promise<any[]>;
  
  // AI Chat operations
  saveChatMessage(message: InsertAiChatMessage): Promise<void>;
  getChatHistory(userId: string, limit: number): Promise<AiChatMessage[]>;
  
  // Workout completion
  completeScheduledWorkout(scheduledWorkoutId: number, userId: string, duration?: number): Promise<ScheduledWorkout>;
  uncompleteScheduledWorkout(scheduledWorkoutId: number, userId: string): Promise<ScheduledWorkout>;
}

export class DatabaseStorage implements IStorage {
  // User operations (mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Profile operations
  async getUserProfile(userId: string): Promise<UserProfile | undefined> {
    const [profile] = await db
      .select()
      .from(userProfiles)
      .where(eq(userProfiles.userId, userId));
    return profile;
  }

  async upsertUserProfile(profileData: InsertUserProfile): Promise<UserProfile> {
    // Check if profile exists
    const existingProfile = await this.getUserProfile(profileData.userId);
    
    if (existingProfile) {
      const [profile] = await db
        .update(userProfiles)
        .set({ ...profileData, updatedAt: new Date() })
        .where(eq(userProfiles.userId, profileData.userId))
        .returning();
      return profile;
    } else {
      const [profile] = await db
        .insert(userProfiles)
        .values(profileData)
        .returning();
      return profile;
    }
  }

  // Workout operations
  async getWorkoutPlans(userId: string): Promise<WorkoutPlan[]> {
    return await db
      .select()
      .from(workoutPlans)
      .where(eq(workoutPlans.userId, userId))
      .orderBy(desc(workoutPlans.createdAt));
  }

  async createWorkoutPlan(planData: InsertWorkoutPlan): Promise<WorkoutPlan> {
    const [plan] = await db
      .insert(workoutPlans)
      .values(planData)
      .returning();
    return plan;
  }

  async updateWorkoutPlan(workoutId: number, updates: Partial<WorkoutPlan>): Promise<WorkoutPlan> {
    const [plan] = await db
      .update(workoutPlans)
      .set({
        ...updates,
        updatedAt: new Date()
      })
      .where(eq(workoutPlans.id, workoutId))
      .returning();
    return plan;
  }

  async getScheduledWorkouts(userId: string, date?: string): Promise<ScheduledWorkout[]> {
    let query = db
      .select({
        id: scheduledWorkouts.id,
        userId: scheduledWorkouts.userId,
        workoutPlanId: scheduledWorkouts.workoutPlanId,
        scheduledDate: scheduledWorkouts.scheduledDate,
        completed: scheduledWorkouts.completed,
        completedAt: scheduledWorkouts.completedAt,
        notes: scheduledWorkouts.notes,
        createdAt: scheduledWorkouts.createdAt,
        workoutPlan: workoutPlans,
      })
      .from(scheduledWorkouts)
      .leftJoin(workoutPlans, eq(scheduledWorkouts.workoutPlanId, workoutPlans.id))
      .where(eq(scheduledWorkouts.userId, userId));

    if (date) {
      query = db
        .select({
          id: scheduledWorkouts.id,
          userId: scheduledWorkouts.userId,
          workoutPlanId: scheduledWorkouts.workoutPlanId,
          scheduledDate: scheduledWorkouts.scheduledDate,
          completed: scheduledWorkouts.completed,
          completedAt: scheduledWorkouts.completedAt,
          notes: scheduledWorkouts.notes,
          createdAt: scheduledWorkouts.createdAt,
          workoutPlan: workoutPlans,
        })
        .from(scheduledWorkouts)
        .leftJoin(workoutPlans, eq(scheduledWorkouts.workoutPlanId, workoutPlans.id))
        .where(and(
          eq(scheduledWorkouts.userId, userId),
          eq(scheduledWorkouts.scheduledDate, date)
        ));
    }

    return await query.orderBy(desc(scheduledWorkouts.scheduledDate));
  }

  async scheduleWorkout(scheduleData: InsertScheduledWorkout): Promise<ScheduledWorkout> {
    const [scheduled] = await db
      .insert(scheduledWorkouts)
      .values(scheduleData)
      .returning();
    return scheduled;
  }

  async clearUserWorkouts(userId: string): Promise<void> {
    // First delete all scheduled workouts for this user
    await db
      .delete(scheduledWorkouts)
      .where(eq(scheduledWorkouts.userId, userId));
    
    // Then delete all workout plans for this user
    await db
      .delete(workoutPlans)
      .where(eq(workoutPlans.userId, userId));
  }

  async removeScheduledWorkout(userId: string, scheduledDate: string): Promise<void> {
    await db
      .delete(scheduledWorkouts)
      .where(and(
        eq(scheduledWorkouts.userId, userId),
        eq(scheduledWorkouts.scheduledDate, scheduledDate)
      ));
  }

  async logWorkout(logData: InsertWorkoutLog): Promise<WorkoutLog> {
    const [log] = await db
      .insert(workoutLogs)
      .values(logData)
      .returning();
    return log;
  }

  async getRecentWorkouts(userId: string, days: number): Promise<any[]> {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - days);
    
    return await db
      .select()
      .from(scheduledWorkouts)
      .leftJoin(workoutPlans, eq(scheduledWorkouts.workoutPlanId, workoutPlans.id))
      .where(and(
        eq(scheduledWorkouts.userId, userId),
        gte(scheduledWorkouts.scheduledDate, cutoffDate.toISOString().split('T')[0])
      ))
      .orderBy(desc(scheduledWorkouts.scheduledDate));
  }

  async getWeeklyWorkoutStats(userId: string): Promise<{ completed: number; total: number }> {
    const startOfWeek = new Date();
    startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay());
    const startDate = startOfWeek.toISOString().split('T')[0];

    const [result] = await db
      .select({
        total: sql<number>`count(*)`,
        completed: sql<number>`count(case when ${scheduledWorkouts.completed} = true then 1 end)`,
      })
      .from(scheduledWorkouts)
      .where(and(
        eq(scheduledWorkouts.userId, userId),
        gte(scheduledWorkouts.scheduledDate, startDate)
      ));

    return {
      completed: Number(result.completed),
      total: Number(result.total),
    };
  }

  // Nutrition operations
  async getFoodLogs(userId: string, date?: string): Promise<FoodLog[]> {
    let query = db
      .select({
        id: foodLogs.id,
        userId: foodLogs.userId,
        foodId: foodLogs.foodId,
        customFoodName: foodLogs.customFoodName,
        servings: foodLogs.servings,
        mealType: foodLogs.mealType,
        calories: foodLogs.calories,
        protein: foodLogs.protein,
        carbs: foodLogs.carbs,
        fats: foodLogs.fats,
        fiber: foodLogs.fiber,
        loggedAt: foodLogs.loggedAt,
        loggedDate: foodLogs.loggedDate,
        food: foods,
      })
      .from(foodLogs)
      .leftJoin(foods, eq(foodLogs.foodId, foods.id))
      .where(eq(foodLogs.userId, userId));

    if (date) {
      query = db
        .select({
          id: foodLogs.id,
          userId: foodLogs.userId,
          foodId: foodLogs.foodId,
          customFoodName: foodLogs.customFoodName,
          servings: foodLogs.servings,
          mealType: foodLogs.mealType,
          calories: foodLogs.calories,
          protein: foodLogs.protein,
          carbs: foodLogs.carbs,
          fats: foodLogs.fats,
          fiber: foodLogs.fiber,
          loggedAt: foodLogs.loggedAt,
          loggedDate: foodLogs.loggedDate,
          food: foods,
        })
        .from(foodLogs)
        .leftJoin(foods, eq(foodLogs.foodId, foods.id))
        .where(and(
          eq(foodLogs.userId, userId),
          eq(foodLogs.loggedDate, date)
        ));
    }

    return await query.orderBy(desc(foodLogs.loggedAt));
  }

  async logFood(logData: any): Promise<FoodLog> {
    console.log('Storage: Attempting to insert food log:', logData);
    
    const [log] = await db
      .insert(foodLogs)
      .values(logData)
      .returning();
      
    console.log('Storage: Successfully inserted food log:', log);
    return log;
  }

  async getDailyNutritionStats(userId: string, date: string): Promise<any> {
    const profile = await this.getUserProfile(userId);
    
    const [result] = await db
      .select({
        calories: sql<number>`coalesce(sum(${foodLogs.calories}), 0)`,
        protein: sql<number>`coalesce(sum(${foodLogs.protein}), 0)`,
        carbs: sql<number>`coalesce(sum(${foodLogs.carbs}), 0)`,
        fats: sql<number>`coalesce(sum(${foodLogs.fats}), 0)`,
        fiber: sql<number>`coalesce(sum(${foodLogs.fiber}), 0)`,
      })
      .from(foodLogs)
      .where(and(
        eq(foodLogs.userId, userId),
        eq(foodLogs.loggedDate, date)
      ));

    return {
      calories: Number(result.calories),
      protein: Number(result.protein),
      carbs: Number(result.carbs),
      fats: Number(result.fats),
      fiber: Number(result.fiber),
      targetCalories: profile?.targetCalories || 2100,
      targetProtein: profile?.targetProtein || 150,
      targetCarbs: profile?.targetCarbs || 250,
      targetFats: profile?.targetFats || 70,
    };
  }

  async getRecentNutritionData(userId: string, days: number): Promise<any[]> {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - days);
    const startDate = cutoffDate.toISOString().split('T')[0];

    return await db
      .select({
        date: foodLogs.loggedDate,
        calories: sql<number>`sum(${foodLogs.calories})`,
        protein: sql<number>`sum(${foodLogs.protein})`,
        carbs: sql<number>`sum(${foodLogs.carbs})`,
        fats: sql<number>`sum(${foodLogs.fats})`,
        fiber: sql<number>`sum(${foodLogs.fiber})`,
      })
      .from(foodLogs)
      .where(and(
        eq(foodLogs.userId, userId),
        gte(foodLogs.loggedDate, startDate)
      ))
      .groupBy(foodLogs.loggedDate)
      .orderBy(foodLogs.loggedDate);
  }

  // Supplement operations
  async getUserSupplements(userId: string): Promise<UserSupplement[]> {
    return await db
      .select({
        id: userSupplements.id,
        userId: userSupplements.userId,
        supplementId: userSupplements.supplementId,
        customName: userSupplements.customName,
        dosage: userSupplements.dosage,
        frequency: userSupplements.frequency,
        timeOfDay: userSupplements.timeOfDay,
        isActive: userSupplements.isActive,
        startDate: userSupplements.startDate,
        endDate: userSupplements.endDate,
        notes: userSupplements.notes,
        createdAt: userSupplements.createdAt,
        supplement: supplements,
      })
      .from(userSupplements)
      .leftJoin(supplements, eq(userSupplements.supplementId, supplements.id))
      .where(and(
        eq(userSupplements.userId, userId),
        eq(userSupplements.isActive, true)
      ))
      .orderBy(desc(userSupplements.createdAt));
  }

  async addUserSupplement(supplementData: InsertUserSupplement): Promise<UserSupplement> {
    const [supplement] = await db
      .insert(userSupplements)
      .values(supplementData)
      .returning();
    return supplement;
  }

  async getTodaySupplementStatus(userId: string, date: string): Promise<any[]> {
    return await db
      .select()
      .from(userSupplements)
      .leftJoin(
        supplementLogs,
        and(
          eq(supplementLogs.userSupplementId, userSupplements.id),
          eq(supplementLogs.loggedDate, date)
        )
      )
      .where(and(
        eq(userSupplements.userId, userId),
        eq(userSupplements.isActive, true)
      ));
  }

  // AI Chat operations
  async saveChatMessage(messageData: InsertAiChatMessage): Promise<void> {
    await db.insert(aiChatMessages).values(messageData);
  }

  async getChatHistory(userId: string, limit: number): Promise<AiChatMessage[]> {
    const messages = await db
      .select()
      .from(aiChatMessages)
      .where(eq(aiChatMessages.userId, userId))
      .orderBy(desc(aiChatMessages.createdAt))
      .limit(limit * 2); // Get more to account for filtering
    
    const now = new Date();
    const validMessages = messages.filter(msg => 
      !msg.expiresAt || new Date(msg.expiresAt) > now
    );
    
    return validMessages.slice(0, limit);
  }

  async completeScheduledWorkout(scheduledWorkoutId: number, userId: string, duration?: number): Promise<ScheduledWorkout> {
    const [updatedWorkout] = await db
      .update(scheduledWorkouts)
      .set({
        completed: true,
        completedAt: new Date(),
        notes: duration ? `Completed in ${duration} minutes` : undefined
      })
      .where(and(
        eq(scheduledWorkouts.id, scheduledWorkoutId),
        eq(scheduledWorkouts.userId, userId)
      ))
      .returning();

    if (!updatedWorkout) {
      throw new Error('Scheduled workout not found or does not belong to user');
    }

    return updatedWorkout;
  }

  async uncompleteScheduledWorkout(scheduledWorkoutId: number, userId: string): Promise<ScheduledWorkout> {
    const [updatedWorkout] = await db
      .update(scheduledWorkouts)
      .set({
        completed: false,
        completedAt: null,
        notes: null
      })
      .where(and(
        eq(scheduledWorkouts.id, scheduledWorkoutId),
        eq(scheduledWorkouts.userId, userId)
      ))
      .returning();

    if (!updatedWorkout) {
      throw new Error('Scheduled workout not found or does not belong to user');
    }

    return updatedWorkout;
  }
}

export const storage = new DatabaseStorage();
